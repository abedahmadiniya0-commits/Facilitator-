/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TeamScores {
  communication: number; // تسهیم اطلاعات و ارتباطات
  trust: number;         // اعتماد و امنیت روانی
  coordination: number;  // رهبری و هماهنگی
  problemSolving: number;// حل مسئله و خلاقیت
  resilience: number;    // تاب‌آوری و مدیریت بحران
}

export const SCORE_LABELS: Record<keyof TeamScores, { fa: string; en: string; description: string }> = {
  communication: {
    fa: "ارتباطات و تسهیم اطلاعات",
    en: "Communication",
    description: "کیفیت انتقال اطلاعات، گوش دادن فعال و بازخورد بین اعضای تیم"
  },
  trust: {
    fa: "اعتماد و امنیت روانی",
    en: "Trust & Psychological Safety",
    description: "احساس امنیت برای ابراز عقیده، پذیرش اشتباهات و تکیه بر یکدیگر"
  },
  coordination: {
    fa: "رهبری و هماهنگی تیمی",
    en: "Leadership & Coordination",
    description: "تقسیم وظایف، تعهد به نقش‌ها و مدیریت زمان و منابع تیمی"
  },
  problemSolving: {
    fa: "حل مسئله و خلاقیت",
    en: "Problem Solving & Creativity",
    description: "تفکر استراتژیک، ایده‌پردازی خلاق و تحلیل گزینه‌ها قبل از اقدام"
  },
  resilience: {
    fa: "تاب‌آوری و مدیریت بحران",
    en: "Resilience & Adaptability",
    description: "نحوه مواجهه با شکست، سازگاری با تغییرات و حفظ روحیه در فشار"
  }
};

export interface SelfReflection {
  whatWentWell: string;   // چه چیزهایی خوب پیش رفت؟
  challenges: string;     // چه چالش‌هایی وجود داشت؟
  learnings: string;      // چه درس‌هایی گرفتیم؟
  actionPlan: string;     // چه تغییراتی در محیط کار واقعی ایجاد می‌کنیم؟
}

export interface AIQuestion {
  id: number;
  question: string;
  intent: string;
  oridCategory: string;
}

export interface ActionItem {
  id: string;
  task: string;
  responsible: string;
  deadline: string;
  completed: boolean;
}

export interface ActionPlan {
  leaderName: string;
  leaderEmail: string;
  commitments: ActionItem[];
  followUpSent: boolean;
  followUpDate: string; // ISO date string
}

export interface Team {
  id: string;
  name: string;
  membersCount: number;
  preScores: TeamScores;
  preNotes: string;
  postScores: TeamScores;
  postNotes: string;
  reflection: SelfReflection;
  aiQuestions?: AIQuestion[];
  behaviorTags?: string[]; // ثبت سریع رفتارهای حین بازی
  actionPlan?: ActionPlan; // خروجی برنامه اقدام (Action Plan Tracker)
}

export interface PresentationSlide {
  id: number;
  title: string;
  subtitle?: string;
  type: "title" | "chart" | "strengths" | "weaknesses" | "recommendations" | "workspace" | "closing";
  content: string[]; // Key bullet points or markdown paragraphs
  visualHint?: string; // Icon or visual styling hint
}

export interface DebriefAnalysis {
  teamId: string;
  teamName: string;
  strengths: {
    title: string;
    description: string;
    behavioralEvidence: string;
  }[];
  weaknesses: {
    title: string;
    description: string;
    rootCause: string;
  }[];
  comzeeInsights: string[]; // Specialized Comzee facilitation tips for this team
  workspaceTransfer: {
    actionableStep: string;
    officeApplication: string;
  }[];
  slides: PresentationSlide[];
}

export interface Event {
  id: string;
  title: string;
  date: string;
  clientName: string; // نام سازمان / شرکت مشتری
  facilitatorName: string;
  goals: string[]; // اهداف اصلی رویداد
  teams: Team[];
  analyses: Record<string, DebriefAnalysis>; // teamId -> Analysis
  status: "setup" | "active" | "completed";
  selectedGames?: string[]; // شناسه بازی‌های انتخاب‌شده از لیست پیش‌فرض
  customGames?: string[];   // بازی‌های سفارشی که تسهیل‌گر تایپ کرده است
  aiTone?: "motivational" | "analytical" | "strict";
}
