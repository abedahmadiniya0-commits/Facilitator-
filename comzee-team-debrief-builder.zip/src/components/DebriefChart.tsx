/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import { TeamScores, SCORE_LABELS } from "../types";
import { BarChart3, Radio } from "lucide-react";

interface DebriefChartProps {
  postScores: TeamScores;
  teamName: string;
  lightMode?: boolean;
}

export default function DebriefChart({ postScores, teamName, lightMode = false }: DebriefChartProps) {
  const [chartType, setChartType] = useState<"radar" | "bar">("radar");

  // Transform scores into Recharts data format
  const chartData = [
    {
      subject: SCORE_LABELS.communication.fa,
      score: postScores.communication,
      fullMark: 10,
    },
    {
      subject: SCORE_LABELS.trust.fa,
      score: postScores.trust,
      fullMark: 10,
    },
    {
      subject: SCORE_LABELS.coordination.fa,
      score: postScores.coordination,
      fullMark: 10,
    },
    {
      subject: SCORE_LABELS.problemSolving.fa,
      score: postScores.problemSolving,
      fullMark: 10,
    },
    {
      subject: SCORE_LABELS.resilience.fa,
      score: postScores.resilience,
      fullMark: 10,
    },
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className={`border p-4 rounded-xl shadow-2xl text-right dir-rtl font-sans text-xs space-y-2 ${
          lightMode ? "bg-white border-slate-200" : "bg-slate-900 border-slate-800"
        }`}>
          <p className={`font-extrabold border-b pb-1 ${
            lightMode ? "text-slate-950 border-slate-100" : "text-white border-slate-800"
          }`}>{payload[0].payload.subject}</p>
          <div className="flex justify-between items-center gap-6">
            <span className={`font-semibold ${lightMode ? "text-amber-600" : "text-amber-400"}`}>امتیاز پویایی تیمی:</span>
            <span className={`font-mono font-bold ${lightMode ? "text-amber-600" : "text-amber-400"}`}>{payload[0].payload.score} / ۱۰</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className={`p-6 flex flex-col space-y-4 font-sans w-full min-h-[420px] rounded-2xl ${
      lightMode 
        ? "bg-white border border-slate-200/80 text-slate-800 shadow-sm" 
        : "bg-slate-950/80 border border-slate-900 text-slate-100"
    }`}>
      <div className={`flex flex-col sm:flex-row items-center justify-between gap-4 border-b pb-4 ${
        lightMode ? "border-slate-100" : "border-slate-900"
      }`}>
        <div>
          <h4 className={`font-bold text-base ${lightMode ? "text-slate-900" : "text-white"}`}>نمودار تحلیل پویایی‌های تیمی کامزی</h4>
          <p className={`text-xs mt-0.5 ${lightMode ? "text-slate-500" : "text-slate-400"}`}>تیم {teamName} - میزان توسعه‌یافتگی ابعاد کلیدی کار تیمی</p>
        </div>
        <div className={`flex rounded-lg p-1 border self-end sm:self-center ${
          lightMode ? "bg-slate-50 border-slate-200" : "bg-slate-900 border-slate-800"
        }`}>
          <button
            onClick={() => setChartType("radar")}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer ${
              chartType === "radar" 
                ? "bg-amber-500 text-slate-950 shadow-md" 
                : lightMode ? "text-slate-500 hover:text-slate-850" : "text-slate-400 hover:text-white"
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            نمودار رادار
          </button>
          <button
            onClick={() => setChartType("bar")}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer ${
              chartType === "bar" 
                ? "bg-amber-500 text-slate-950 shadow-md" 
                : lightMode ? "text-slate-500 hover:text-slate-850" : "text-slate-400 hover:text-white"
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            نمودار ستونی
          </button>
        </div>
      </div>

      <div className="flex-1 w-full min-h-[300px] flex items-center justify-center">
        {chartType === "radar" ? (
          <ResponsiveContainer width="100%" height={320}>
            <RadarChart cx="50%" cy="50%" outerRadius="75%" data={chartData}>
              <PolarGrid stroke={lightMode ? "#e2e8f0" : "#1e293b"} />
              <PolarAngleAxis
                dataKey="subject"
                tick={{ fill: lightMode ? "#475569" : "#cbd5e1", fontSize: 10, fontWeight: 500 }}
              />
              <PolarRadiusAxis angle={30} domain={[0, 10]} stroke={lightMode ? "#cbd5e1" : "#475569"} tick={{ fill: lightMode ? "#64748b" : "#64748b" }} />
              <Radar
                name="امتیاز پویایی تیمی"
                dataKey="score"
                stroke="#f59e0b"
                fill="#f59e0b"
                fillOpacity={0.35}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="bottom"
                height={36}
                formatter={(value) => <span className={`text-xs px-1 font-semibold ${lightMode ? "text-slate-600" : "text-slate-300"}`}>{value}</span>}
              />
            </RadarChart>
          </ResponsiveContainer>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData} margin={{ top: 20, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={lightMode ? "#f1f5f9" : "#1e293b"} />
              <XAxis
                dataKey="subject"
                tick={{ fill: lightMode ? "#475569" : "#cbd5e1", fontSize: 9, fontWeight: 500 }}
                stroke={lightMode ? "#cbd5e1" : "#334155"}
              />
              <YAxis domain={[0, 10]} stroke={lightMode ? "#cbd5e1" : "#334155"} tick={{ fill: "#64748b" }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="bottom"
                height={36}
                formatter={(value) => <span className={`text-xs px-1 font-semibold ${lightMode ? "text-slate-600" : "text-slate-300"}`}>{value}</span>}
              />
              <Bar name="امتیاز پویایی تیمی" dataKey="score" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className={`grid grid-cols-2 md:grid-cols-5 gap-3 border-t pt-4 text-center ${
        lightMode ? "border-slate-100" : "border-slate-900"
      }`}>
        {chartData.map((item) => {
          return (
            <div key={item.subject} className={`rounded-xl p-2.5 ${
              lightMode ? "bg-slate-50 border border-slate-150" : "bg-slate-950/40 border border-slate-900"
            }`}>
              <p className={`text-[10px] font-medium truncate ${lightMode ? "text-slate-500" : "text-slate-400"}`}>{item.subject}</p>
              <div className="flex items-baseline justify-center gap-1.5 mt-1 font-mono">
                <span className={`text-sm font-bold ${lightMode ? "text-amber-600" : "text-amber-400"}`}>{item.score}</span>
                <span className={`text-[10px] ${lightMode ? "text-slate-400" : "text-slate-550"}`}>/ ۱۰</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
