/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Event, Team, PresentationSlide, SCORE_LABELS } from "../types";
import {
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Sparkles,
  Award,
  TrendingUp,
  AlertCircle,
  Compass,
  Briefcase,
  Flag,
  Tv,
  ArrowLeft,
  X,
  Volume2,
} from "lucide-react";
import DebriefChart from "./DebriefChart";

interface ProjectorViewProps {
  eventId: string;
  teamId: string;
  onExit: () => void;
}

export default function ProjectorView({ eventId, teamId, onExit }: ProjectorViewProps) {
  const [event, setEvent] = useState<Event | null>(null);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [showPresenterNotes, setShowPresenterNotes] = useState(false);

  // Load event on mount
  useEffect(() => {
    const saved = localStorage.getItem("comzee_events");
    if (saved) {
      try {
        const eventsList: Event[] = JSON.parse(saved);
        const found = eventsList.find((e) => e.id === eventId);
        if (found) {
          setEvent(found);
        }
      } catch (e) {
        console.error("Error loading events for projector:", e);
      }
    }
  }, [eventId]);

  const activeTeam = event?.teams.find((t) => t.id === teamId) || null;
  const analysis = event?.analyses ? event.analyses[teamId] : null;

  // Generate fallback slides if none generated yet
  const slides: PresentationSlide[] = analysis?.slides || [
    {
      id: 1,
      title: "دیبریف و ارزیابی پویایی‌های تیمی",
      subtitle: "رویداد توسعه پویایی تیمی کامزی",
      type: "title",
      content: ["خوش‌آمدگویی به اعضای تیم", "تمرکز بر یادگیری‌های شبیه‌سازی", "توافق بر اقدامات بهبود"]
    },
    {
      id: 2,
      title: "ارزیابی آماری پویایی‌های تیمی کامزی",
      subtitle: "میزان توسعه‌یافتگی ابعاد کلیدی کار تیمی",
      type: "chart",
      content: []
    }
  ];

  const currentSlide = slides[currentSlideIndex];

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") {
        handlePrev(); // RTL: Right arrow goes to previous slide
      } else if (e.key === "ArrowLeft" || e.key === " ") {
        handleNext(); // RTL: Left arrow/Space goes to next slide
      } else if (e.key.toLowerCase() === "h" || e.key === "ا" || e.key === "آ") {
        setShowPresenterNotes((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentSlideIndex, slides.length]);

  const handleNext = () => {
    if (currentSlideIndex < slides.length - 1) {
      setCurrentSlideIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentSlideIndex > 0) {
      setCurrentSlideIndex((prev) => prev - 1);
    }
  };

  // Icon mapping
  const getSlideIcon = (type: string) => {
    switch (type) {
      case "title":
        return <Sparkles className="w-12 h-12 text-amber-400" />;
      case "chart":
        return <TrendingUp className="w-12 h-12 text-emerald-400" />;
      case "strengths":
        return <Award className="w-12 h-12 text-emerald-400" />;
      case "weaknesses":
        return <AlertCircle className="w-12 h-12 text-rose-500" />;
      case "recommendations":
        return <Compass className="w-12 h-12 text-sky-400" />;
      case "workspace":
        return <Briefcase className="w-12 h-12 text-amber-500" />;
      case "closing":
        return <Flag className="w-12 h-12 text-purple-400" />;
      default:
        return <Sparkles className="w-12 h-12 text-amber-400" />;
    }
  };

  const getPresenterNotes = (type: string) => {
    switch (type) {
      case "title":
        return "به تیم تبریک بگویید و اهمیت فاز دیبریف را تشریح کنید. یادآوری کنید که هدف دیبریف، قضاوت یا مقصریابی نیست، بلکه هم‌افزایی است.";
      case "chart":
        return "نمودار پویایی‌های تیمی را باز کرده و اجازه دهید ابتدا خود اعضا پویایی‌های کار تیمی را تحلیل کنند.";
      case "strengths":
        return "روی شواهد رفتاری واقعی که ثبت کرده‌اید مانور دهید و حس موفقیت جمعی را تقویت کنید.";
      case "weaknesses":
        return "چالش‌ها را به عنوان عارضه سیستمیک تیم مطرح کنید نه فردی. ریشه‌یابی کنید.";
      case "recommendations":
        return "بینش‌های تسهیل‌گری کامزی را برای بهبود پویایی و پیاده‌سازی در شرکت بازگو کنید.";
      case "workspace":
        return "تمرکز را ببرید روی اقدامات عملی و ملموسی که شنبه صبح اعضا باید روی میز کار خود ببرند.";
      case "closing":
        return "ارائه را با یک عهد تیمی محکم و با انرژی عاطفی بالا به پایان برسانید.";
      default:
        return "";
    }
  };

  if (!event || !activeTeam) {
    return (
      <div className="min-h-screen bg-[#06080a] text-slate-100 flex flex-col justify-center items-center p-8 font-sans dir-rtl">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-500 mb-4"></div>
        <p className="text-slate-400">در حال فراخوانی داده‌های دیبریف کلاینت...</p>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-[#06080a] text-slate-100 flex flex-col font-sans dir-rtl overflow-hidden select-none z-50">
      {/* Decorative ambient glowing circles */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-600/5 rounded-full blur-3xl pointer-events-none" />

      {/* Top Professional Header Bar */}
      <header className="bg-[#0b0f14]/80 backdrop-blur-md border-b border-slate-900/80 px-8 py-4 flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-4">
          <div className="bg-amber-500 text-slate-950 font-black text-[11px] px-3.5 py-1 rounded-full tracking-wider uppercase flex items-center gap-1">
            <Tv className="w-3.5 h-3.5" />
            حالت مستقل پروژکتور (بدون امکان ویرایش)
          </div>
          <span className="text-sm font-bold text-slate-300">
            {event.clientName} • تیم {activeTeam.name}
          </span>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setShowPresenterNotes((n) => !n)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              showPresenterNotes
                ? "bg-amber-500/20 text-amber-400 border border-amber-500/40"
                : "bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            <Volume2 className="w-4 h-4" />
            راهنمای تسهیل‌گر {showPresenterNotes ? "(فعال)" : "(H)"}
          </button>
          
          <button
            onClick={onExit}
            className="px-4 py-2 bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white border border-rose-500/20 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <X className="w-4 h-4" />
            خروج از صفحه ارائه
          </button>
        </div>
      </header>

      {/* Main Slides Content Section */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden relative">
        {/* Active Presentation Canvas */}
        <div className="flex-1 flex flex-col justify-center items-center p-8 lg:p-16 min-h-0 overflow-y-auto relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide.id}
              initial={{ opacity: 0, scale: 0.96, x: -30 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.96, x: 30 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              className="w-full max-w-5xl bg-slate-950/60 backdrop-blur-xl border-t-4 border-t-amber-500 border border-slate-900 rounded-[32px] p-10 lg:p-14 shadow-2xl relative overflow-hidden flex flex-col justify-between min-h-[500px]"
            >
              {/* Slide Icon and Title */}
              <div className="flex items-center gap-5 mb-8">
                <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl shadow-inner">
                  {getSlideIcon(currentSlide.type)}
                </div>
                <div>
                  <h1 className="font-extrabold text-3xl lg:text-4xl text-white tracking-tight leading-snug">
                    {currentSlide.title}
                  </h1>
                  {currentSlide.subtitle && (
                    <p className="text-slate-400 text-base mt-1.5">{currentSlide.subtitle}</p>
                  )}
                </div>
              </div>

              {/* Slide Main Body Area */}
              <div className="flex-1 flex flex-col justify-center min-h-0 mb-10">
                {currentSlide.type === "title" && (
                  <div className="text-center py-8 space-y-8">
                    <div className="inline-block">
                      <h2 className="text-5xl font-black text-amber-400 leading-tight">کامزی | کارگاه توسعه پویایی تیمی</h2>
                      <p className="text-slate-300 text-lg mt-4 max-w-2xl mx-auto leading-relaxed">
                        بازی‌ها و چالش‌ها پایان یافته است. اکنون داده‌ها داستان کار تیمی و مسیر رشد عقاب‌ها را بازگو می‌کنند.
                      </p>
                    </div>
                    
                    <div className="grid grid-cols-2 max-w-md mx-auto gap-5 pt-4 text-right">
                      <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-900">
                        <span className="text-xs text-slate-500">سازمان مخاطب</span>
                        <p className="text-sm font-bold text-slate-200 mt-1">{event.clientName}</p>
                      </div>
                      <div className="bg-[#0b0f14] p-4 rounded-2xl border border-slate-900">
                        <span className="text-xs text-slate-500">تیم ارزیابی</span>
                        <p className="text-sm font-bold text-slate-200 mt-1">تیم {activeTeam.name}</p>
                      </div>
                    </div>
                  </div>
                )}

                {currentSlide.type === "chart" && (
                  <div className="w-full flex items-center justify-center py-2 animate-fade-in">
                    <div className="w-full max-w-3xl bg-slate-950/20 border border-slate-900/40 rounded-3xl p-4">
                      {/* Using the newly upgraded DebriefChart showing post/current scores */}
                      <DebriefChart postScores={activeTeam.postScores} teamName={activeTeam.name} />
                    </div>
                  </div>
                )}

                {currentSlide.type !== "title" && currentSlide.type !== "chart" && (
                  <ul className="space-y-5 lg:space-y-6 text-right">
                    {currentSlide.content.map((bullet, idx) => (
                      <motion.li
                        key={idx}
                        initial={{ opacity: 0, x: -30 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.12 + 0.15 }}
                        className="flex items-start gap-4 bg-slate-950/40 hover:bg-slate-950/80 border border-slate-900/80 p-5 rounded-2xl transition-colors"
                      >
                        <span className="flex-shrink-0 w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-sm font-bold font-mono mt-0.5">
                          {idx + 1}
                        </span>
                        <p className="text-slate-200 text-lg md:text-xl leading-relaxed font-semibold">
                          {bullet}
                        </p>
                      </motion.li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Slide Bottom Signature and Branding */}
              <footer className="flex items-center justify-between border-t border-slate-900 pt-6 text-slate-500 text-xs">
                <span>تسهیل‌گری خلاق و داده‌محور کامزی</span>
                <span className="font-mono text-sm font-bold text-slate-400">
                  اسلاید {currentSlideIndex + 1} از {slides.length}
                </span>
                <span>comzee.ir</span>
              </footer>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Presenter Sidebar Guide */}
        <AnimatePresence>
          {showPresenterNotes && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: "380px", opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="border-r border-slate-900 bg-[#080b0f] w-full max-w-[380px] flex flex-col overflow-hidden shrink-0"
            >
              <div className="p-5 border-b border-slate-900 bg-slate-950/60 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse" />
                  <span className="font-extrabold text-sm text-slate-200">راهنما و سوالات دیبریف تسهیل‌گر</span>
                </div>
              </div>

              <div className="flex-1 p-6 overflow-y-auto space-y-6 text-slate-300 text-right text-xs leading-relaxed">
                <div className="space-y-2">
                  <span className="text-[10px] text-amber-400 font-black tracking-wider uppercase block">هدف تسهیل‌گر در این اسلاید:</span>
                  <p className="bg-slate-950 border border-slate-900 p-4 rounded-xl text-slate-300 leading-relaxed text-sm">
                    {getPresenterNotes(currentSlide.type)}
                  </p>
                </div>

                <div className="bg-slate-950/60 border border-slate-900 rounded-2xl p-4 space-y-2">
                  <strong className="text-emerald-400 text-xs">نمونه سوالات هدایت گفتگو (ORID):</strong>
                  <ul className="space-y-2 text-slate-300 text-xs list-disc list-inside leading-relaxed">
                    {currentSlide.type === "chart" && (
                      <>
                        <li>چه شاخصی بیشترین جهش را داشته است؟</li>
                        <li>چرا ارتباطات تیم در فاز دوم صعود کرده است؟</li>
                      </>
                    )}
                    {currentSlide.type === "strengths" && (
                      <>
                        <li>چه حسی داشتید وقتی هماهنگی کامل برقرار شد؟</li>
                        <li>عامل اصلی این موفقیت رفتاری چه بود؟</li>
                      </>
                    )}
                    {currentSlide.type === "weaknesses" && (
                      <>
                        <li>کجا احساس ناهماهنگی یا ابهام کردید؟</li>
                        <li>تنش‌های رفتاری چطور حل شد؟</li>
                      </>
                    )}
                    {currentSlide.type !== "chart" && currentSlide.type !== "strengths" && currentSlide.type !== "weaknesses" && (
                      <>
                        <li>چطور این فرمول را شنبه صبح در شرکت پیاده می‌کنید؟</li>
                        <li>بزرگ‌ترین درس‌آموخته شما چیست؟</li>
                      </>
                    )}
                  </ul>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Professional Slide Navigation Dock */}
      <footer className="bg-[#0b0f14]/90 border-t border-slate-950 py-5 px-8 flex items-center justify-between z-10 shrink-0">
        <button
          onClick={() => setCurrentSlideIndex(0)}
          disabled={currentSlideIndex === 0}
          className="p-3 bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none rounded-xl transition-all cursor-pointer"
          title="بازگشت به اولین اسلاید"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-4">
          <button
            onClick={handlePrev}
            disabled={currentSlideIndex === 0}
            className="px-5 py-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none text-slate-300 font-extrabold text-xs rounded-xl flex items-center gap-2 transition-all cursor-pointer border border-slate-800"
          >
            <ChevronRight className="w-4 h-4" />
            اسلاید قبل
          </button>

          <span className="text-xs font-black text-slate-400 font-mono px-3">
            {currentSlideIndex + 1} / {slides.length}
          </span>

          <button
            onClick={handleNext}
            disabled={currentSlideIndex === slides.length - 1}
            className="px-6 py-3 bg-amber-500 hover:bg-amber-400 disabled:opacity-30 disabled:pointer-events-none text-slate-950 font-black text-xs rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-md shadow-amber-500/10"
          >
            اسلاید بعد
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        <div className="text-[11px] text-slate-500 font-semibold hidden sm:block">
          برای جابجایی می‌توانید از کلیدهای ➔ و ⬅ کیبورد یا فاصله (Space) استفاده کنید
        </div>
      </footer>
    </div>
  );
}
