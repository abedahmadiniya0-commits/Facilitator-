/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PresentationSlide, TeamScores, SCORE_LABELS, Team } from "../types";
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Volume2,
  X,
  Play,
  RotateCcw,
  Sparkles,
  Award,
  TrendingUp,
  AlertCircle,
  Compass,
  Briefcase,
  Flag,
} from "lucide-react";
import DebriefChart from "./DebriefChart";
import ActionPlanTracker from "./ActionPlanTracker";

interface DebriefPresentationProps {
  slides: PresentationSlide[];
  preScores: TeamScores;
  postScores: TeamScores;
  teamName: string;
  clientName: string;
  onClose: () => void;
  team?: Team;
  onUpdateActionPlan?: (plan: any) => void;
}

export default function DebriefPresentation({
  slides,
  preScores,
  postScores,
  teamName,
  clientName,
  onClose,
  team,
  onUpdateActionPlan,
}: DebriefPresentationProps) {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showPresenterNotes, setShowPresenterNotes] = useState(true);

  const currentSlide = slides[currentSlideIndex];

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") {
        handlePrev(); // RTL: Right arrow goes to previous slide
      } else if (e.key === "ArrowLeft") {
        handleNext(); // RTL: Left arrow goes to next slide
      } else if (e.key === "Escape" && isFullscreen) {
        setIsFullscreen(false);
      } else if (e.key.toLowerCase() === "h" || e.key === "ا" || e.key === "آ") {
        setShowPresenterNotes((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentSlideIndex, isFullscreen]);

  const handleNext = () => {
    if (currentSlideIndex < slides.length - 1) {
      setCurrentSlideIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentSlideIndex > 0) {
      setCurrentSlideIndex((prev) => prev - 1);
    }
  };

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // Get slide visual styling/icons based on slide type
  const getSlideIcon = (type: string) => {
    switch (type) {
      case "title":
        return <Sparkles className="w-10 h-10 text-amber-400" />;
      case "chart":
        return <TrendingUp className="w-10 h-10 text-emerald-400" />;
      case "strengths":
        return <Award className="w-10 h-10 text-emerald-400" />;
      case "weaknesses":
        return <AlertCircle className="w-10 h-10 text-rose-500" />;
      case "recommendations":
        return <Compass className="w-10 h-10 text-sky-400" />;
      case "workspace":
        return <Briefcase className="w-10 h-10 text-amber-500" />;
      case "closing":
        return <Flag className="w-10 h-10 text-purple-400" />;
      default:
        return <Sparkles className="w-10 h-10 text-amber-400" />;
    }
  };

  // Automated presenter questions based on ORID framework for each slide type
  const getPresenterGuide = (type: string) => {
    switch (type) {
      case "title":
        return {
          framework: "خوش‌آمدگویی و مقدمه",
          objective: "به تیم بابت تلاش‌هایشان در بازی تبریک بگویید و اعلام کنید که بازی تمام شده و الان نوبت استخراج ارزشمندترین بخش یعنی 'تجربه و درس‌ها' است.",
          questions: [
            "احساس کلی شما بعد از اتمام بازی‌ها چیست؟",
            "چارچوب دیبریف را توضیح دهید: هیچ قضاوتی نیست، هدف رشد است."
          ]
        };
      case "chart":
        return {
          framework: "تحلیل عینی داده‌ها (O - Objective)",
          objective: "نمودار مقایسه‌ای را به تیم نشان دهید. اجازه دهید خودشان ابتدا تفاوت نمرات قبل و بعد را ببینند و تحلیل کنند.",
          questions: [
            "چه چیزی در نمودار توجه شما را جلب می‌کند؟",
            "بیشترین میزان جهش یا سقوط نمره در کدام شاخص تیمی بوده است؟ چرا؟"
          ]
        };
      case "strengths":
        return {
          framework: "انعکاس احساسات و شواهد موفقیت (R - Reflective)",
          objective: "روی نقاط قوت تمرکز کنید. بگذارید طعم شیرین پیروزی‌ها و هماهنگی‌های خوب را دوباره مزه کنند.",
          questions: [
            "کجا احساس کردید به عنوان یک تیم کاملاً هماهنگ و یکپارچه هستید؟",
            "کدام رفتار یا حرف یکی از اعضا، جریان کل بازی را به سمت مثبت تغییر داد؟"
          ]
        };
      case "weaknesses":
        return {
          framework: "تفسیر و ریشه‌یابی چالش‌ها (I - Interpretive)",
          objective: "وارد چالش‌ها شوید. به هیچ وجه تقصیر را گردن فرد خاصی نیندازید. چالش را متعلق به ساختار و کل سیستم تیم بدانید.",
          questions: [
            "کجا و چرا کنترل از دست ما خارج شد؟",
            "چه فشارهایی (مثل زمان، قانون، ابهام) پویایی تیم ما را دچار اختلال کرد؟"
          ]
        };
      case "recommendations":
        return {
          framework: "ارائه بینش توسعه (I - Interpretive)",
          objective: "بینش‌های تسهیل‌گری کامزی را ارائه دهید. کمک کنید متوجه ارتباط عمیق الگوهای بازی با رفتار سازمانی‌شان بشوند.",
          questions: [
            "آیا پدیده‌ای که در بازی دیدیم، در تصمیم‌گیری‌های هفتگی شرکت هم اتفاق می‌افتد؟",
            "تسهیم اطلاعات چطور در کارهای پروژه‌ای واقعی شما جریان دارد؟"
          ]
        };
      case "workspace":
        return {
          framework: "برنامه اقدام و انتقال به کار (D - Decisive)",
          objective: "به سمت تصمیم‌گیری بروید. از کلی‌گویی دوری کنید و تعهدات بسیار کوچک ولی مستمر بسازید.",
          questions: [
            "شنبه صبح که به شرکت می‌روید، چه فرمولی از این رویداد را روی میز کار خود پیاده می‌کنید؟",
            "کدام رفتار مخربِ بازی را همین‌جا دفن می‌کنیم و با خود به سازمان نمی‌بریم؟"
          ]
        };
      case "closing":
        return {
          framework: "تعهد تیمی و عهد نهایی (D - Decisive)",
          objective: "رویداد را پرانرژی و عاطفی تمام کنید. یک عهد جمعی یا فریاد تیمی ترتیب دهید.",
          questions: [
            "تیم ما در یک کلمه از امروز به بعد چه تیمی است؟",
            "دست‌ها را روی هم بگذارید و عهد تیمی جدید کامزی را تکرار کنید."
          ]
        };
      default:
        return {
          framework: "راهنمای تسهیل‌گری",
          objective: "تسهیل و راهبری موثر این بخش از دیبریف.",
          questions: ["هدف تیمی چیست؟", "چگونه بهبود یابیم؟"]
        };
    }
  };

  const currentGuide = getPresenterGuide(currentSlide.type);

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-[#0c0e12] via-[#08090b] to-[#040405] text-slate-100 z-50 flex flex-col font-sans dir-rtl overflow-hidden select-none">
      {/* Slide Header */}
      <div className="bg-slate-900/40 backdrop-blur-md border-b border-slate-900/80 px-6 py-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <div className="bg-amber-500 text-slate-950 font-black text-[10px] px-3 py-1 rounded-full tracking-wider uppercase">
            دیبریف اختصاصی کامزی
          </div>
          <span className="text-xs sm:text-sm font-semibold text-slate-300">
            {clientName} • {teamName === "all_teams" ? "خلاصه کل تیم‌ها" : `تیم ${teamName}`}
          </span>
        </div>
        
        {/* Progress Bar */}
        <div className="flex-1 max-w-md mx-8 hidden md:block">
          <div className="bg-slate-800/60 h-1.5 rounded-full overflow-hidden border border-slate-900">
            <div
              className="bg-gradient-to-l from-amber-500 to-yellow-400 h-full transition-all duration-300 shadow-[0_0_8px_rgba(245,158,11,0.5)]"
              style={{ width: `${((currentSlideIndex + 1) / slides.length) * 100}%` }}
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowPresenterNotes((p) => !p)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              showPresenterNotes 
                ? "bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-[0_0_12px_rgba(245,158,11,0.1)]" 
                : "bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
            title="نمایش/پنهان‌سازی راهنمای تسهیل‌گر (کلید میانبر H)"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>{showPresenterNotes ? "پنهان‌سازی راهنما (H)" : "نمایش راهنمای تسهیل‌گر (H)"}</span>
          </button>
          
          <button
            onClick={toggleFullscreen}
            className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-lg transition-colors"
            title="تمام صفحه"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          <button
            onClick={onClose}
            className="p-2 bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white border border-rose-500/20 rounded-lg transition-all"
            title="خروج از ارائه"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Active Presentation Canvas */}
        <div className="flex-1 flex flex-col justify-center items-center p-6 lg:p-12 min-h-0 overflow-y-auto relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide.id}
              initial={{ opacity: 0, x: -60, scale: 0.98 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 60, scale: 0.98 }}
              transition={{ duration: 0.35, ease: "easeInOut" }}
              className={`w-full ${currentSlide.type === "workspace" ? "max-w-5xl" : "max-w-4xl"} bg-slate-950/60 backdrop-blur-xl border-t-2 border-t-amber-500/80 border border-slate-900/80 rounded-3xl p-8 lg:p-12 shadow-2xl relative overflow-hidden flex flex-col justify-between min-h-[480px] max-h-full`}
            >
              {/* Background Glows */}
              <div className="absolute -top-40 -left-40 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-amber-600/5 rounded-full blur-3xl pointer-events-none" />

              {/* Slide Meta / Header */}
              <div className="flex items-center gap-4 mb-8">
                <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-2xl shadow-inner">
                  {getSlideIcon(currentSlide.type)}
                </div>
                <div>
                  <h1 className="font-extrabold text-2xl lg:text-3xl text-white tracking-tight leading-snug">
                    {currentSlide.title}
                  </h1>
                  {currentSlide.subtitle && (
                    <p className="text-slate-400 text-sm mt-1">{currentSlide.subtitle}</p>
                  )}
                </div>
              </div>

              {/* Dynamic Slide Layouts based on Slide Type */}
              <div className="flex-1 flex flex-col justify-center min-h-0 mb-8">
                {currentSlide.type === "title" && (
                  <div className="text-center py-6 space-y-6">
                    <motion.div
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ delay: 0.2 }}
                      className="inline-block mx-auto"
                    >
                      <img
                        src="https://comzee.ir/wp-content/uploads/2021/04/comzee-logo.png"
                        alt="Comzee"
                        className="h-16 mx-auto opacity-80 invert brightness-200"
                        onError={(e) => {
                          // Fallback to text if image fails or offline
                          e.currentTarget.style.display = "none";
                        }}
                      />
                      <h2 className="text-4xl font-black text-amber-400 mt-4 leading-tight">کامزی | کارگاه یادگیری تجربی</h2>
                    </motion.div>
                    <p className="text-slate-300 text-base max-w-2xl mx-auto leading-relaxed">
                      بازی‌ها و چالش‌ها به پایان رسیدند. اکنون زمان آن است که ارزشمندترین بخش یعنی گوهر عمیق یادگیری را با تکیه بر داده‌ها استخراج کنیم.
                    </p>
                    <div className="grid grid-cols-2 max-w-md mx-auto gap-4 pt-4 text-right">
                      <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-900">
                        <span className="text-[10px] text-slate-500">سازمان مخاطب</span>
                        <p className="text-xs font-bold text-slate-300 mt-1">{clientName}</p>
                      </div>
                      <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-900">
                        <span className="text-[10px] text-slate-500">تیم ارزیابی</span>
                        <p className="text-xs font-bold text-slate-300 mt-1">تیم {teamName}</p>
                      </div>
                    </div>
                  </div>
                )}

                {currentSlide.type === "chart" && (
                  <div className="w-full flex items-center justify-center py-2">
                    <div className="w-full max-w-2xl bg-slate-950/20 border border-slate-950/40 rounded-2xl p-2">
                      <DebriefChart postScores={postScores} teamName={teamName} />
                    </div>
                  </div>
                )}

                {currentSlide.type === "workspace" && team && onUpdateActionPlan ? (
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start text-right">
                    <div className="md:col-span-5 space-y-4">
                      <span className="text-xs font-bold text-amber-400 block pb-1 border-b border-slate-900">
                        بینش‌ها و تعهدات کلیدی پیشنهادی کامزی:
                      </span>
                      <ul className="space-y-3">
                        {currentSlide.content.map((bullet, idx) => (
                          <motion.li
                            key={idx}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.1 + 0.1 }}
                            className="flex items-start gap-2.5 bg-slate-900/30 border border-slate-900/60 p-3 rounded-xl"
                          >
                            <span className="flex-shrink-0 w-5 h-5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono mt-0.5">
                              {idx + 1}
                            </span>
                            <p className="text-slate-300 text-xs leading-relaxed">
                              {bullet}
                            </p>
                          </motion.li>
                        ))}
                      </ul>
                    </div>
                    
                    <div className="md:col-span-7">
                      <ActionPlanTracker
                        team={team}
                        defaultSuggestions={currentSlide.content.map(bullet => ({
                          actionableStep: bullet,
                          officeApplication: "کاربرد مستقیم در دفتر کار"
                        }))}
                        onUpdateActionPlan={onUpdateActionPlan}
                      />
                    </div>
                  </div>
                ) : currentSlide.type !== "title" && currentSlide.type !== "chart" && (
                  <ul className="space-y-4 md:space-y-6 text-right">
                    {currentSlide.content.map((bullet, idx) => (
                      <motion.li
                        key={idx}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.15 + 0.2 }}
                        className="flex items-start gap-3.5 bg-slate-950/20 hover:bg-slate-950/40 border border-slate-900 p-4 rounded-2xl transition-colors"
                      >
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-xs font-bold font-mono mt-1">
                          {idx + 1}
                        </span>
                        <p className="text-slate-200 text-sm md:text-base leading-relaxed font-medium">
                          {bullet}
                        </p>
                      </motion.li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Slide Footer */}
              <div className="flex items-center justify-between border-t border-slate-900 pt-6 text-slate-500 text-xs">
                <span>رویداد بازآفرینی پویایی تیمی کامزی</span>
                <span className="font-mono">
                  اسلاید {currentSlideIndex + 1} از {slides.length}
                </span>
                <span>comzee.ir</span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Presenter Notes & Teleprompter Drawer */}
        <AnimatePresence>
          {showPresenterNotes && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: "100%", opacity: 1, maxWidth: "380px" }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="border-t lg:border-t-0 lg:border-r border-slate-900 bg-slate-900/40 w-full lg:max-w-[380px] flex flex-col overflow-hidden min-h-[220px] lg:min-h-0"
            >
              <div className="p-5 border-b border-slate-900 bg-slate-900/60 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-pulse" />
                  <span className="font-bold text-sm text-slate-200">کابین تسهیل‌گر (Presenter Guide)</span>
                </div>
                <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">
                  {currentGuide.framework}
                </span>
              </div>

              <div className="flex-1 p-5 overflow-y-auto space-y-5 text-slate-300 text-right text-xs leading-relaxed">
                <div className="space-y-1.5">
                  <span className="text-[10px] text-amber-400 font-bold tracking-wider">هدف تسهیل‌گری در این اسلاید:</span>
                  <p className="bg-slate-950/60 border border-slate-900 p-3 rounded-xl text-slate-300 text-[11px] leading-relaxed">
                    {currentGuide.objective}
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] text-emerald-400 font-bold tracking-wider">سوالات کلیدی و محرک گفتگو (ORID Prompt Questions):</span>
                  <div className="space-y-2">
                    {currentGuide.questions.map((question, qIdx) => (
                      <div
                        key={qIdx}
                        className="flex gap-2.5 items-start bg-slate-950/30 border border-slate-900/60 p-3 rounded-xl text-slate-200 font-medium"
                      >
                        <span className="text-amber-400 font-bold mt-0.5 font-mono">؟</span>
                        <p>{question}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-950/60 border border-slate-900 rounded-xl p-3 space-y-1.5 text-[10px] text-slate-400">
                  <strong className="text-slate-300">نکته حرفه‌ای تسهیل‌گری کامزی:</strong>
                  <p>
                    در صورت برخورد تیم با گارد دفاعی، به این نکته اشاره کنید که «نتیجه هر چه باشد، تمام تصمیمات بر اساس بهترین نیت اعضا در آن لحظه بوده است». روی پیشرفت تمرکز کنید.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Control Navigation Console */}
      <div className="bg-slate-900/80 border-t border-slate-950 py-4 px-6 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentSlideIndex(0)}
            disabled={currentSlideIndex === 0}
            className="p-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none text-slate-300 rounded-lg transition-colors"
            title="شروع مجدد اسلایدها"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handlePrev}
            disabled={currentSlideIndex === 0}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none text-slate-300 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
            اسلاید قبل
          </button>

          <span className="text-xs text-slate-400 font-semibold px-2 font-mono">
            {currentSlideIndex + 1} / {slides.length}
          </span>

          <button
            onClick={handleNext}
            disabled={currentSlideIndex === slides.length - 1}
            className="px-5 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-30 disabled:pointer-events-none text-slate-950 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all shadow-md hover:shadow-amber-500/10"
          >
            اسلاید بعد
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        <div className="text-[10px] text-slate-500 font-medium hidden sm:block">
          با کلیدهای چپ و راست کیبورد حرکت کنید
        </div>
      </div>
    </div>
  );
}
