import React, { useState, useRef, useEffect } from "react";
import { 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  RotateCcw, 
  Tv, 
  HelpCircle, 
  Check, 
  Copy, 
  Play, 
  AlertCircle,
  Eye,
  FileText,
  Volume2
} from "lucide-react";

interface Message {
  id: string;
  sender: "assistant" | "user";
  text: string;
  timestamp: string;
  isProjector?: boolean;
}

export default function ComzeeAssistant() {
  // Stepper state: 1, 2, 3, 4
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);
  
  // Collected inputs
  const [context, setContext] = useState("");
  const [observations, setObservations] = useState("");
  const [analysis, setAnalysis] = useState("");
  const [projectorOutput, setProjectorOutput] = useState("");
  
  // Conversational message history
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      sender: "assistant",
      text: "درود تسهیل‌گر ارشد کامزی. به دستیار هوشمند دیبریف خوش آمدید. من همراه شما هستم تا مشاهدات و خروجی‌های کارگاه‌های جدی شما را برای ارائه روی پروژکتور آماده کنم.\n\nلطفاً **نام بازی جدی** و **هدف اصلی این جلسه دیبریف** را بفرمایید:",
      timestamp: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })
    }
  ]);
  
  // Text area / input field state
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Ref for auto-scrolling
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  // Focus input field on step change
  useEffect(() => {
    inputRef.current?.focus();
  }, [currentStep]);

  // Helper to get step-specific questions
  const getStepQuestion = (step: 1 | 2 | 3 | 4): string => {
    switch (step) {
      case 1:
        return "لطفاً **نام بازی جدی** و **هدف اصلی این جلسه دیبریف** را بفرمایید:";
      case 2:
        return "مفهومه. اطلاعات بازی با موفقیت ثبت شد. حالا لطفاً **مشاهدات کلیدی** خود را از رفتارها و چالش‌های تیم‌ها در طول این شبیه‌سازی بنویسید:";
      case 3:
        return "بسیار عالی. مشاهدات شما با موفقیت ثبت شد. در گام سوم، بر اساس متدولوژی دیبریف (شامل لایه‌های عمیق ORID: واقعیت‌ها، احساسات تیمی، تحلیل‌ها یا تصمیماتشان)، چه نکات یا بازخوردهایی ثبت کرده‌اید؟";
      case 4:
        return "سپاسگزارم. تمام داده‌های لازم جمع‌آوری شد. در حال تولید خروجی لوکس پروژکتور هستیم...";
    }
  };

  // State rollback (Virtual Back Button)
  const handleGoBack = () => {
    if (currentStep === 1) return;
    
    // Determine target step
    const prevStep = (currentStep - 1) as 1 | 2 | 3 | 4;
    
    // Revert state variables & populate input value with previous data
    let restoredValue = "";
    if (prevStep === 1) {
      restoredValue = context;
    } else if (prevStep === 2) {
      restoredValue = observations;
    } else if (prevStep === 3) {
      restoredValue = analysis;
    }

    setCurrentStep(prevStep);
    setInputValue(restoredValue);

    // Add rollback notification to chat log
    setMessages(prev => [
      ...prev,
      {
        id: `back-to-${prevStep}-${Date.now()}`,
        sender: "assistant",
        text: `مفهومه. به یک قدم قبل (گام ${prevStep}) برگشتیم. لطفاً پاسخ قبلی را مجدداً وارد یا اصلاح کنید:`,
        timestamp: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })
      }
    ]);
  };

  // Submit current answer
  const handleSubmitAnswer = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    const trimmedInput = inputValue.trim();
    if (!trimmedInput && !isLoading) return;

    // Check for rollback keywords: [برگشت] , [مرحله قبل] , [اصلاح]
    const lowercaseInput = trimmedInput.toLowerCase();
    if (
      lowercaseInput === "[برگشت]" || 
      lowercaseInput === "برگشت" || 
      lowercaseInput === "[مرحله قبل]" || 
      lowercaseInput === "مرحله قبل" || 
      lowercaseInput === "[اصلاح]" || 
      lowercaseInput === "اصلاح"
    ) {
      handleGoBack();
      return;
    }

    // Check for direct projector keyword: [خروجی نهایی]
    if (lowercaseInput === "[خروجی نهایی]" || lowercaseInput === "خروجی نهایی") {
      triggerProjectorGeneration();
      return;
    }

    // Append user message to chat history
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: trimmedInput,
      timestamp: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })
    };
    
    setMessages(prev => [...prev, userMsg]);
    setInputValue("");
    setError(null);

    // Save corresponding step data and transition
    if (currentStep === 1) {
      setContext(trimmedInput);
      setCurrentStep(2);
      
      // AI simulated response for transition
      setTimeout(() => {
        setMessages(prev => [
          ...prev,
          {
            id: `assist-step2-${Date.now()}`,
            sender: "assistant",
            text: getStepQuestion(2),
            timestamp: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })
          }
        ]);
      }, 600);

    } else if (currentStep === 2) {
      setObservations(trimmedInput);
      setCurrentStep(3);
      
      setTimeout(() => {
        setMessages(prev => [
          ...prev,
          {
            id: `assist-step3-${Date.now()}`,
            sender: "assistant",
            text: getStepQuestion(3),
            timestamp: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })
          }
        ]);
      }, 600);

    } else if (currentStep === 3) {
      setAnalysis(trimmedInput);
      setCurrentStep(4);
      
      // Auto trigger Projector generation because all data is completed!
      triggerProjectorGeneration(trimmedInput);
    }
  };

  // Generate Projector Slide
  const triggerProjectorGeneration = async (overrideAnalysis?: string) => {
    setIsLoading(true);
    setError(null);
    
    // Add transition notification in chat log
    setMessages(prev => [
      ...prev,
      {
        id: `assist-projector-start-${Date.now()}`,
        sender: "assistant",
        text: "بسیار عالی. در حال تنظیم و پردازش نهایی اسلاید دیجیتال شما هستم. لطفاً شکیبا باشید...",
        timestamp: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })
      }
    ]);

    try {
      const finalContext = context;
      const finalObservations = observations;
      const finalAnalysis = overrideAnalysis !== undefined ? overrideAnalysis : analysis;

      const response = await fetch("/api/debrief/assistant-projector", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context: finalContext || "بازی جدی شبیه‌سازی",
          observations: finalObservations || "مشاهدات پویایی تیمی تسهیل‌گر",
          analysis: finalAnalysis || "درس‌آموخته‌های اولیه و تحلیل‌های ORID"
        })
      });

      if (!response.ok) {
        throw new Error("خطا در پاسخ‌دهی سرور. لطفاً مجدداً تلاش کنید.");
      }

      const data = await response.json();
      setProjectorOutput(data.result);
      setCurrentStep(4);

      setMessages(prev => [
        ...prev,
        {
          id: `assist-projector-done-${Date.now()}`,
          sender: "assistant",
          text: "🎉 خروجی ویژه پروژکتور با موفقیت آماده شد! هم‌اکنون می‌توانید آن را بر روی پرده بیندازید.",
          timestamp: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" }),
          isProjector: true
        }
      ]);
    } catch (err: any) {
      setError(err.message || "برقراری ارتباط با هوش مصنوعی کامزی ناموفق بود.");
    } finally {
      setIsLoading(false);
    }
  };

  // Quick action tags helper to add to the input
  const handleAddQuickObservation = (text: string) => {
    setInputValue(prev => {
      const separator = prev ? " • " : "";
      return prev + separator + text;
    });
    inputRef.current?.focus();
  };

  // Reset entire assistant state to start over
  const handleReset = () => {
    if (window.confirm("آیا مایلید تمام داده‌های ثبت‌شده این گفتگو پاک شده و از اول شروع کنید؟")) {
      setCurrentStep(1);
      setContext("");
      setObservations("");
      setAnalysis("");
      setProjectorOutput("");
      setInputValue("");
      setError(null);
      setMessages([
        {
          id: "welcome-reset",
          sender: "assistant",
          text: "درود تسهیل‌گر ارشد کامزی. به دستیار هوشمند دیبریف خوش آمدید. من همراه شما هستم تا مشاهدات و خروجی‌های کارگاه‌های جدی شما را برای ارائه روی پروژکتور آماده کنم.\n\nلطفاً **نام بازی جدی** و **هدف اصلی این جلسه دیبریف** را بفرمایید:",
          timestamp: new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })
        }
      ]);
    }
  };

  // Copied state
  const [isCopied, setIsCopied] = useState(false);
  const handleCopyText = () => {
    navigator.clipboard.writeText(projectorOutput);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Format projector text to JSX safely (preserving negative spaces and large font rules)
  const renderProjectorOutput = (text: string) => {
    if (!text) return null;

    // Split based on separators "---"
    const blocks = text.split("---").map(b => b.trim()).filter(Boolean);

    return (
      <div className="space-y-12 py-6 text-right selection:bg-amber-500/30">
        {blocks.map((block, bIdx) => {
          const lines = block.split("\n").map(l => l.trim()).filter(Boolean);
          
          return (
            <div key={bIdx} className="space-y-6">
              {bIdx > 0 && (
                <hr className="border-t-4 border-slate-800 my-8 opacity-80" />
              )}
              
              <div className="space-y-5">
                {lines.map((line, lIdx) => {
                  // Handle slide headers with specific marks like 📌 or ###
                  if (line.startsWith("📌") || line.startsWith("# ")) {
                    const titleText = line.replace(/^[📌#\s]+/, "");
                    return (
                      <h2 key={lIdx} className="text-3xl md:text-5xl font-black text-amber-400 tracking-tight flex items-center gap-3 justify-start font-sans">
                        <span className="text-3xl">📌</span>
                        {titleText}
                      </h2>
                    );
                  }

                  if (line.startsWith("###")) {
                    const subheaderText = line.replace(/^[#\s]+/, "");
                    return (
                      <h3 key={lIdx} className="text-lg md:text-2xl font-black text-slate-100 border-r-4 border-amber-500 pr-3.5 tracking-wide mt-8">
                        {subheaderText}
                      </h3>
                    );
                  }

                  // Handle bullets (* or -)
                  if (line.startsWith("*") || line.startsWith("-")) {
                    const bulletText = line.substring(1).trim();
                    
                    // Replace markdown bold like **word** with styled span
                    const formattedText = bulletText.split("**").map((part, pIdx) => {
                      if (pIdx % 2 === 1) {
                        return <strong key={pIdx} className="text-amber-300 font-extrabold">{part}</strong>;
                      }
                      return part;
                    });

                    return (
                      <div key={lIdx} className="flex items-start gap-3.5 text-base md:text-xl font-bold text-slate-300 leading-relaxed pr-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0 mt-2.5 shadow-lg shadow-amber-500/50" />
                        <span>{formattedText}</span>
                      </div>
                    );
                  }

                  // Ordinary text
                  const formattedText = line.split("**").map((part, pIdx) => {
                    if (pIdx % 2 === 1) {
                      return <strong key={pIdx} className="text-amber-400 font-black">{part}</strong>;
                    }
                    return part;
                  });

                  return (
                    <p key={lIdx} className="text-sm md:text-lg text-slate-400 font-medium leading-relaxed">
                      {formattedText}
                    </p>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-stretch w-full min-h-[70vh]">
      
      {/* Left panel: Chat Interface (takes 5 cols on lg or full on smaller) */}
      <div className="xl:col-span-5 bg-slate-900/60 border border-slate-900 rounded-3xl p-5 flex flex-col justify-between space-y-4">
        
        {/* Chat Header & Stepper */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-950 pb-3">
            <div className="flex items-center gap-2.5 text-right">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Sparkles className="w-4 h-4 animate-pulse" />
              </div>
              <div>
                <h3 className="font-extrabold text-xs text-white">دستیار هوشمند دیبریف کامزی</h3>
                <p className="text-[10px] text-slate-500">طراحی گام‌به‌گام ارائه زنده رویداد</p>
              </div>
            </div>
            
            <button
              onClick={handleReset}
              className="text-[10px] text-slate-500 hover:text-rose-400 font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="شروع مجدد گفتگو"
            >
              <RotateCcw className="w-3 h-3" />
              شروع مجدد
            </button>
          </div>

          {/* Stepper tracker */}
          <div className="grid grid-cols-4 gap-1.5">
            {[
              { stepNum: 1, label: "کانتکست" },
              { stepNum: 2, label: "مشاهدات" },
              { stepNum: 3, label: "تحلیل ORID" },
              { stepNum: 4, label: "پروژکتور" }
            ].map((stepObj) => {
              const isActive = currentStep === stepObj.stepNum;
              const isDone = currentStep > stepObj.stepNum;
              return (
                <div key={stepObj.stepNum} className="space-y-1 text-center">
                  <div className={`h-1 rounded-full transition-all duration-300 ${
                    isActive 
                      ? "bg-amber-500 shadow-sm shadow-amber-500/20" 
                      : isDone 
                      ? "bg-emerald-500/75" 
                      : "bg-slate-800"
                  }`} />
                  <span className={`text-[9px] font-bold block truncate transition-colors ${
                    isActive 
                      ? "text-amber-400 font-extrabold" 
                      : isDone 
                      ? "text-emerald-400" 
                      : "text-slate-550"
                  }`}>
                    {stepObj.stepNum}. {stepObj.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chat History Messages */}
        <div className="flex-1 bg-slate-950/40 border border-slate-950 rounded-2xl p-4 overflow-y-auto max-h-[420px] min-h-[280px] space-y-4">
          {messages.map((msg) => {
            const isAss = msg.sender === "assistant";
            return (
              <div 
                key={msg.id} 
                className={`flex flex-col max-w-[85%] space-y-1 ${
                  isAss ? "self-start text-right mr-auto" : "self-end text-right ml-auto"
                }`}
                style={{ alignSelf: isAss ? "flex-start" : "flex-end" }}
              >
                <div className={`p-3.5 rounded-2xl text-xs leading-relaxed font-sans ${
                  isAss 
                    ? "bg-slate-900 border border-slate-850 text-slate-200 rounded-tr-none" 
                    : "bg-amber-500 text-slate-950 font-semibold rounded-tl-none"
                }`}>
                  {/* Parse basic bold syntax **text** for premium look in assistant text */}
                  {isAss ? (
                    msg.text.split("\n").map((para, pIdx) => (
                      <p key={pIdx} className={pIdx > 0 ? "mt-2" : ""}>
                        {para.split("**").map((txt, tIdx) => {
                          if (tIdx % 2 === 1) return <strong key={tIdx} className="text-amber-400 font-extrabold">{txt}</strong>;
                          return txt;
                        })}
                      </p>
                    ))
                  ) : (
                    msg.text
                  )}
                </div>
                <span className="text-[8px] text-slate-600 px-1 select-none font-mono">
                  {msg.timestamp}
                </span>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex flex-col max-w-[85%] space-y-1 self-start mr-auto">
              <div className="bg-slate-900 border border-slate-850 p-4 rounded-2xl rounded-tr-none text-xs flex items-center gap-2.5">
                <div className="flex space-x-1 space-x-reverse">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce [animation-delay:-0.3s]" />
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce [animation-delay:-0.15s]" />
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce" />
                </div>
                <span className="text-slate-400 font-bold">دستیار کامزی در حال پردازش...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input box & interactive elements */}
        <div className="space-y-2.5">
          {/* Quick-suggestion tags when collecting observations (Step 2) */}
          {currentStep === 2 && (
            <div className="flex flex-wrap gap-1.5 items-center justify-start py-1">
              <span className="text-[9px] text-slate-500 font-bold self-center">کمک‌برگ میانبر:</span>
              {[
                "تفکر جزیره‌ای شدید",
                "نقص صریح در شنیدن فعال",
                "انعطاف‌پذیری و سازگاری بالا",
                "ناهماهنگی شدید در تقسیم کار",
                "حفظ خونسردی در طوفان بهمن"
              ].map(tag => (
                <button
                  key={tag}
                  onClick={() => handleAddQuickObservation(tag)}
                  className="text-[9px] bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 px-2.5 py-1 rounded-lg transition-colors cursor-pointer select-none"
                >
                  + {tag}
                </button>
              ))}
            </div>
          )}

          {/* Quick-suggestion tags when collecting analysis (Step 3) */}
          {currentStep === 3 && (
            <div className="flex flex-wrap gap-1.5 items-center justify-start py-1">
              <span className="text-[9px] text-slate-500 font-bold self-center">کمک‌برگ میانبر:</span>
              {[
                "اضطراب ناشی از محدودیت زمان",
                "احساس گناه پس از شکست",
                "تفکیک موفق نقش‌ها در شرکت",
                "ضرورت تدوین چک‌لیست بحران",
                "اعتماد متقابل میان بخش‌ها"
              ].map(tag => (
                <button
                  key={tag}
                  onClick={() => handleAddQuickObservation(tag)}
                  className="text-[9px] bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 px-2.5 py-1 rounded-lg transition-colors cursor-pointer select-none"
                >
                  + {tag}
                </button>
              ))}
            </div>
          )}

          {/* Core Chat Form (adhering strictly to Single Question Micro-Interaction) */}
          <form onSubmit={handleSubmitAnswer} className="space-y-2 text-right">
            {error && (
              <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] p-2.5 rounded-xl flex items-start gap-2">
                <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="relative">
              <textarea
                ref={inputRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSubmitAnswer();
                  }
                }}
                disabled={isLoading || currentStep === 4}
                className="w-full bg-slate-950 border border-slate-850 rounded-2xl px-4 py-3 pl-12 text-xs text-slate-200 focus:outline-none focus:border-amber-500/60 transition-colors placeholder:text-slate-600 h-[72px] resize-none leading-relaxed text-right"
                placeholder={
                  currentStep === 4 
                    ? "پردازش نهایی خروجی پروژکتور تکمیل شد." 
                    : `پاسخ گام ${currentStep} را بنویسید... (یا بنویسید [برگشت] یا [خروجی نهایی])`
                }
              />
              
              <button
                type="submit"
                disabled={isLoading || currentStep === 4 || !inputValue.trim()}
                className={`absolute left-3.5 bottom-3.5 w-7 h-7 rounded-xl flex items-center justify-center transition-all ${
                  inputValue.trim() && !isLoading && currentStep !== 4
                    ? "bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer scale-105"
                    : "bg-slate-900 text-slate-500 cursor-not-allowed"
                }`}
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>

            {/* Stepper Navigation actions for accessibility */}
            <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
              <div className="flex gap-1.5">
                {currentStep > 1 && (
                  <button
                    type="button"
                    onClick={handleGoBack}
                    className="px-3 py-1.5 bg-slate-950 hover:bg-slate-900 border border-slate-850 text-slate-400 hover:text-white font-bold text-[10px] rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                    مرحله قبل (برگشت)
                  </button>
                )}
                
                {currentStep > 1 && currentStep < 4 && (
                  <button
                    type="button"
                    onClick={() => triggerProjectorGeneration()}
                    disabled={isLoading}
                    className="px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/20 font-bold text-[10px] rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Tv className="w-3.5 h-3.5" />
                    تولید خروجی نهایی همینجا
                  </button>
                )}
              </div>

              <div className="text-[10px] text-slate-550 leading-relaxed">
                کلیدواژه <code className="text-amber-500 bg-slate-950 px-1 py-0.5 rounded font-mono font-bold">[برگشت]</code> یا <code className="text-amber-500 bg-slate-950 px-1 py-0.5 rounded font-mono font-bold">[خروجی نهایی]</code> هم کار می‌کند.
              </div>
            </div>
          </form>
        </div>
      </div>

      {/* Right panel: Projector-Ready Preview (takes 7 cols on lg or full on smaller) */}
      <div className="xl:col-span-7 bg-slate-950 border border-slate-900 rounded-3xl p-6 md:p-8 flex flex-col justify-between space-y-6 relative overflow-hidden min-h-[450px]">
        
        {/* Subtle geometric neon grid for a futuristic premium corporate look */}
        <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:20px_20px] opacity-15 pointer-events-none" />
        
        {/* Panel Header Actions */}
        <div className="flex items-center justify-between border-b border-slate-900 pb-4 relative z-10">
          <div className="flex items-center gap-2.5 text-right">
            <Tv className="w-5 h-5 text-amber-500 animate-pulse" />
            <div>
              <h4 className="font-extrabold text-sm text-white">خروجی اسلاید پروژکتور (Projector-Ready Mode)</h4>
              <p className="text-[10px] text-slate-500">طراحی مینیمال، فونت درشت و تلگرافی ویژه ارائه از فاصله دور</p>
            </div>
          </div>

          {projectorOutput && (
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyText}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-[10px] rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                {isCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">کپی شد!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>کپی متنی</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Core Projector Display View */}
        <div className="flex-1 overflow-y-auto px-1 md:px-3 relative z-10">
          {isLoading && !projectorOutput ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
              <div className="relative">
                <div className="w-14 h-14 rounded-full border-4 border-amber-500/10 border-t-amber-500 animate-spin" />
                <Tv className="w-5 h-5 text-amber-500 absolute inset-0 m-auto" />
              </div>
              <div className="space-y-1">
                <h5 className="text-white font-extrabold text-xs">در حال پردازش اسلاید پروژکتور...</h5>
                <p className="text-[10px] text-slate-400">فرمت‌دهی داده‌ها به گزاره‌های کوتاه تلگرافی و ایجاد فضاهای منفی مناسب برای پرده</p>
              </div>
            </div>
          ) : projectorOutput ? (
            <div className="animate-fade-in">
              {renderProjectorOutput(projectorOutput)}
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center py-12 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-850 flex items-center justify-center text-slate-700">
                <Tv className="w-8 h-8" />
              </div>
              <div className="max-w-md space-y-1">
                <h5 className="text-slate-400 font-bold text-xs">اسلاید پروژکتور هنوز آماده نیست</h5>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  گفتگوی تسهیل‌گری در پنل سمت راست را آغاز کنید. با اتمام مراحل یا کلیک بر روی دکمه «خروجی نهایی»، گزاره‌های رفتاری و درس‌آموخته‌ها به صورت کاملاً خلاصه و فوق‌العاده خوانا روی این پرده شبیه‌سازی خواهند شد.
                </p>
              </div>
              <div className="border border-slate-900 bg-slate-900/10 p-3 rounded-xl max-w-sm text-[10px] text-slate-500 leading-relaxed text-right">
                <strong className="text-slate-400 block mb-0.5">💡 قوانین حاکم بر این اسلاید:</strong>
                بدون متن طولانی، استفاده از جداکننده‌های ضخیم، جملات کوتاه گزاره‌ای ۵ تا ۷ کلمه‌ای، و بولد کردن کلمات اصلی از دید افقی دور.
              </div>
            </div>
          )}
        </div>

        {/* Slide Footer */}
        <div className="border-t border-slate-900 pt-3 flex items-center justify-between text-[9px] text-slate-600 relative z-10 select-none">
          <span>COMZEE CORPORATE GAMEPLAY DEBRIEF • DESIGN FOR PROJECTOR</span>
          <span>comzee.ir</span>
        </div>
      </div>

    </div>
  );
}
