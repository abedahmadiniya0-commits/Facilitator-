/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useMemo } from "react";
import { Event, TeamScores, SCORE_LABELS } from "../types";
import { getAggregatedScores } from "../App";
import {
  TrendingUp,
  Building2,
  Calendar,
  Users,
  Award,
  AlertTriangle,
  Lightbulb,
  FileText,
  Activity,
  ArrowUpRight,
  Filter,
  Layers,
  ArrowRightLeft,
  ChevronRight,
  ChevronLeft,
  Briefcase,
  Target,
  Sparkles,
  HelpCircle,
  FileSpreadsheet
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from "recharts";

interface ClientGrowthDashboardProps {
  events: Event[];
  onSelectEvent: (eventId: string, tab: "setup" | "teams" | "analysis") => void;
}

export default function ClientGrowthDashboard({
  events,
  onSelectEvent
}: ClientGrowthDashboardProps) {
  // Group events by client/company name
  const clientsData = useMemo(() => {
    const clients: Record<string, Event[]> = {};
    events.forEach((event) => {
      const name = event.clientName?.trim();
      if (!name) return;
      if (!clients[name]) {
        clients[name] = [];
      }
      clients[name].push(event);
    });

    // Sort events inside each client chronologically (assuming date formats like YYYY-MM-DD or fa-IR are sortable)
    Object.keys(clients).forEach((clientName) => {
      clients[clientName].sort((a, b) => {
        return a.date.localeCompare(b.date);
      });
    });

    return clients;
  }, [events]);

  const clientNames = Object.keys(clientsData);

  // Active client state (default to first client if available)
  const [selectedClient, setSelectedClient] = useState<string>(clientNames[0] || "");

  // Fallback to update selected client if client names load or change
  React.useEffect(() => {
    if (clientNames.length > 0 && (!selectedClient || !clientNames.includes(selectedClient))) {
      setSelectedClient(clientNames[0]);
    }
  }, [clientNames, selectedClient]);

  // Chart view type: "line" for long-term trends, "radar" for dynamic profiles, "bar" for pre/post net change
  const [chartType, setChartType] = useState<"line" | "radar" | "bar">("line");

  // Selected dimensions to filter
  const [visibleDimensions, setVisibleDimensions] = useState<Record<string, boolean>>({
    communication: true,
    trust: true,
    coordination: true,
    problemSolving: true,
    resilience: true
  });

  const toggleDimension = (dim: string) => {
    setVisibleDimensions((prev) => ({
      ...prev,
      [dim]: !prev[dim]
    }));
  };

  const activeEvents = clientsData[selectedClient] || [];

  // Format data for Recharts line chart
  const timelineData = useMemo(() => {
    return activeEvents.map((event) => {
      const agg = getAggregatedScores(event.teams);
      const post = agg.postScores;

      return {
        id: event.id,
        title: event.title,
        shortTitle: event.title.length > 25 ? event.title.substring(0, 25) + "..." : event.title,
        date: event.date,
        // Calculate scores directly using postScores
        communication: post.communication,
        trust: post.trust,
        coordination: post.coordination,
        problemSolving: post.problemSolving,
        resilience: post.resilience
      };
    });
  }, [activeEvents]);

  // Format data for Radar Chart (shows average scores for the entire duration of relationships)
  const averageRadarData = useMemo(() => {
    if (activeEvents.length === 0) return [];
    
    let totalPost = { communication: 0, trust: 0, coordination: 0, problemSolving: 0, resilience: 0 };
    let count = 0;

    activeEvents.forEach((event) => {
      if (event.teams.length === 0) return;
      const agg = getAggregatedScores(event.teams);

      totalPost.communication += agg.postScores.communication;
      totalPost.trust += agg.postScores.trust;
      totalPost.coordination += agg.postScores.coordination;
      totalPost.problemSolving += agg.postScores.problemSolving;
      totalPost.resilience += agg.postScores.resilience;
      count++;
    });

    if (count === 0) return [];

    return (Object.keys(SCORE_LABELS) as Array<keyof TeamScores>).map((key) => {
      return {
        subject: SCORE_LABELS[key].fa,
        'امتیاز (میانگین)': Math.round((totalPost[key] / count) * 10) / 10,
        fullMark: 10
      };
    });
  }, [activeEvents]);

  // Aggregate total metrics for client
  const stats = useMemo(() => {
    let totalWorkshops = activeEvents.length;
    let totalTeams = 0;
    let totalEmployees = 0;
    let sumOfAverages = 0;
    let countOfTeams = 0;

    activeEvents.forEach((event) => {
      totalTeams += event.teams.length;
      event.teams.forEach((t) => {
        totalEmployees += t.membersCount || 0;
        const postScores = t.postScores || { communication: 5, trust: 5, coordination: 5, problemSolving: 5, resilience: 5 };
        const postAvg = (postScores.communication + postScores.trust + postScores.coordination + postScores.problemSolving + postScores.resilience) / 5;
        sumOfAverages += postAvg;
        countOfTeams++;
      });
    });

    const averageScore = countOfTeams > 0 ? Math.round((sumOfAverages / countOfTeams) * 10) / 10 : 7.2;

    return {
      totalWorkshops,
      totalTeams,
      totalEmployees,
      averageScore
    };
  }, [activeEvents]);

  // Strategic Consultative HR Advice & Profile Summary (Generated based on the scores)
  const hrConsultation = useMemo(() => {
    if (activeEvents.length === 0) return null;

    // Determine weak/strong points from the average radar scores
    const dimensions = Object.keys(SCORE_LABELS) as Array<keyof TeamScores>;
    const averages = dimensions.map((dim) => {
      let sum = 0;
      let count = 0;
      activeEvents.forEach((e) => {
        if (e.teams.length === 0) return;
        const agg = getAggregatedScores(e.teams);
        sum += agg.postScores[dim];
        count++;
      });
      return { dim, avg: count > 0 ? sum / count : 5 };
    });

    averages.sort((a, b) => b.avg - a.avg);
    const strongestDim = averages[0]?.dim as keyof TeamScores;
    const weakestDim = averages[averages.length - 1]?.dim as keyof TeamScores;

    const insightsByDim: Record<keyof TeamScores, { strength: string; advice: string }> = {
      communication: {
        strength: "تسهیم بدون مرز اطلاعات و کیفیت بالای گفت‌وگوی بین‌فردی در فشار کاری بالا.",
        advice: "پیشنهاد می‌شود کانال‌های ارتباطی اسلک/تیمز را برای کانال‌های ایده آزاد (Open-space) باز بگذارید و ریتوال اسپرینت‌ها را کوتاه‌تر کنید."
      },
      trust: {
        strength: "امنیت روانی بالا و وجود فضای صمیمی برای برون‌ریزی احساسات و پذیرش اشتباهات.",
        advice: "از این امنیت روانی استفاده کرده و جلسات رتروسپکتیو هفتگی بدون حضور مدیران ارشد بگذارید تا مشکلات فرایندی بدون سانسور ریشه‌یابی شوند."
      },
      coordination: {
        strength: "تعهد جدی به تقسیم نقش‌ها، مدیریت بهینه زمان و هماهنگی توزیع‌شده بین‌گروهی.",
        advice: "توصیه می‌شود در اسپرینت‌ها بر هماهنگی چندوظیفه‌ای (Cross-functional) تمرکز کنید و مرز بین تیم‌های جزیره‌ای را کم‌رنگ‌تر نمایید."
      },
      problemSolving: {
        strength: "تفکر استراتژیک خلاق و قدرت بالا در تحلیل گزینه‌ها پیش از اتخاذ تصمیم‌های حیاتی.",
        advice: "جهت حفظ این پتانسیل، رویدادهای هکاتون داخلی طراحی کنید تا نوآوری‌های فردی به راه‌حل‌های عملیاتی در سازمان تبدیل شوند."
      },
      resilience: {
        strength: "تاب‌آوری بالا در مواجهه با باخت و قدرت بالای بازیابی روحیه تیمی در سناریوهای دشوار.",
        advice: "پیشنهاد می‌شود تکنیک «پس از مرگ پروژه» (Post-mortem Analysis) را پس از شکست‌های واقعی پیاده کنید تا تجربه کارگاه شبیه‌سازی کالیبره شود."
      }
    };

    return {
      strongest: SCORE_LABELS[strongestDim]?.fa || "ارتباطات",
      weakest: SCORE_LABELS[weakestDim]?.fa || "تاب‌آوری",
      strengthText: insightsByDim[strongestDim]?.strength || "پویایی همبستگی عالی.",
      adviceText: insightsByDim[weakestDim]?.advice || "توصیه می‌شود اهداف تیمی را به صورت عینی تعریف کنید."
    };
  }, [activeEvents]);

  // Retrieve all action items from all events of this client
  const allActionPlanItems = useMemo(() => {
    const items: Array<{ eventTitle: string; task: string; responsible: string; deadline: string; completed: boolean; id: string }> = [];
    activeEvents.forEach((event) => {
      event.teams.forEach((t) => {
        if (t.actionPlan?.commitments) {
          t.actionPlan.commitments.forEach((c) => {
            items.push({
              eventTitle: event.title,
              task: c.task,
              responsible: c.responsible,
              deadline: c.deadline,
              completed: c.completed,
              id: c.id
            });
          });
        }
      });
    });
    return items;
  }, [activeEvents]);

  if (clientNames.length === 0) {
    return (
      <div className="bg-slate-900/20 border border-slate-900 rounded-3xl p-12 text-center text-slate-400 space-y-4 font-sans text-right">
        <Building2 className="w-12 h-12 text-slate-700 mx-auto" />
        <h3 className="font-extrabold text-sm text-slate-300">هیچ پروفایل مشتری یا تاریخچه‌ای ثبت نشده است</h3>
        <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
          با وارد کردن اطلاعات کارگاه‌ها در تب امتیازدهی و انتخاب یک نام مشخص برای سازمان مشتری در چندین رویداد، تاریخچه و داشبورد رشد بلندمدت شرکت در اینجا به صورت اتوماتیک رسم می‌شود.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-right font-sans">
      
      {/* Client Selector Bar */}
      <div className="bg-slate-900/60 border border-slate-900 p-5 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="p-2.5 bg-amber-500/10 rounded-xl text-amber-500 shrink-0">
            <Building2 className="w-5 h-5" />
          </div>
          <div className="space-y-0.5">
            <h3 className="font-extrabold text-sm text-white">پروفایل مشتریان سازمانی کامزی</h3>
            <p className="text-[11px] text-slate-400">سازمان‌ها را برگزینید تا ارزیابی توسعه پویایی تیمی بلندمدت و مشاوره‌های HR فعال شود.</p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <span className="text-xs text-slate-400 font-medium whitespace-nowrap">شرکت انتخاب شده:</span>
          <select
            value={selectedClient}
            onChange={(e) => setSelectedClient(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-200 text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:border-amber-500 cursor-pointer min-w-[200px]"
          >
            {clientNames.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Corporate HR Consulting & High-Level Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        
        {/* KPI 1: Workshops Held */}
        <div className="bg-slate-950/40 border border-slate-900 p-4 rounded-2xl flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 font-bold block">تعداد کل کارگاه‌ها</span>
            <span className="text-xl font-black font-mono text-white">{stats.totalWorkshops} دوره</span>
          </div>
          <div className="p-2 bg-slate-900 border border-slate-800 text-amber-400 rounded-xl">
            <Calendar className="w-5 h-5" />
          </div>
        </div>

        {/* KPI 2: Total Teams Trained */}
        <div className="bg-slate-950/40 border border-slate-900 p-4 rounded-2xl flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 font-bold block">تیم‌های ارزیابی شده</span>
            <span className="text-xl font-black font-mono text-amber-400">{stats.totalTeams} تیم</span>
          </div>
          <div className="p-2 bg-slate-900 border border-slate-800 text-amber-400 rounded-xl">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* KPI 3: Total Employees Engaged */}
        <div className="bg-slate-950/40 border border-slate-900 p-4 rounded-2xl flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 font-bold block">مجموع پرسنل درگیر</span>
            <span className="text-xl font-black font-mono text-white">{stats.totalEmployees} نفر</span>
          </div>
          <div className="p-2 bg-slate-900 border border-slate-800 text-amber-400 rounded-xl">
            <Briefcase className="w-5 h-5" />
          </div>
        </div>

        {/* KPI 4: Cumulative Team Average Score */}
        <div className="bg-slate-950/40 border border-slate-900 p-4 rounded-2xl flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] text-slate-500 font-bold block">میانگین امتیاز پویایی تیمی</span>
            <span className="text-xl font-black font-mono text-emerald-400">{stats.averageScore} از ۱۰</span>
          </div>
          <div className="p-2 bg-slate-900 border border-slate-800 text-emerald-400 rounded-xl">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Main Growth Trend Analysis Chart & Parameters */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Long-term Growth Chart Section */}
        <div className="lg:col-span-2 bg-slate-950/60 border border-slate-900 p-5 rounded-3xl space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-900 pb-3">
            <div className="space-y-0.5">
              <h4 className="font-extrabold text-xs text-white flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-amber-500" />
                روند توسعه پویایی‌های تیمی در طول زمان (HR Development Tracker)
              </h4>
              <p className="text-[10px] text-slate-400">نمودار پیشرفت سازمان در شاخص‌های گوناگون در رویدادهای مختلف</p>
            </div>

            {/* Chart controls */}
            <div className="flex items-center gap-1.5 self-end sm:self-auto text-[10px]">
              
              <div className="flex bg-slate-900 rounded-lg p-0.5 border border-slate-800 font-bold">
                <button
                  onClick={() => setChartType("line")}
                  className={`px-2 py-1 rounded-md transition-colors ${
                    chartType === "line" ? "bg-amber-500 text-slate-950" : "text-slate-400 hover:text-white"
                  }`}
                >
                  نمودار خطی
                </button>
                <button
                  onClick={() => setChartType("bar")}
                  className={`px-2 py-1 rounded-md transition-colors ${
                    chartType === "bar" ? "bg-amber-500 text-slate-950" : "text-slate-400 hover:text-white"
                  }`}
                >
                  رشد ستونی
                </button>
                <button
                  onClick={() => setChartType("radar")}
                  className={`px-2 py-1 rounded-md transition-colors ${
                    chartType === "radar" ? "bg-amber-500 text-slate-950" : "text-slate-400 hover:text-white"
                  }`}
                >
                  پروفایل راداری
                </button>
              </div>

            </div>
          </div>

          {/* Dimension toggle filters */}
          {chartType !== "radar" && (
            <div className="flex flex-wrap gap-2 text-[10px] font-bold">
              <span className="text-slate-500 self-center flex items-center gap-1">
                <Filter className="w-3 h-3" /> فیلتر شاخص‌ها:
              </span>
              {(Object.keys(SCORE_LABELS) as Array<keyof TeamScores>).map((key) => {
                const visible = visibleDimensions[key];
                return (
                  <button
                    key={key}
                    onClick={() => toggleDimension(key)}
                    className={`px-2.5 py-1 rounded-full border transition-all ${
                      visible
                        ? "bg-slate-900 border-amber-500/30 text-amber-400"
                        : "bg-transparent border-slate-900 text-slate-500 hover:border-slate-850"
                    }`}
                  >
                    <span className={`inline-block w-1.5 h-1.5 rounded-full mr-1.5 ${
                      key === "communication" ? "bg-[#38bdf8]" :
                      key === "trust" ? "bg-[#34d399]" :
                      key === "coordination" ? "bg-[#fb7185]" :
                      key === "problemSolving" ? "bg-[#fbbf24]" : "bg-[#a78bfa]"
                    }`} />
                    {SCORE_LABELS[key].fa}
                  </button>
                );
              })}
            </div>
          )}

          {/* Chart Wrapper Container */}
          <div className="h-[320px] w-full bg-slate-950/40 p-2 rounded-2xl">
            {timelineData.length < 2 && chartType !== "radar" ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2">
                <Layers className="w-10 h-10 text-slate-700" />
                <h5 className="font-bold text-xs text-slate-400">داده‌های تاریخی ناکافی جهت رسم نمودار پیشرفت</h5>
                <p className="text-[10px] text-slate-500 max-w-sm leading-relaxed">
                  نمودار پیشرفت زمانی با ثبت حداقل ۲ کارگاه با نام مشتری یکسان ({selectedClient}) رسم می‌شود. با اضافه کردن کارگاه جدید می‌توانید این نمودار را مشاهده کنید.
                </p>
              </div>
            ) : chartType === "line" ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timelineData} margin={{ top: 20, right: 10, left: -25, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#0f172a" />
                  <XAxis dataKey="shortTitle" tick={{ fill: "#64748b", fontSize: 9 }} stroke="#334155" />
                  <YAxis domain={[0, 10]} tick={{ fill: "#64748b", fontSize: 9 }} stroke="#334155" />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#020617", borderColor: "#1e293b", borderRadius: "1rem", textAlign: "right", fontFamily: "sans-serif", fontSize: "11px" }}
                    labelClassName="font-extrabold text-amber-400 text-xs mb-1"
                  />
                  <Legend wrapperStyle={{ fontSize: 9, paddingTop: 10 }} />
                  {visibleDimensions.communication && (
                    <Line name="ارتباطات" type="monotone" dataKey="communication" stroke="#38bdf8" strokeWidth={2.5} activeDot={{ r: 6 }} />
                  )}
                  {visibleDimensions.trust && (
                    <Line name="اعتماد تیمی" type="monotone" dataKey="trust" stroke="#34d399" strokeWidth={2.5} activeDot={{ r: 6 }} />
                  )}
                  {visibleDimensions.coordination && (
                    <Line name="رهبری و هماهنگی" type="monotone" dataKey="coordination" stroke="#fb7185" strokeWidth={2.5} activeDot={{ r: 6 }} />
                  )}
                  {visibleDimensions.problemSolving && (
                    <Line name="حل مسئله" type="monotone" dataKey="problemSolving" stroke="#fbbf24" strokeWidth={2.5} activeDot={{ r: 6 }} />
                  )}
                  {visibleDimensions.resilience && (
                    <Line name="تاب‌آوری" type="monotone" dataKey="resilience" stroke="#a78bfa" strokeWidth={2.5} activeDot={{ r: 6 }} />
                  )}
                </LineChart>
              </ResponsiveContainer>
            ) : chartType === "bar" ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={timelineData} margin={{ top: 20, right: 10, left: -25, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#0f172a" />
                  <XAxis dataKey="shortTitle" tick={{ fill: "#64748b", fontSize: 9 }} stroke="#334155" />
                  <YAxis domain={[0, 10]} tick={{ fill: "#64748b", fontSize: 9 }} stroke="#334155" />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#020617", borderColor: "#1e293b", borderRadius: "1rem", textAlign: "right", fontFamily: "sans-serif", fontSize: "11px" }}
                    labelClassName="font-extrabold text-amber-400 text-xs mb-1"
                  />
                  <Legend wrapperStyle={{ fontSize: 9, paddingTop: 10 }} />
                  {visibleDimensions.communication && <Bar name="ارتباطات" dataKey="communication" fill="#38bdf8" radius={[4, 4, 0, 0]} />}
                  {visibleDimensions.trust && <Bar name="اعتماد" dataKey="trust" fill="#34d399" radius={[4, 4, 0, 0]} />}
                  {visibleDimensions.coordination && <Bar name="هماهنگی" dataKey="coordination" fill="#fb7185" radius={[4, 4, 0, 0]} />}
                  {visibleDimensions.problemSolving && <Bar name="حل مسئله" dataKey="problemSolving" fill="#fbbf24" radius={[4, 4, 0, 0]} />}
                  {visibleDimensions.resilience && <Bar name="تاب‌آوری" dataKey="resilience" fill="#a78bfa" radius={[4, 4, 0, 0]} />}
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="75%" data={averageRadarData}>
                  <PolarGrid stroke="#1e293b" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: "#94a3b8", fontSize: 10 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 10]} tick={{ fill: "#64748b", fontSize: 8 }} stroke="#1e293b" />
                  <Radar name="میانگین امتیازات پویایی تیمی" dataKey="امتیاز (میانگین)" stroke="#34d399" fill="#34d399" fillOpacity={0.25} />
                  <Tooltip contentStyle={{ backgroundColor: "#020617", borderColor: "#1e293b", borderRadius: "1rem", textAlign: "right" }} />
                  <Legend wrapperStyle={{ fontSize: 9 }} />
                </RadarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* HR Strategic Consultation Column */}
        {hrConsultation && (
          <div className="bg-gradient-to-tr from-slate-950 to-slate-900 border border-slate-900 p-5 rounded-3xl space-y-4">
            <h4 className="font-extrabold text-xs text-white flex items-center gap-2 pb-2 border-b border-slate-900">
              <Sparkles className="w-4.5 h-4.5 text-amber-500 animate-pulse" />
              دیدگاه مشاوره‌ای کامزی برای HR
            </h4>
            
            <p className="text-[10px] text-slate-400 leading-relaxed">
              بر اساس شبیه‌سازی‌های اجرا شده، ساختار و پویایی کلی منابع انسانی <strong className="text-white">{selectedClient}</strong> تحلیل شده و موارد زیر توصیه می‌شود:
            </p>

            <div className="space-y-3">
              {/* Core Strength */}
              <div className="bg-emerald-500/5 border border-emerald-500/10 p-3.5 rounded-2xl space-y-1.5">
                <span className="font-bold text-[10px] text-emerald-400 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" />
                  بزرگ‌ترین مزیت تیمی سازمان:
                </span>
                <span className="text-xs font-bold text-slate-200 block">{hrConsultation.strongest}</span>
                <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                  {hrConsultation.strengthText}
                </p>
              </div>

              {/* Core Developmental Area */}
              <div className="bg-amber-500/5 border border-amber-500/10 p-3.5 rounded-2xl space-y-1.5">
                <span className="font-bold text-[10px] text-amber-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  بخش نیازمند سرمایه‌گذاری آموزشی:
                </span>
                <span className="text-xs font-bold text-slate-200 block">{hrConsultation.weakest}</span>
                <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                  {hrConsultation.adviceText}
                </p>
              </div>

              {/* Strategic Advice */}
              <div className="bg-slate-900/60 border border-slate-900 p-3.5 rounded-2xl space-y-1.5">
                <span className="font-bold text-[10px] text-amber-500 flex items-center gap-1.5">
                  <Lightbulb className="w-3.5 h-3.5" />
                  نقشه راه توسعه منابع انسانی:
                </span>
                <p className="text-[10px] text-slate-300 leading-relaxed font-medium">
                  برگزاری دوره‌ای شبیه‌سازی‌ها هر ۳ الی ۶ ماه یک بار باعث پایداری رشد و جلوگیری از فرسودگی شغلی می‌شود. پیشنهاد بعدی ما، بازی‌های سناریو سنگین با محوریت <strong>حل تعارضات چند دپارتمانی</strong> است.
                </p>
              </div>
            </div>

          </div>
        )}

      </div>

      {/* Historical Workshops Timeline List & Action tracker */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Workshop history timeline */}
        <div className="lg:col-span-7 bg-slate-950/40 border border-slate-900 p-5 rounded-3xl space-y-4">
          <h4 className="font-extrabold text-xs text-white flex items-center gap-2 pb-2 border-b border-slate-900">
            <FileText className="w-4.5 h-4.5 text-amber-500" />
            تاریخچه تفصیلی کارگاه‌ها و شبیه‌سازی‌های سازمان
          </h4>

          <div className="relative pr-4 border-r border-slate-900 space-y-6">
            {activeEvents.map((event, index) => {
              const agg = getAggregatedScores(event.teams);
              return (
                <div key={event.id} className="relative space-y-2 text-right">
                  {/* Timeline dot */}
                  <span className="absolute -right-[21px] top-1 w-2.5 h-2.5 rounded-full bg-amber-500 border-2 border-slate-950 z-10" />

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-extrabold text-white hover:text-amber-400 transition-colors">
                        {event.title}
                      </span>
                      <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-400 px-2 py-0.5 rounded-md font-mono">
                        {event.date}
                      </span>
                    </div>

                    <button
                      onClick={() => onSelectEvent(event.id, "analysis")}
                      className="px-2.5 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-amber-400 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer self-start sm:self-auto"
                    >
                      مشاهده گزارش دیبریف
                      <ArrowUpRight className="w-3 h-3" />
                    </button>
                  </div>

                  <p className="text-[10px] text-slate-500 font-medium">
                    تسهیل‌گر: <strong className="text-slate-400">{event.facilitatorName || "تسهیل‌گر کامزی"}</strong> • تعداد تیم‌ها: <strong className="text-slate-400">{event.teams.length}</strong> • وضعیت: <span className="text-emerald-400">نهایی شده</span>
                  </p>

                  {/* Summary of post values */}
                  <div className="bg-slate-900/30 border border-slate-900/60 p-3 rounded-2xl grid grid-cols-5 gap-2 text-center text-[10px]">
                    <div>
                      <span className="text-slate-500 block font-bold">ارتباطات</span>
                      <span className="font-mono text-slate-200 mt-0.5 block"><strong className="text-amber-400">{agg.postScores.communication}</strong> / ۱۰</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-bold">امنیت روانی</span>
                      <span className="font-mono text-slate-200 mt-0.5 block"><strong className="text-amber-400">{agg.postScores.trust}</strong> / ۱۰</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-bold">هماهنگی</span>
                      <span className="font-mono text-slate-200 mt-0.5 block"><strong className="text-amber-400">{agg.postScores.coordination}</strong> / ۱۰</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-bold">حل مسئله</span>
                      <span className="font-mono text-slate-200 mt-0.5 block"><strong className="text-amber-400">{agg.postScores.problemSolving}</strong> / ۱۰</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-bold">تاب‌آوری</span>
                      <span className="font-mono text-slate-200 mt-0.5 block"><strong className="text-amber-400">{agg.postScores.resilience}</strong> / ۱۰</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Action checklist follow-up status across relationship */}
        <div className="lg:col-span-5 bg-slate-950/40 border border-slate-900 p-5 rounded-3xl space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h4 className="font-extrabold text-xs text-white flex items-center gap-2 pb-2 border-b border-slate-900">
              <FileSpreadsheet className="w-4.5 h-4.5 text-amber-500" />
              رهگیری تعهدات تیمی در محیط کار واقعی
            </h4>

            <p className="text-[10px] text-slate-400 leading-relaxed">
              چک‌لیست دیجیتال زیر تعهداتی را که پرسنل این سازمان در انتهای کارگاه پذیرفته‌اند تجمیع کرده تا HR بتواند به راحتی بر اجرای فیزیکی آنها نظارت کند:
            </p>

            <div className="space-y-3 overflow-y-auto max-h-[220px] pr-1">
              {allActionPlanItems.length === 0 ? (
                <div className="text-center py-8 text-slate-600 text-xs">
                  هنوز هیچ تعهدی در هیچ یک از کارگاه‌های این شرکت به ثبت نرسیده است.
                </div>
              ) : (
                allActionPlanItems.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3 rounded-xl border flex items-start gap-2.5 transition-all ${
                      item.completed
                        ? "bg-emerald-500/5 border-emerald-500/15"
                        : "bg-slate-900/40 border-slate-900/80"
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full shrink-0 mt-1.5 ${
                      item.completed ? "bg-emerald-400" : "bg-amber-400"
                    }`} />
                    <div className="flex-1 space-y-1 text-right">
                      <span className={`text-[11px] font-bold block ${item.completed ? 'text-slate-400 line-through' : 'text-slate-200'}`}>
                        {item.task}
                      </span>
                      <div className="flex justify-between text-[9px] text-slate-500">
                        <span>مسئول: {item.responsible || "لیدر تیم"}</span>
                        <span>مهلت: {item.deadline || "۷ روز"}</span>
                      </div>
                      <span className="text-[8px] text-slate-600 block pt-1 border-t border-slate-950/40 truncate">
                        منبع: {item.eventTitle}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-900/80 bg-slate-900/10 p-3.5 rounded-2xl text-[10px] text-slate-500 space-y-1 font-medium leading-relaxed">
            <div className="flex items-center gap-1.5 text-white font-bold mb-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>چرا این داشبورد مهم است؟</span>
            </div>
            تسهیل‌گر با اشتراک‌گذاری این داشبورد با مدیر HR سازمان، نشان می‌دهد که پویایی‌ها چگونه توسعه می‌یابند و تعهدات پیگیری می‌شوند. این ارزش‌آفرینی فراتر از برگزاری ساده رویداد بوده و نقش تسهیل‌گر را به شریک استراتژیک سرمایه انسانی مبدل می‌سازد.
          </div>
        </div>

      </div>

    </div>
  );
}
