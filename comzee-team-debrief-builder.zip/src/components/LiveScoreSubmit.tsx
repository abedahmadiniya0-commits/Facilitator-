/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { SCORE_LABELS, TeamScores } from "../types";
import {
  Sparkles,
  Users,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Info,
  User,
  Activity,
  Heart,
  ShieldCheck,
  Zap,
  X,
} from "lucide-react";

interface LiveScoreSubmitProps {
  eventId: string;
  teamId: string;
  eventName: string;
  teamName: string;
  onExit?: () => void;
}

export default function LiveScoreSubmit({ eventId, teamId, eventName, teamName, onExit }: LiveScoreSubmitProps) {
  const [memberName, setMemberName] = useState("");
  const [scores, setScores] = useState<TeamScores>({
    communication: 5,
    trust: 5,
    coordination: 5,
    problemSolving: 5,
    resilience: 5,
  });
  
  const [step, setStep] = useState<"intro" | "scoring" | "success">("intro");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const dimensions = [
    { key: "communication" as const, label: SCORE_LABELS.communication.fa, desc: "کیفیت انتقال اطلاعات، صراحت و گوش دادن مؤثر به یکدیگر", icon: <Users className="w-5 h-5 text-amber-400" /> },
    { key: "trust" as const, label: SCORE_LABELS.trust.fa, desc: "وجود صمیمیت، پذیرش اشتباهات، امنیت روانی و حمایت تیمی", icon: <ShieldCheck className="w-5 h-5 text-emerald-400" /> },
    { key: "coordination" as const, label: SCORE_LABELS.coordination.fa, desc: "همپوشانی نقش‌ها، سرعت عمل، پیشگیری از اتلاف انرژی و نظم تیمی", icon: <Zap className="w-5 h-5 text-sky-400" /> },
    { key: "problemSolving" as const, label: SCORE_LABELS.problemSolving.fa, desc: "خلاقیت در حل بن‌بست‌ها، همفکری و استفاده از خرد جمعی", icon: <Activity className="w-5 h-5 text-purple-400" /> },
    { key: "resilience" as const, label: SCORE_LABELS.resilience.fa, desc: "حفظ روحیه در شکست‌ها، انعطاف‌پذیری و بازگشت پرقدرت به بازی", icon: <Heart className="w-5 h-5 text-rose-400" /> },
  ];

  const handleScoreChange = (key: keyof TeamScores, val: number) => {
    setScores((prev) => ({
      ...prev,
      [key]: val,
    }));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch(`/api/events/${eventId}/teams/${teamId}/live-score`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...scores,
          memberName: memberName.trim() || "عضو ناشناس"
        }),
      });
      if (res.ok) {
        setStep("success");
      } else {
        const data = await res.json();
        setError(data.error || "خطا در ثبت امتیاز تیمی");
      }
    } catch (e) {
      setError("خطا در برقراری ارتباط با سرور ابری کامزی");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#06080a] text-slate-100 flex flex-col font-sans dir-rtl select-none relative overflow-hidden">
      {/* Background radial effects */}
      <div className="absolute top-0 left-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-amber-600/5 rounded-full blur-3xl pointer-events-none" />

      {/* Brand Header */}
      <header className="bg-[#0b0f14]/95 border-b border-slate-900/80 px-6 py-4 flex items-center justify-between shrink-0 z-10">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-pulse" />
            <span className="font-extrabold text-xs text-slate-300">نظرسنجی پویایی زنده کامزی</span>
          </div>
          
          {onExit && (
            <button
              onClick={onExit}
              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white border border-slate-800 rounded-xl text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer"
            >
              <X className="w-3 h-3" />
              خروج و بازگشت به داشبورد
            </button>
          )}
        </div>
        <div className="text-left font-mono">
          <span className="font-black text-sm tracking-tighter">COMZEE ◆</span>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 overflow-y-auto px-5 py-6 flex flex-col justify-center items-center relative z-10">
        <AnimatePresence mode="wait">
          {step === "intro" && (
            <motion.div
              key="intro"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="w-full max-w-md bg-slate-950/80 border border-slate-900 rounded-3xl p-6 space-y-6 text-center"
            >
              <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-center justify-center mx-auto text-amber-500">
                <Users className="w-8 h-8" />
              </div>

              <div className="space-y-1.5">
                <span className="text-[10px] font-black text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full uppercase">
                  خودارزیابی زنده کارگاه
                </span>
                <h1 className="text-xl font-extrabold text-white pt-1">
                  به لندینگ ارزیابی تیم خوش آمدید
                </h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  رویداد: <strong className="text-slate-200">{eventName}</strong> • تیم شما: <strong className="text-amber-400">{teamName}</strong>
                </p>
              </div>

              <div className="bg-[#0b0f14] p-4 rounded-2xl border border-slate-900 text-right space-y-3">
                <label className="text-xs font-bold text-slate-300 block flex items-center gap-1.5">
                  <User className="w-4 h-4 text-amber-500" />
                  نام یا نام مستعار شما (اختیاری):
                </label>
                <input
                  type="text"
                  placeholder="مثلاً: محمد، مریم یا لیدر"
                  value={memberName}
                  onChange={(e) => setMemberName(e.target.value)}
                  className="w-full bg-[#06080a] border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-amber-500 transition-colors text-right"
                />
              </div>

              <div className="bg-slate-900/40 p-4 rounded-2xl border border-slate-900/60 flex gap-3 text-xs text-slate-400 leading-relaxed text-right">
                <Info className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <p>
                  پاسخ‌های شما کاملاً محفوظ است. میانگین ارزیابی‌های اعضای تیم بر روی پروژکتور دیبریف رویداد در زمان واقعی نمایان می‌شود.
                </p>
              </div>

              <button
                onClick={() => setStep("scoring")}
                className="w-full py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm rounded-2xl transition-all shadow-lg shadow-amber-500/10 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                شروع ارزیابی پویایی تیمی
                <ChevronLeft className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {step === "scoring" && (
            <motion.div
              key="scoring"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="w-full max-w-md bg-slate-950/80 border border-slate-900 rounded-3xl p-6 space-y-6"
            >
              <div className="border-b border-slate-900 pb-3 flex justify-between items-center flex-wrap gap-2">
                <div>
                  <h2 className="font-extrabold text-base text-white">خودارزیابی کار تیمی</h2>
                  <p className="text-[10px] text-slate-500 mt-0.5">۵ بعد کلیدی پویایی را از ۱ تا ۱۰ امتیازدهی کنید</p>
                </div>
                <span className="text-[10px] text-slate-400 font-mono bg-slate-900 border border-slate-800 px-2 py-1 rounded">
                  تیم {teamName}
                </span>
              </div>

              {error && (
                <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3 rounded-xl text-xs font-bold text-center">
                  {error}
                </div>
              )}

              {/* Scoring Dimensions list */}
              <div className="space-y-5">
                {dimensions.map((dim) => {
                  const val = scores[dim.key];
                  return (
                    <div key={dim.key} className="bg-[#0b0f14] p-4 rounded-2xl border border-slate-900 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {dim.icon}
                          <span className="font-bold text-slate-200 text-xs">{dim.label}</span>
                        </div>
                        <span className="font-mono text-sm font-black text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-full">
                          {val}
                        </span>
                      </div>
                      
                      <p className="text-[10px] text-slate-400 leading-relaxed pr-1">
                        {dim.desc}
                      </p>

                      <div className="pt-2">
                        <input
                          type="range"
                          min="1"
                          max="10"
                          value={val}
                          onChange={(e) => handleScoreChange(dim.key, Number(e.target.value))}
                          className="w-full h-1.5 bg-slate-900 rounded-lg appearance-none cursor-pointer accent-amber-500"
                        />
                        <div className="flex justify-between text-[8px] text-slate-600 font-bold px-1 mt-1">
                          <span>نیاز به بهبود شدیدی داریم</span>
                          <span>فوق‌العاده و بی‌نظیریم</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  onClick={() => setStep("intro")}
                  disabled={submitting}
                  className="px-4 py-3 border border-slate-800 hover:border-slate-700 text-slate-400 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  بازگشت
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="flex-1 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 disabled:opacity-40 font-black text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-amber-500/10"
                >
                  {submitting ? "در حال ثبت اطلاعات..." : "ارسال نهایی ارزیابی تیمی"}
                  <Sparkles className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          )}

          {step === "success" && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-md bg-slate-950/80 border border-slate-900 rounded-3xl p-8 text-center space-y-6"
            >
              <div className="w-20 h-20 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto relative">
                <CheckCircle2 className="w-10 h-10" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full animate-ping" />
              </div>

              <div className="space-y-2">
                <h1 className="text-2xl font-black text-white">ثبت ارزیابی با موفقیت انجام شد!</h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  از زمان و بازخورد ارزشمند شما متشکریم. امتیازات شما به صورت در لحظه با سایر اعضا ادغام شده و بر روی مانیتور ارائه تسهیل‌گر آپدیت شد.
                </p>
              </div>

              <div className="bg-[#0b0f14] p-5 rounded-2xl border border-slate-900 text-right relative overflow-hidden">
                <span className="text-[10px] text-amber-500 font-extrabold uppercase block mb-1">کلام برگزیده کار تیمی:</span>
                <p className="text-slate-300 text-xs leading-relaxed italic font-medium">
                  «هیچ‌کدام از ما به تنهایی به اندازه همگی ما با هم باهوش نیست.»
                </p>
                <span className="text-[10px] text-slate-500 block mt-2 text-left font-mono">Ken Blanchard</span>
              </div>

              <p className="text-[10px] text-slate-500">
                در صورت نیاز می‌توانید این صفحه را ببندید یا با تسهیل‌گر رویداد هماهنگ شوید.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Brand Footer */}
      <footer className="py-4 border-t border-slate-900 text-center text-[10px] text-slate-600 font-medium shrink-0">
        تسهیل‌گری خلاق و دیجیتال کامزی © 2026
      </footer>
    </div>
  );
}
