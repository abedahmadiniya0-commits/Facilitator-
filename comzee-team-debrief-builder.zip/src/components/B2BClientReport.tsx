/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Event, Team, SCORE_LABELS, TeamScores } from "../types";
import { X, Printer, Award, Activity, Users, Calendar, Target, HelpCircle, AlertTriangle, Lightbulb, FileDown, Info, CheckCircle, CheckCircle2, FileSpreadsheet, Cloud, RefreshCw } from "lucide-react";
import { getAggregatedScores } from "../App";
import { initAuth, googleSignIn } from "../lib/firebase";
import { uploadReportToDrive } from "../lib/drive";

// We can import getAggregatedScores from App and DebriefChart from our existing components.
import DebriefChartComp from "./DebriefChart";

interface B2BClientReportProps {
  isOpen: boolean;
  onClose: () => void;
  event: Event;
  selectedTeamId: string;
}

export default function B2BClientReport({ isOpen, onClose, event, selectedTeamId }: B2BClientReportProps) {
  if (!isOpen) return null;

  // Calculate aggregated metrics for the header summary
  const totalTeams = event.teams.length;
  const totalParticipants = event.teams.reduce((acc, t) => acc + (t.membersCount || 0), 0);
  const aggregated = getAggregatedScores(event.teams);

  // Determine if we are rendering for "all_teams" or a single team
  const isAggregated = selectedTeamId === "all_teams";
  const activeTeam = isAggregated 
    ? null 
    : event.teams.find((t) => t.id === selectedTeamId) || null;

  const activeAnalysis = event.analyses ? event.analyses[selectedTeamId] : null;

  // Google Drive integration states
  const [driveAccessToken, setDriveAccessToken] = React.useState<string | null>(null);
  const [userEmail, setUserEmail] = React.useState<string | null>(null);
  const [isSavingToDrive, setIsSavingToDrive] = React.useState(false);
  const [driveLink, setDriveLink] = React.useState<string | null>(null);
  const [driveError, setDriveError] = React.useState<string | null>(null);
  const [driveSuccess, setDriveSuccess] = React.useState(false);

  React.useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setDriveAccessToken(token);
        setUserEmail(user.email);
      },
      () => {
        setDriveAccessToken(null);
        setUserEmail(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleSaveToDrive = async () => {
    setDriveError(null);
    setDriveSuccess(false);
    setIsSavingToDrive(true);

    try {
      let token = driveAccessToken;
      if (!token) {
        // Trigger sign in
        const result = await googleSignIn();
        if (result) {
          token = result.accessToken;
          setDriveAccessToken(result.accessToken);
          setUserEmail(result.user.email);
        } else {
          throw new Error("تأیید هویت با حساب گوگل لغو شد یا با خطا مواجه گردید.");
        }
      }

      if (!token) {
        throw new Error("توکن معتبر برای دسترسی به گوگل درایو یافت نشد.");
      }

      const teamName = isAggregated ? "کل کارگاه (تجمیعی)" : activeTeam?.name || "";
      const filename = `Comzee-B2B-Report-${event.clientName}-${teamName.replace(/\s+/g, "-")}.html`;
      const htmlContent = generateHtmlReport();

      const uploadResult = await uploadReportToDrive(token, filename, htmlContent);
      setDriveLink(uploadResult.webViewLink);
      setDriveSuccess(true);
    } catch (err: any) {
      console.error("Error saving report to Google Drive:", err);
      setDriveError(err.message || "خطایی در ذخیره فایل در گوگل درایو رخ داد.");
    } finally {
      setIsSavingToDrive(false);
    }
  };

  const getGameName = (gameId: string) => {
    if (gameId === "utopia") return "شهر آرمانی (Utopia)";
    if (gameId === "alliance") return "اتحاد استراتژیک (Strategic Alliance)";
    if (gameId === "pyramid") return "هرم سبز (Green Pyramid)";
    if (gameId === "theatre") return "تئاتر خلاقانه (Creative Theatre)";
    if (gameId === "drink") return "ساخت نوشیدنی (Drink Crafting)";
    return gameId;
  };

  // Generate self-contained high-fidelity printable HTML report to bypass iframe sandbox limits
  const generateHtmlReport = () => {
    const scores = isAggregated ? aggregated.postScores : activeTeam?.postScores || aggregated.postScores;
    const teamName = isAggregated ? "کل کارگاه (تجمیعی)" : activeTeam?.name || "";
    
    // Build game lists
    const gamesListHtml = (event.selectedGames || []).map(g => `<li class="py-1 border-b border-slate-100 last:border-0">${getGameName(g)}</li>`).join("") +
      (event.customGames || []).map(cg => `<li class="py-1 border-b border-slate-100 last:border-0">بازی سفارشی: ${cg}</li>`).join("");

    // Build goals HTML
    const goalsHtml = event.goals.map(g => `<li class="py-1">${g}</li>`).join("");

    // Build chart dimensions
    const chartDimensions = [
      { label: SCORE_LABELS.communication.fa, val: scores.communication },
      { label: SCORE_LABELS.trust.fa, val: scores.trust },
      { label: SCORE_LABELS.coordination.fa, val: scores.coordination },
      { label: SCORE_LABELS.problemSolving.fa, val: scores.problemSolving },
      { label: SCORE_LABELS.resilience.fa, val: scores.resilience },
    ];

    const barChartHtml = chartDimensions.map(d => `
      <div class="flex flex-col items-center flex-1 min-w-[70px] bg-slate-50 border border-slate-100 rounded-xl p-3 relative pt-12">
        <!-- Bar Background -->
        <div class="w-8 bg-slate-200 h-32 rounded-lg flex items-end overflow-hidden">
          <!-- Value fill -->
          <div class="w-full bg-amber-500 rounded-b-lg transition-all" style="height: ${d.val * 10}%"></div>
        </div>
        <!-- Score Label -->
        <span class="absolute top-4 font-mono font-bold text-xs text-amber-600">${d.val} / 10</span>
        <!-- Dimension Label -->
        <span class="mt-3 text-[10px] font-bold text-slate-600 text-center leading-relaxed h-8 flex items-center justify-center">${d.label}</span>
      </div>
    `).join("");

    // Strengths & Challenges HTML
    let qualitativeHtml = "";
    if (activeAnalysis) {
      const strengthsHtml = activeAnalysis.strengths.map(s => `
        <div class="border-b border-emerald-100 pb-3 last:border-0 last:pb-0">
          <span class="font-bold text-emerald-950 text-xs block">◆ ${s.title}</span>
          <p class="text-emerald-900 mt-1 leading-relaxed text-[11px]">${s.description}</p>
          <p class="text-emerald-700/80 text-[10px] mt-1 italic">شاهد رفتاری: ${s.behavioralEvidence}</p>
        </div>
      `).join("");

      const weaknessesHtml = activeAnalysis.weaknesses.map(w => `
        <div class="border-b border-rose-100 pb-3 last:border-0 last:pb-0">
          <span class="font-bold text-rose-950 text-xs block">◆ ${w.title}</span>
          <p class="text-rose-900 mt-1 leading-relaxed text-[11px]">${w.description}</p>
          <p class="text-rose-700/80 text-[10px] mt-1 italic">ریشه‌یابی تیمی: ${w.rootCause}</p>
        </div>
      `).join("");

      const transferHtml = activeAnalysis.workspaceTransfer.map(t => `
        <div class="bg-white/80 p-3.5 rounded-xl border border-amber-100">
          <span class="font-bold text-amber-950 text-xs block">■ ${t.actionableStep}</span>
          <p class="text-amber-900 mt-1.5 leading-relaxed text-[11px]">کاربرد سازمانی: ${t.officeApplication}</p>
        </div>
      `).join("");

      let actionPlanHtml = "";
      const activeTeamPlan = isAggregated ? null : activeTeam?.actionPlan;
      if (!isAggregated && activeTeamPlan && activeTeamPlan.commitments && activeTeamPlan.commitments.length > 0) {
        const commitmentRows = activeTeamPlan.commitments.map((c, idx) => `
          <div class="p-3.5 bg-white border border-amber-100 rounded-xl flex items-start gap-3">
            <div class="w-5 h-5 rounded-full ${c.completed ? 'bg-emerald-500 text-white' : 'bg-amber-100 text-amber-800'} flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
              ${c.completed ? '✓' : idx + 1}
            </div>
            <div class="flex-1 space-y-1">
              <span class="font-bold text-slate-800 text-xs block">${c.task}</span>
              <div class="flex gap-4 text-[10px] text-slate-500 font-medium">
                <span>مسئول پیگیری: <strong class="text-slate-700">${c.responsible || "لیدر تیم"}</strong></span>
                <span>مهلت انجام: <strong class="text-slate-700">${c.deadline || "۷ روز"}</strong></span>
              </div>
            </div>
          </div>
        `).join("");

        actionPlanHtml = `
          <div class="bg-amber-50/40 border border-amber-100 rounded-2xl p-5 space-y-3 mt-6">
            <h4 class="font-bold text-amber-800 text-xs mb-1 flex items-center gap-1.5">
              📋 تعهدات اجرایی تیم جهت بهبود پویایی در شرکت (Action Items Checklist)
            </h4>
            <p class="text-[10px] text-slate-500 leading-relaxed">
              این ۳ تعهد تیمی برای تغییر در محیط کار انتخاب شده‌اند. ایمیل پیگیری و پیگرد وضعیت یک هفته بعد به صورت اتوماتیک به لیدر تیم (${activeTeamPlan.leaderName || "ثبت نشده"} - ${activeTeamPlan.leaderEmail || "ثبت نشده"}) ارسال خواهد شد.
            </p>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">${commitmentRows}</div>
          </div>
        `;
      }

      qualitativeHtml = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="bg-emerald-50 border border-emerald-100 rounded-2xl p-5 space-y-3">
            <h4 class="font-bold text-emerald-800 text-xs mb-2 flex items-center gap-1.5">نقاط قوت برجسته و الگوهای کارآمد کار تیمی</h4>
            <div class="space-y-4">${strengthsHtml}</div>
          </div>
          <div class="bg-rose-50 border border-rose-100 rounded-2xl p-5 space-y-3">
            <h4 class="font-bold text-rose-800 text-xs mb-2 flex items-center gap-1.5">نقاط آسیب، چالش‌های ارتباطی و ناهماهنگی‌ها</h4>
            <div class="space-y-4">${weaknessesHtml}</div>
          </div>
        </div>
        <div class="bg-amber-50/60 border border-amber-100 rounded-2xl p-5 space-y-3 mt-6">
          <h4 class="font-bold text-amber-800 text-xs mb-2">برنامه انتقال تجربه به دفتر کار واقعی (Workspace Transfer Plan)</h4>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">${transferHtml}</div>
        </div>
        ${actionPlanHtml}
      `;
    } else {
      qualitativeHtml = `
        <div class="bg-slate-50 border border-slate-100 rounded-2xl p-8 text-center text-xs text-slate-500">
          هیچ گزارش و تحلیل کیفی هوش مصنوعی برای این بخش صادر نشده است.
        </div>
      `;
    }

    // Tags HTML
    let tagsSectionHtml = "";
    if (!isAggregated && activeTeam) {
      const tagsList = activeTeam.behaviorTags && activeTeam.behaviorTags.length > 0
        ? activeTeam.behaviorTags.map(tag => {
            const isPos = !tag.includes("❌");
            return `<span class="inline-block text-xs font-bold px-3 py-1.5 rounded-xl border ${isPos ? 'bg-emerald-50 border-emerald-100 text-emerald-800' : 'bg-rose-50 border-rose-100 text-rose-800'}">${tag}</span>`;
          }).join("")
        : `<span class="text-xs text-slate-400">هیچ تگ رفتاری برای این تیم ثبت نشده است.</span>`;

      tagsSectionHtml = `
        <div class="space-y-3 page-break">
          <h2 class="text-base font-bold text-slate-900 border-r-4 border-amber-500 pr-2.5">۳. شواهد رفتاری ثبت‌شده حین بازی (Behavioral Evidence Logs)</h2>
          <div class="flex flex-wrap gap-2 pt-1">${tagsList}</div>
        </div>
      `;
    }

    // Individual teams html for aggregated
    let individualTeamsHtml = "";
    if (isAggregated) {
      const teamsHtml = event.teams.map(t => {
        const hasAn = event.analyses && event.analyses[t.id];
        const teamTags = t.behaviorTags && t.behaviorTags.length > 0
          ? t.behaviorTags.map(tag => `<span class="bg-white border border-slate-200 text-[10px] font-bold px-2 py-0.5 rounded text-slate-700">${tag}</span>`).join(" ")
          : `<span class="text-slate-400">ثبت نشده</span>`;

        let teamAnalysesHtml = `<p class="text-slate-400">تحلیل کیفی هوش مصنوعی برای این تیم هنوز انجام نشده است.</p>`;
        if (hasAn && event.analyses) {
          teamAnalysesHtml = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1 text-slate-600 leading-relaxed text-[11px]">
              <div>
                <span class="font-bold text-slate-800 block mb-1">نقاط قوت تیمی:</span>
                <ul class="space-y-1 list-disc list-inside">
                  ${event.analyses[t.id].strengths.slice(0, 2).map(s => `<li><span class="font-bold text-slate-900">${s.title}:</span> ${s.description}</li>`).join("")}
                </ul>
              </div>
              <div>
                <span class="font-bold text-slate-800 block mb-1">چالش‌های تیمی و پویایی‌ها:</span>
                <ul class="space-y-1 list-disc list-inside">
                  ${event.analyses[t.id].weaknesses.slice(0, 2).map(w => `<li><span class="font-bold text-slate-900">${w.title}:</span> ${w.description}</li>`).join("")}
                </ul>
              </div>
            </div>
          `;
        }

        return `
          <div class="bg-slate-50 p-5 rounded-2xl border border-slate-100 space-y-3">
            <div class="flex items-center justify-between border-b border-slate-200 pb-2 flex-wrap gap-2">
              <span class="font-bold text-slate-900 text-sm">تیم: ${t.name} (${t.membersCount} عضو)</span>
              <span class="font-mono text-slate-500 font-bold">میانگین امتیاز پویایی: ${Math.round(Object.values(t.postScores).reduce((a,b)=>a+b, 0)/5 * 10)/10} از ۱۰</span>
            </div>
            <div class="flex flex-wrap gap-1.5 text-xs">
              <span class="text-slate-400 font-bold">رفتارهای مشاهده‌شده:</span>
              ${teamTags}
            </div>
            ${teamAnalysesHtml}
          </div>
        `;
      }).join("");

      individualTeamsHtml = `
        <div class="space-y-4 page-break">
          <h2 class="text-base font-bold text-slate-900 border-r-4 border-amber-500 pr-2.5">۴. وضعیت و خلاصه دیبریف تیمی تک‌تک تیم‌ها</h2>
          <div class="space-y-4">${teamsHtml}</div>
        </div>
      `;
    }

    return `
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>گزارش دیبریف کامزی - ${event.clientName}</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700;900&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Vazirmatn', Tahoma, sans-serif;
    }
    @media print {
      .no-print {
        display: none !important;
      }
      .page-break {
        page-break-before: always;
        margin-top: 2rem;
      }
      body {
        background-color: white !important;
        color: black !important;
      }
    }
  </style>
</head>
<body class="bg-slate-100 text-slate-900 p-4 md:p-8">

  <!-- Print Notice Banner (only on screen) -->
  <div class="no-print max-w-4xl mx-auto bg-amber-500 text-slate-950 px-5 py-4 rounded-2xl mb-6 shadow-md border border-amber-600 flex flex-col sm:flex-row justify-between items-center gap-3">
    <div>
      <h4 class="font-bold text-sm">سند چاپی آفلاین دیبریف کامزی صادر شد!</h4>
      <p class="text-xs text-slate-900 mt-0.5">این فایل بدون محدودیت آی‌فریم و کاملاً سازگار با پرینتر دانلود شده است. برای ذخیره به عنوان PDF دکمه مقابل را کلیک کنید.</p>
    </div>
    <button onclick="window.print()" class="px-5 py-2.5 bg-slate-950 hover:bg-slate-900 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 transition-all shadow cursor-pointer">
      🖨️ پرینت گزارش یا ذخیره PDF
    </button>
  </div>

  <!-- Main Printable Card -->
  <div class="bg-white max-w-4xl mx-auto rounded-3xl border border-slate-200 p-8 md:p-12 space-y-10 shadow-sm">
    
    <!-- Header Block -->
    <div class="border-b-4 border-amber-500 pb-8 space-y-4">
      <div class="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div class="space-y-1.5">
          <span class="text-[11px] font-bold uppercase tracking-wider text-amber-600 bg-amber-50 px-2.5 py-1 rounded-md">
            گزارش رسمی دیبریف و ارزیابی پویایی تیمی
          </span>
          <h1 class="text-2xl md:text-3xl font-black text-slate-900 pt-1 leading-tight">
            ${event.title}
          </h1>
          <p class="text-xs text-slate-500 font-medium">
            مجموعه تجربیات تیمی، شواهد رفتاری و تحلیل‌های سازمانی کامزی (Comzee)
          </p>
        </div>

        <!-- Brand Logo -->
        <div class="text-left font-mono self-start sm:self-auto shrink-0">
          <div class="font-black text-lg text-slate-950 tracking-tighter">COMZEE <span class="text-amber-500">◆</span></div>
          <div class="text-[8px] text-slate-400 uppercase tracking-widest mt-0.5">Team Experiential Analytics</div>
        </div>
      </div>

      <!-- Metadata Table -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100 text-xs text-right mt-4">
        <div class="space-y-1">
          <span class="text-slate-400 block font-medium">نام کارفرما / کلاینت</span>
          <span class="font-bold text-slate-800">${event.clientName}</span>
        </div>
        <div class="space-y-1 border-r border-slate-200 pr-4">
          <span class="text-slate-400 block font-medium">تسهیل‌گر رویداد</span>
          <span class="font-bold text-slate-800">${event.facilitatorName}</span>
        </div>
        <div class="space-y-1 border-r border-slate-200 pr-4">
          <span class="text-slate-400 block font-medium">تعداد کل شرکت‌کنندگان</span>
          <span class="font-bold text-slate-800">${totalParticipants} نفر (${totalTeams} تیم)</span>
        </div>
        <div class="space-y-1 border-r border-slate-200 pr-4">
          <span class="text-slate-400 block font-medium">تاریخ کارگاه</span>
          <span class="font-bold text-slate-800">${event.date}</span>
        </div>
      </div>
    </div>

    <!-- Section 1: Goals and Agenda -->
    <div class="space-y-4">
      <h2 class="text-base font-black text-slate-900 border-r-4 border-amber-500 pr-2.5">
        ۱. اهداف راهبردی و بازی‌های انجام‌شده کارگاه
      </h2>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-1">
        <div class="bg-slate-50 p-5 rounded-2xl border border-slate-100 space-y-3">
          <h3 class="font-bold text-xs text-slate-700">🎯 اهداف مد نظر کارفرما:</h3>
          <ul class="space-y-2 text-xs text-slate-600 list-disc list-inside leading-relaxed pr-1">
            ${goalsHtml}
          </ul>
        </div>

        <div class="bg-slate-50 p-5 rounded-2xl border border-slate-100 space-y-3">
          <h3 class="font-bold text-xs text-slate-700">🎲 بازی‌های انجام‌شده (ابزار یادگیری تجربی):</h3>
          <ul class="space-y-2 text-xs text-slate-600 list-disc list-inside leading-relaxed pr-1">
            ${gamesListHtml}
          </ul>
        </div>
      </div>
    </div>

    <!-- Section 2: Quantitative Score Analysis -->
    <div class="space-y-4 page-break">
      <h2 class="text-base font-black text-slate-900 border-r-4 border-amber-500 pr-2.5">
        ۲. ارزیابی آماری و پویایی تیمی
      </h2>
      <p class="text-xs text-slate-500 leading-relaxed max-w-3xl">
        پویایی‌های تیمی در طول کارگاه توسط تسهیل‌گر ارشد بر اساس ۵ بعد کلیدی سازمان سنجیده شده است.
        رقم پایانی نشان‌دهنده میانگین عملکرد در ابعاد ارتباطات، امنیت روانی، هماهنگی، حل مسئله و سازگاری تیمی است.
      </p>

      <!-- Custom CSS-based printable bar chart -->
      <div class="bg-slate-50 border border-slate-100 rounded-3xl p-6 text-slate-800">
        <div class="text-center font-bold text-xs text-slate-700 mb-4 pb-2 border-b border-slate-200">
          ${teamName} - ارزیابی نهایی پویایی‌های کار تیمی (از ۱۰ امتیاز)
        </div>
        <div class="flex justify-around items-end gap-3 pt-6 min-h-[180px]">
          ${barChartHtml}
        </div>
      </div>
    </div>

    <!-- Section 3: AI Qualitative Analysis & Recommendations -->
    <div class="space-y-5 page-break">
      <h2 class="text-base font-black text-slate-900 border-r-4 border-amber-500 pr-2.5">
        ۳. تحلیل کیفی پویایی‌ها و توصیه‌های هوش مصنوعی کامزی
      </h2>
      ${qualitativeHtml}
    </div>

    <!-- Section 4: Behavioral Tags Observed (Only for individual teams) -->
    ${tagsSectionHtml}

    <!-- Individual Teams List (For Aggregated Report) -->
    ${individualTeamsHtml}

    <!-- Footer Signature -->
    <div class="border-t border-slate-200 pt-6 flex justify-between text-[11px] text-slate-400 font-medium">
      <span>حقوق مادی و معنوی محفوظ است ◆ تسهیل‌گری خلاق کامزی</span>
      <span>Comzee Team-Building Debrief Reports &copy; 2026</span>
    </div>

  </div>

</body>
</html>
    `;
  };

  const handleDownloadHtmlReport = () => {
    const htmlContent = generateHtmlReport();
    const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Comzee-B2B-Report-${event.clientName}-${isAggregated ? 'aggregated' : activeTeam?.name || ''}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex justify-center p-0 md:p-6 dir-rtl text-right print:p-0 print:bg-white print:absolute print:inset-0">
      
      {/* Container Card */}
      <div className="bg-slate-900 w-full max-w-5xl rounded-none md:rounded-3xl border border-slate-800 flex flex-col shadow-2xl relative overflow-hidden print:border-0 print:rounded-none print:shadow-none print:bg-white print:text-black">
        
        {/* Sticky Control Bar (Hidden on print) */}
        <div className="flex items-center justify-between bg-slate-950 border-b border-slate-850 px-6 py-4 print:hidden shrink-0">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-amber-500/10 text-amber-500 rounded-lg">
              <Award className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-extrabold text-sm text-white">پیش‌نمایش گزارش سازمانی B2B</h3>
              <p className="text-[10px] text-slate-400 mt-0.5">سند نهایی بازخورد کارفرما - طراحی‌شده برای پرینت و خروجی PDF</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveToDrive}
              disabled={isSavingToDrive}
              className={`px-4 py-2 border ${
                driveSuccess 
                  ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20" 
                  : "border-sky-500/30 hover:border-sky-500/60 text-sky-400 hover:text-white"
              } font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50`}
              title="ذخیره مستقیم فایل گزارش در گوگل درایو کارفرما"
            >
              {isSavingToDrive ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Cloud className="w-4 h-4" />
              )}
              {driveSuccess ? "ذخیره مجدد در گوگل درایو" : "ذخیره در گوگل درایو"}
            </button>
            <button
              onClick={handleDownloadHtmlReport}
              className="px-4 py-2 border border-amber-500/30 hover:border-amber-500/60 text-amber-400 hover:text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
              title="دانلود فایل HTML قابل چاپ آفلاین برای حل محدودیت آی‌فریم"
            >
              <FileDown className="w-4 h-4" />
              دانلود فایل گزارش (HTML)
            </button>
            <button
              onClick={() => window.print()}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              پرینت مستقیم
            </button>
            <button
              onClick={onClose}
              className="p-2 bg-slate-850 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Report Content Panel */}
        <div className="flex-1 overflow-y-auto bg-white text-slate-900 p-8 md:p-12 space-y-10 font-sans print:p-4 print:overflow-visible">
          
          {/* Google Drive Status Banners (Only visible on screen) */}
          {driveSuccess && driveLink && (
            <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl flex items-start gap-3 print:hidden text-sm text-emerald-900 leading-relaxed">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="space-y-1 flex-1">
                <span className="font-extrabold block text-emerald-950 text-base">گزارش با موفقیت در گوگل درایو ذخیره شد!</span>
                <p>
                  فایل گزارش با فرمت HTML در پوشه Root گوگل درایو شما قرار گرفت. می‌توانید جهت مدیریت، ویرایش یا اشتراک‌گذاری روی لینک زیر کلیک کنید:
                </p>
                {userEmail && (
                  <p className="text-xs text-slate-450">
                     متصل به حساب کاربری: <strong>{userEmail}</strong>
                  </p>
                )}
                <div className="pt-1.5">
                  <a 
                    href={driveLink} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-lg transition-colors"
                  >
                    🚀 باز کردن فایل در گوگل درایو
                  </a>
                </div>
              </div>
            </div>
          )}

          {driveError && (
            <div className="bg-rose-50 border border-rose-200 p-4 rounded-2xl flex items-start gap-3 print:hidden text-sm text-rose-900 leading-relaxed">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-extrabold block text-rose-950 text-base">خطا در ذخیره گزارش در گوگل درایو:</span>
                <p>{driveError}</p>
              </div>
            </div>
          )}

          {/* IFrame Print Limitation Warning Banner (Only visible on screen) */}
          <div className="bg-amber-50 border border-amber-200 p-4.5 rounded-2xl flex items-start gap-3 print:hidden text-sm text-amber-900 leading-relaxed">
            <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1.5">
              <span className="font-extrabold block text-base text-amber-950">توجه تسهیل‌گر محترم:</span>
              <p>
                به دلیل محدودیت‌های امنیتی مرورگر برای پنجره‌های داخل شبیه‌ساز (آی‌فریم)، دکمه <strong>«پرینت مستقیم»</strong> ممکن است واکنش ندهد. برای پرینت بدون مشکل، می‌توانید دکمه <strong>«دانلود فایل گزارش (HTML)»</strong> را بفشارید و فایل دانلودی را با مرورگر خود باز کرده و به راحتی با زدن <kbd className="bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded font-mono text-xs">Ctrl+P</kbd> ذخیره یا چاپ کنید. همچنین باز کردن وب‌اپلیکیشن در یک تب جدید (New Tab) این محدودیت را به کلی رفع می‌کند.
              </p>
            </div>
          </div>
          
          {/* Header Block */}
          <div className="border-b-4 border-amber-500 pb-8 space-y-4">
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-600 bg-amber-50 px-3 py-1.5 rounded-md">
                  گزارش رسمی دیبریف و ارزیابی پویایی تیمی
                </span>
                <h1 className="text-3xl md:text-4xl font-black text-slate-900 pt-1.5 leading-tight">
                  {event.title}
                </h1>
                <p className="text-sm text-slate-500 font-bold">
                  مجموعه تجربیات تیمی، شواهد رفتاری و تحلیل‌های سازمانی کامزی (Comzee)
                </p>
              </div>

              {/* Brand Logo Placeholder */}
              <div className="text-left font-mono self-start md:self-auto shrink-0">
                <div className="font-black text-xl text-slate-950 tracking-tighter">COMZEE <span className="text-amber-500">◆</span></div>
                <div className="text-[10px] text-slate-400 uppercase tracking-widest mt-1">Team Experiential Analytics</div>
              </div>
            </div>

            {/* Metadata Table */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50 p-5 rounded-2xl border border-slate-100 text-sm text-right mt-4">
              <div className="space-y-1">
                <span className="text-slate-400 block font-bold">نام کارفرما / کلاینت</span>
                <span className="font-extrabold text-slate-800 text-base">{event.clientName}</span>
              </div>
              <div className="space-y-1 border-r border-slate-200 pr-4">
                <span className="text-slate-400 block font-bold">تسهیل‌گر رویداد</span>
                <span className="font-extrabold text-slate-800 text-base">{event.facilitatorName}</span>
              </div>
              <div className="space-y-1 border-r border-slate-200 pr-4">
                <span className="text-slate-400 block font-bold">تعداد کل شرکت‌کنندگان</span>
                <span className="font-extrabold text-slate-800 text-base">{totalParticipants} نفر ({totalTeams} تیم)</span>
              </div>
              <div className="space-y-1 border-r border-slate-200 pr-4">
                <span className="text-slate-400 block font-bold">تاریخ کارگاه</span>
                <span className="font-extrabold text-slate-800 text-base flex items-center justify-end gap-1">
                  <Calendar className="w-4 h-4 text-amber-500" />
                  ۱۴۰۵/۰۴/۰۷
                </span>
              </div>
            </div>
          </div>

          {/* Section 1: Goals and Agenda */}
          <div className="space-y-4">
            <h2 className="text-lg font-black text-slate-900 border-r-4 border-amber-500 pr-2.5">
              ۱. اهداف راهبردی و بازی‌های انجام‌شده کارگاه
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-1">
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 space-y-3">
                <h3 className="font-bold text-sm text-slate-700 flex items-center gap-1.5">
                  <Target className="w-4 h-4 text-amber-500" />
                  اهداف مد نظر کارفرما:
                </h3>
                <ul className="space-y-2 text-sm text-slate-600 list-disc list-inside leading-relaxed pr-1 font-medium">
                  {event.goals.map((g, i) => (
                    <li key={i}>{g}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 space-y-3">
                <h3 className="font-bold text-sm text-slate-700 flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-amber-500" />
                  بازی‌های انجام‌شده (ابزار یادگیری تجربی):
                </h3>
                <div className="space-y-2 text-sm text-slate-600 font-medium">
                  {event.selectedGames?.map((gameId) => {
                    return (
                      <div key={gameId} className="border-b border-slate-200 pb-1.5 last:border-0 last:pb-0">
                        <span className="font-bold text-slate-800">
                          {gameId === "utopia" && "بازی شهر آرمانی (Utopia)"}
                          {gameId === "alliance" && "بازی اتحاد استراتژیک (Strategic Alliance)"}
                          {gameId === "pyramid" && "بازی هرم سبز (Green Pyramid)"}
                          {gameId === "theatre" && "بازی تئاتر خلاقانه (Creative Theatre)"}
                          {gameId === "drink" && "بازی ساخت نوشیدنی (Drink Crafting)"}
                          {!["utopia", "alliance", "pyramid", "theatre", "drink"].includes(gameId) && gameId}
                        </span>
                      </div>
                    );
                  })}
                  {event.customGames?.map((cg, i) => (
                    <div key={i} className="border-b border-slate-200 pb-1.5 last:border-0 last:pb-0">
                      <span className="font-bold text-slate-800">بازی سفارشی: {cg}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Quantitative Score Analysis */}
          <div className="space-y-4 page-break">
            <h2 className="text-lg font-black text-slate-900 border-r-4 border-amber-500 pr-2.5">
              ۲. ارزیابی آماری و پویایی تیمی
            </h2>
            <p className="text-sm text-slate-550 leading-relaxed max-w-3xl font-medium">
              پویایی‌های تیمی در طول کارگاه توسط تسهیل‌گر ارشد بر اساس ۵ بعد کلیدی سازمان سنجیده شده است.
              رقم پایانی نشان‌دهنده میانگین عملکرد در ابعاد ارتباطات، امنیت روانی، هماهنگی، حل مسئله و سازگاری تیمی است.
            </p>

            {/* Render chart layout with White aesthetic specifically for print */}
            <div className="w-full">
              <DebriefChartComp 
                postScores={isAggregated ? aggregated.postScores : activeTeam?.postScores || aggregated.postScores}
                teamName={isAggregated ? "کل کارگاه (تجمیعی)" : activeTeam?.name || ""}
                lightMode={true}
              />
            </div>
          </div>

          {/* Section 3: AI Qualitative Analysis & Recommendations */}
          <div className="space-y-5 page-break">
            <h2 className="text-lg font-black text-slate-900 border-r-4 border-amber-500 pr-2.5">
              ۳. تحلیل کیفی پویایی‌ها و توصیه‌های هوش مصنوعی کامزی
            </h2>

            {activeAnalysis ? (
              <div className="space-y-6">
                
                {/* 1. Strengths & Challenges */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-5 text-sm">
                    <h4 className="font-extrabold text-emerald-800 flex items-center gap-1.5 mb-3">
                      <Award className="w-4 h-4 text-emerald-600" />
                      نقاط قوت برجسته و الگوهای کارآمد کار تیمی:
                    </h4>
                    <div className="space-y-3">
                      {activeAnalysis.strengths.map((s, idx) => (
                        <div key={idx} className="border-b border-emerald-200/40 pb-2.5 last:border-0 last:pb-0">
                          <span className="font-bold text-emerald-950 text-sm block">{s.title}</span>
                          <p className="text-emerald-900 mt-0.5 leading-relaxed text-sm">{s.description}</p>
                          <p className="text-emerald-700/80 text-xs mt-1 italic">شاهد رفتاری: {s.behavioralEvidence}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-rose-50 border border-rose-100 rounded-2xl p-5 text-sm">
                    <h4 className="font-extrabold text-rose-800 flex items-center gap-1.5 mb-3">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      نقاط آسیب، چالش‌های ارتباطی و ناهماهنگی‌ها:
                    </h4>
                    <div className="space-y-3">
                      {activeAnalysis.weaknesses.map((w, idx) => (
                        <div key={idx} className="border-b border-rose-200/40 pb-2.5 last:border-0 last:pb-0">
                          <span className="font-bold text-rose-950 text-sm block">{w.title}</span>
                          <p className="text-rose-900 mt-0.5 leading-relaxed text-sm">{w.description}</p>
                          <p className="text-rose-700/80 text-xs mt-1 italic">ریشه‌یابی تیمی: {w.rootCause}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 2. Workspace Transfer Plan */}
                <div className="bg-amber-50/60 border border-amber-100 rounded-2xl p-6 text-sm leading-relaxed">
                  <h4 className="font-extrabold text-amber-800 flex items-center gap-1.5 text-sm mb-3">
                    <Lightbulb className="w-4 h-4 text-amber-600" />
                    برنامه انتقال تجربه به دفتر کار واقعی (Workspace Transfer Plan):
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeAnalysis.workspaceTransfer.map((t, idx) => (
                      <div key={idx} className="bg-white/60 p-3.5 rounded-xl border border-amber-100">
                        <span className="font-bold text-amber-950 text-sm block">{t.actionableStep}</span>
                        <p className="text-amber-900 mt-1 leading-relaxed text-xs">کاربرد سازمانی: {t.officeApplication}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3. Action Plan Tracker - Commitments */}
                {activeTeam?.actionPlan?.commitments && activeTeam.actionPlan.commitments.length > 0 && (
                  <div className="bg-amber-50 border border-amber-100 rounded-2xl p-6 text-sm leading-relaxed space-y-3">
                    <h4 className="font-extrabold text-amber-800 flex items-center gap-1.5 text-sm">
                      <CheckCircle className="w-4 h-4 text-amber-600" />
                      تعهدات کارگاهی منتخب تیم (Action Items Checklist):
                    </h4>
                    <p className="text-xs text-amber-700 font-medium">
                      ۳ اقدام کلیدی انتخاب شده توسط تیم جهت اجرا در سازمان. پیگیری اتوماتیک برای لیدر تیم ({activeTeam.actionPlan.leaderName || "ثبت نشده"} - {activeTeam.actionPlan.leaderEmail || "ثبت نشده"}) در تاریخ {activeTeam.actionPlan.followUpDate} برنامه‌ریزی شده است.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                      {activeTeam.actionPlan.commitments.map((c, idx) => (
                        <div key={c.id} className="bg-white border border-amber-100 p-3.5 rounded-xl space-y-2 relative text-sm">
                          <div className="flex items-center gap-2">
                            <span className={`w-5 h-5 rounded-full ${c.completed ? 'bg-emerald-500 text-white' : 'bg-amber-100 text-amber-800'} flex items-center justify-center font-bold text-xs shrink-0`}>
                              {c.completed ? '✓' : idx + 1}
                            </span>
                            <span className="font-bold text-slate-800">{c.task}</span>
                          </div>
                          <div className="flex justify-between items-center text-xs text-slate-500 border-t border-slate-100 pt-2">
                            <span>مسئول: <strong>{c.responsible || "لیدر تیم"}</strong></span>
                            <span>مهلت: <strong>{c.deadline || "۷ روز"}</strong></span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            ) : (
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-8 text-center text-sm text-slate-500">
                هیچ گزارش و تحلیل کیفی هوش مصنوعی برای این بخش صادر نشده است. ابتدا در بخش گزارش‌ها دکمه تحلیل تیمی را بفشارید.
              </div>
            )}
          </div>

          {/* Section 4: Behavioral Tags Observed (Only for individual teams) */}
          {!isAggregated && activeTeam && (
            <div className="space-y-4 page-break">
              <h2 className="text-lg font-black text-slate-900 border-r-4 border-amber-500 pr-2.5">
                ۴. شواهد رفتاری ثبت‌شده حین بازی (Behavioral Evidence Logs)
              </h2>
              <p className="text-sm text-slate-550 leading-relaxed font-medium">
                تسهیل‌گر در جریان فعالیت تیمی، این تگ‌های رفتاری عینی را مستقیماً از کار اعضای تیم استخراج و ثبت نموده است:
              </p>

              <div className="flex flex-wrap gap-2 pt-1">
                {activeTeam.behaviorTags && activeTeam.behaviorTags.length > 0 ? (
                  activeTeam.behaviorTags.map((tag, idx) => {
                    const isPositive = !tag.includes("❌");
                    return (
                      <span
                        key={idx}
                        className={`inline-flex items-center gap-1.5 text-sm font-bold px-3.5 py-1.5 rounded-xl border ${
                          isPositive
                            ? "bg-emerald-50 border-emerald-100 text-emerald-800"
                            : "bg-rose-50 border-rose-100 text-rose-800"
                        }`}
                      >
                        {tag}
                      </span>
                    );
                  })
                ) : (
                  <span className="text-sm text-slate-400 font-medium">هیچ تگ رفتاری برای این تیم ثبت نشده است.</span>
                )}
              </div>
            </div>
          )}

          {/* Individual Teams List (For Aggregated Report) */}
          {isAggregated && (
            <div className="space-y-6 page-break">
              <h2 className="text-lg font-black text-slate-900 border-r-4 border-amber-500 pr-2.5">
                ۴. وضعیت و خلاصه دیبریف تیمی تک‌تک تیم‌ها
              </h2>
              <div className="space-y-4">
                {event.teams.map((t) => {
                  const hasAn = event.analyses && event.analyses[t.id];
                  return (
                    <div key={t.id} className="bg-slate-50 p-5 rounded-2xl border border-slate-100 space-y-3 text-sm">
                      <div className="flex items-center justify-between border-b border-slate-200 pb-2 flex-wrap gap-2">
                        <span className="font-extrabold text-slate-900 text-base">تیم: {t.name} ({t.membersCount} عضو)</span>
                        <span className="font-mono text-slate-500 font-bold text-xs">
                          میانگین امتیاز پویایی: {Math.round(Object.values(t.postScores).reduce((a,b)=>a+b, 0)/5 * 10)/10} از ۱۰
                        </span>
                      </div>
                      
                      {t.behaviorTags && t.behaviorTags.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 items-center">
                          <span className="text-slate-400 font-bold self-center text-xs">رفتارهای مشاهده‌شده:</span>
                          {t.behaviorTags.map((tag, idx) => (
                            <span key={idx} className="bg-white border border-slate-200 text-xs font-bold px-2 py-0.5 rounded-md text-slate-700">
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}

                      {hasAn && event.analyses ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1 text-slate-600 leading-relaxed text-xs">
                          <div>
                            <span className="font-bold text-slate-800 block mb-1 text-xs">نقاط قوت تیمی:</span>
                            <ul className="space-y-1 list-disc list-inside">
                              {event.analyses[t.id].strengths.slice(0, 2).map((s, idx) => (
                                <li key={idx}><span className="font-bold text-slate-900">{s.title}:</span> {s.description}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <span className="font-bold text-slate-800 block mb-1 text-xs">چالش‌های تیمی و پویایی‌ها:</span>
                            <ul className="space-y-1 list-disc list-inside">
                              {event.analyses[t.id].weaknesses.slice(0, 2).map((w, idx) => (
                                <li key={idx}><span className="font-bold text-slate-900">{w.title}:</span> {w.description}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ) : (
                        <p className="text-slate-450">تحلیل کیفی هوش مصنوعی برای این تیم هنوز انجام نشده است.</p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Footer Signature */}
          <div className="border-t border-slate-200 pt-6 flex justify-between text-xs text-slate-400 font-bold">
            <span>حقوق مادی و معنوی محفوظ است ◆ تسهیل‌گری خلاق کامزی</span>
            <span>Comzee Team-Building Debrief Reports &copy; 2026</span>
          </div>

        </div>

      </div>

      {/* Embedded CSS for Page Break Print layout */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .print\\:absolute, .print\\:absolute * {
            visibility: visible;
          }
          .print\\:absolute {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: auto;
            background: white !important;
            color: black !important;
            padding: 0 !important;
            box-shadow: none !important;
          }
          .page-break {
            page-break-before: always;
            margin-top: 2rem;
          }
        }
      `}</style>

    </div>
  );
}
