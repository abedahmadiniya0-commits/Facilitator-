import React from "react";
import { ChevronLeft, ChevronRight, Home, ArrowLeft, ArrowRight, Gamepad2, TrendingUp, Sparkles, FolderOpen } from "lucide-react";

interface BreadcrumbWithBackProps {
  viewMode: "workshops" | "growth" | "assistant";
  selectedEventId: string | null;
  activeEventTitle: string | null;
  activeTab: "setup" | "teams" | "analysis";
  selectedTeamName: string | null;
  lightMode: boolean;
  onNavigateViewMode: (mode: "workshops" | "growth" | "assistant") => void;
  onNavigateTab: (tab: "setup" | "teams" | "analysis") => void;
  onClearEvent: () => void;
  onClearTeam: () => void;
}

export const BreadcrumbWithBack: React.FC<BreadcrumbWithBackProps> = ({
  viewMode,
  selectedEventId,
  activeEventTitle,
  activeTab,
  selectedTeamName,
  lightMode,
  onNavigateViewMode,
  onNavigateTab,
  onClearEvent,
  onClearTeam,
}) => {
  // Determine if we should show the back button
  const hasBackAction = viewMode !== "workshops" || selectedEventId !== null || selectedTeamName !== null;

  // Handle the back action based on the hierarchical state
  const handleBack = () => {
    if (selectedTeamName !== null) {
      // Step back from deep team analysis view to the main workshop analysis tab
      onClearTeam();
    } else if (selectedEventId !== null) {
      // Step back from active workshop view to the workshops list view
      onClearEvent();
    } else if (viewMode !== "workshops") {
      // Step back from other views to the main workshops list view
      onNavigateViewMode("workshops");
    }
  };

  return (
    <div className={`w-full flex items-center justify-between gap-4 py-3.5 px-4 md:px-6 rounded-2xl border transition-all ${
      lightMode
        ? "bg-white border-slate-200 shadow-sm text-slate-800"
        : "bg-slate-950/40 border-slate-900 text-slate-200"
    }`}>
      {/* Right Side: Persian/RTL Breadcrumbs */}
      <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs font-medium overflow-x-auto whitespace-nowrap scrollbar-none">
        {/* Level 1: Home/Workshops List */}
        <button
          onClick={() => {
            onNavigateViewMode("workshops");
            onClearEvent();
            onClearTeam();
          }}
          className={`flex items-center gap-1 hover:text-amber-500 transition-colors cursor-pointer ${
            viewMode === "workshops" && selectedEventId === null ? "text-amber-500 font-bold" : "text-slate-400"
          }`}
        >
          <Home className="w-3.5 h-3.5" />
          <span>میز کار تسهیل‌گری</span>
        </button>

        {/* Level 2: Sub-views (HR Growth, Assistant, or Event Title) */}
        {viewMode === "growth" && (
          <>
            <ChevronLeft className="w-3.5 h-3.5 text-slate-500 rtl:rotate-180" />
            <span className="text-amber-500 font-bold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              داشبورد مقایسه‌ای مشتری (HR Growth)
            </span>
          </>
        )}

        {viewMode === "assistant" && (
          <>
            <ChevronLeft className="w-3.5 h-3.5 text-slate-500 rtl:rotate-180" />
            <span className="text-amber-500 font-bold flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              دستیار هوشمند دیبریف (پروژکتور)
            </span>
          </>
        )}

        {viewMode === "workshops" && selectedEventId !== null && activeEventTitle && (
          <>
            <ChevronLeft className="w-3.5 h-3.5 text-slate-500 rtl:rotate-180" />
            <button
              onClick={() => {
                onClearTeam();
              }}
              className={`hover:text-amber-500 transition-colors cursor-pointer ${
                selectedTeamName === null ? "text-amber-500 font-bold" : "text-slate-400"
              }`}
            >
              <span className="flex items-center gap-1">
                <FolderOpen className="w-3.5 h-3.5" />
                {activeEventTitle}
              </span>
            </button>

            {/* Level 3: Active Tab (Setup, Teams, Analysis) */}
            <ChevronLeft className="w-3.5 h-3.5 text-slate-500 rtl:rotate-180" />
            <button
              onClick={() => {
                if (activeTab === "setup") onNavigateTab("setup");
                if (activeTab === "teams") onNavigateTab("teams");
                if (activeTab === "analysis") onNavigateTab("analysis");
                onClearTeam();
              }}
              className={`hover:text-amber-500 transition-colors cursor-pointer ${
                selectedTeamName === null ? "text-amber-500 font-bold" : "text-slate-400"
              }`}
            >
              {activeTab === "setup" && "۱. مشخصات و اهداف"}
              {activeTab === "teams" && "۲. تیم‌ها و امتیازدهی"}
              {activeTab === "analysis" && "۳. گزارش دیبریف"}
            </button>

            {/* Level 4: Active Team AI Analysis */}
            {selectedTeamName !== null && (
              <>
                <ChevronLeft className="w-3.5 h-3.5 text-slate-500 rtl:rotate-180" />
                <span className="text-amber-500 font-bold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  تحلیل هوشمند {selectedTeamName}
                </span>
              </>
            )}
          </>
        )}
      </nav>

      {/* Left Side: Back Button */}
      {hasBackAction ? (
        <button
          onClick={handleBack}
          aria-label="Back"
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-extrabold transition-all duration-200 cursor-pointer select-none active:scale-95 ${
            lightMode
              ? "bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300 hover:border-slate-400 active:bg-slate-300"
              : "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800 hover:border-slate-700 active:bg-slate-950/80"
          }`}
        >
          {/* arrow-right or chevron-right icon, which goes "back" in Persian/RTL context */}
          <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          <span>بازگشت</span>
        </button>
      ) : (
        <div className="text-[10px] text-slate-500 font-medium hidden sm:block">
          صفحه اصلی مدیریت کارگاه کامزی
        </div>
      )}
    </div>
  );
};

export default BreadcrumbWithBack;
