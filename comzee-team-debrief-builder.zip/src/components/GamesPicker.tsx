import React, { useState } from "react";
import { DEFAULT_GAMES, GameDefinition } from "../data/games";
import { TeamScores, SCORE_LABELS } from "../types";
import { Gamepad2, Clock, Plus, X, HelpCircle, Sparkles, BookOpen } from "lucide-react";

interface GamesPickerProps {
  selectedGames: string[];
  customGames: string[];
  onToggleGame: (gameId: string) => void;
  onAddCustomGame: (gameName: string) => void;
  onRemoveCustomGame: (gameName: string) => void;
}

const GamesPicker: React.FC<GamesPickerProps> = ({
  selectedGames = [],
  customGames = [],
  onToggleGame,
  onAddCustomGame,
  onRemoveCustomGame,
}) => {
  const [customInput, setCustomInput] = useState("");
  const [expandedGameId, setExpandedGameId] = useState<string | null>(null);

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = customInput.trim();
    if (trimmed && !customGames.includes(trimmed)) {
      onAddCustomGame(trimmed);
      setCustomInput("");
    }
  };

  const getDimensionLabel = (dimension: keyof TeamScores) => {
    return SCORE_LABELS[dimension]?.fa || dimension;
  };

  return (
    <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-5 text-right font-sans">
      <div className="flex items-center justify-between pb-3 border-b border-slate-900">
        <div className="space-y-1">
          <h3 className="text-xs font-bold text-slate-300 flex items-center gap-2">
            <Gamepad2 className="w-4 h-4 text-amber-500" />
            بازی‌ها و فعالیت‌های تجربی شبیه‌سازی شده
          </h3>
          <p className="text-[10px] text-slate-400">
            فعالیت‌های انجام شده در کارگاه را انتخاب کنید تا سوالات و تحلیل‌ها بر اساس مکانیک این بازی‌ها تنظیم شوند.
          </p>
        </div>
        <span className="text-[10px] bg-amber-500/10 text-amber-400 font-extrabold px-2.5 py-1 rounded-full border border-amber-500/20">
          {selectedGames.length + customGames.length} فعالیت ثبت شده
        </span>
      </div>

      {/* Grid of Default Games */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 max-h-[360px] overflow-y-auto pr-1">
        {DEFAULT_GAMES.map((game) => {
          const isSelected = selectedGames.includes(game.id);
          const isExpanded = expandedGameId === game.id;

          return (
            <div
              key={game.id}
              className={`rounded-xl border transition-all duration-300 flex flex-col justify-between overflow-hidden ${
                isSelected
                  ? "bg-amber-500/10 border-amber-500/30 text-slate-100 shadow-md shadow-amber-500/5"
                  : "bg-slate-900/40 border-slate-900/60 text-slate-400 hover:border-slate-800"
              }`}
            >
              {/* Clickable Header Area */}
              <div
                onClick={() => onToggleGame(game.id)}
                className="p-3.5 cursor-pointer flex items-start justify-between gap-3 select-none"
              >
                <div className="space-y-1.5 text-right flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className={`text-xs font-extrabold transition-colors ${isSelected ? "text-amber-300" : "text-slate-300"}`}>
                      {game.name}
                    </span>
                    <span className="text-[9px] font-mono text-slate-500">
                      ({game.englishName})
                    </span>
                  </div>

                  {/* Focus Dimension Badges */}
                  <div className="flex flex-wrap gap-1">
                    {game.focusDimensions.map((dim) => (
                      <span
                        key={dim}
                        className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded ${
                          isSelected
                            ? "bg-amber-500/20 text-amber-300"
                            : "bg-slate-950/60 text-slate-400"
                        }`}
                      >
                        {getDimensionLabel(dim)}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Checked Indicator */}
                <span className={`w-4 h-4 rounded-full flex-shrink-0 flex items-center justify-center border transition-all ${
                  isSelected ? "bg-amber-500 border-amber-400 text-slate-950" : "border-slate-800 text-transparent"
                }`}>
                  ✓
                </span>
              </div>

              {/* Collapsible Details Area */}
              <div className="px-3.5 pb-3 border-t border-slate-900/40 pt-2 bg-slate-950/20 space-y-2">
                <div className="flex items-center justify-between text-[9px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    مدت زمان: {game.duration}
                  </span>
                  <button
                    type="button"
                    onClick={() => setExpandedGameId(isExpanded ? null : game.id)}
                    className="text-amber-500/85 hover:text-amber-400 transition-colors font-bold flex items-center gap-0.5"
                  >
                    <BookOpen className="w-3 h-3" />
                    {isExpanded ? "بستن جزئیات" : "مشاهده سناریو و اهداف"}
                  </button>
                </div>

                {isExpanded && (
                  <div className="text-[10px] space-y-2 leading-relaxed text-slate-300 pt-1.5 border-t border-slate-900/60 animate-fade-in">
                    <p>
                      <strong className="text-amber-300">خلاصه سناریو: </strong>
                      {game.description}
                    </p>
                    <p>
                      <strong className="text-slate-400">ابزارهای مورد نیاز: </strong>
                      {game.setupRequirements}
                    </p>
                    <p>
                      <strong className="text-slate-400">تمرکز دیبریف: </strong>
                      {game.debriefFocus}
                    </p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Custom Game Creation Form */}
      <div className="pt-3 border-t border-slate-900/80 space-y-3">
        <form onSubmit={handleAddCustom} className="flex gap-2">
          <input
            type="text"
            placeholder="آیا بازی سفارشی دیگری بازی کرده‌اید؟ نام آن را بنویسید..."
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            className="flex-1 bg-slate-900 border border-slate-850 rounded-xl px-3.5 py-2 text-[11px] text-slate-200 focus:outline-none focus:border-amber-500 transition-colors"
          />
          <button
            type="submit"
            className="bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-amber-400 hover:text-amber-300 px-4 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            افزودن
          </button>
        </form>

        {/* Custom Games Chips */}
        {customGames.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-1">
            {customGames.map((game, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1 bg-slate-900/60 border border-slate-850 text-slate-300 text-[10px] px-2.5 py-1 rounded-lg hover:border-red-500/30 group transition-all"
              >
                <span>{game}</span>
                <button
                  type="button"
                  onClick={() => onRemoveCustomGame(game)}
                  className="text-slate-500 hover:text-red-400 p-0.5 rounded transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default GamesPicker;
