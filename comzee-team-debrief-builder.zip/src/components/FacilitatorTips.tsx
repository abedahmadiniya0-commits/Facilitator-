/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { HelpCircle, Shield, Compass, Zap, MessageSquareCode } from "lucide-react";

export default function FacilitatorTips() {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 space-y-6 dir-rtl text-right font-sans">
      <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
        <div className="p-2 bg-amber-500/10 rounded-lg text-amber-400">
          <HelpCircle className="w-6 h-6" />
        </div>
        <div>
          <h3 className="font-bold text-lg text-white">جعبه ابزار تسهیل‌گر ارشد کامزی</h3>
          <p className="text-xs text-slate-400 mt-0.5">چگونه یک دیبریف تجربی و عمیق اجرا کنیم؟</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Step 1: ORID */}
        <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-amber-400">
            <Compass className="w-4 h-4" />
            <h4 className="font-bold text-sm">چارچوب استاندارد ORID در دیبریف</h4>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            دیبریف را به ترتیب زیر هدایت کنید تا فرآیند یادگیری به صورت طبیعی در ذهن شرکت‌کنندگان بنشیند:
          </p>
          <ul className="list-disc list-inside text-xs text-slate-300 space-y-1 pr-1">
            <li><strong className="text-amber-300">O (Objective):</strong> واقعیات فیزیکی؛ «چه اتفاقی افتاد؟ سناریو چطور طی شد؟»</li>
            <li><strong className="text-amber-300">R (Reflective):</strong> احساسات؛ «کجا هیجان‌زده شدید؟ کجا ناامید شدید؟»</li>
            <li><strong className="text-amber-300">I (Interpretive):</strong> تفسیر؛ «این چالش‌ها چه شباهتی به کارهای واقعی ما در شرکت دارند؟»</li>
            <li><strong className="text-amber-300">D (Decisive):</strong> تصمیم؛ «دفعه بعد در سازمان چه قولی به هم می‌دهیم؟»</li>
          </ul>
        </div>

        {/* Step 2: Safety */}
        <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-sky-400">
            <Shield className="w-4 h-4" />
            <h4 className="font-bold text-sm">حفظ امنیت روانی (Psychological Safety)</h4>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            هیچ تیمی در فضای اتهام یاد نمی‌گیرد. وظیفه تسهیل‌گر حفظ فضای امن برای بیان چالش‌هاست:
          </p>
          <ul className="list-disc list-inside text-xs text-slate-300 space-y-1 pr-1">
            <li>اشتباهات بازی را به عنوان "معدن طلا" و داده‌های باارزش تعریف کنید.</li>
            <li>به جای اشاره به افراد، به رفتارهای تیمی و ساختارها اشاره کنید.</li>
            <li>از سوالات باز استفاده کنید و سکوت‌ها را با صبوری پذیرا باشید.</li>
          </ul>
        </div>

        {/* Step 3: Powerful Questions */}
        <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-emerald-400">
            <MessageSquareCode className="w-4 h-4" />
            <h4 className="font-bold text-sm">سوالات باز و قدرتمند (Power Questions)</h4>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            به جای پاسخ دادن، با پرسیدن سوالات عمیق، تیم را به خودآگاهی برسانید:
          </p>
          <ul className="list-disc list-inside text-xs text-slate-300 space-y-1 pr-1">
            <li>«وقتی زمان رو به اتمام بود، مدل تصمیم‌گیری شما چه تغییری کرد؟»</li>
            <li>«اگر می‌توانستید بازی را دوباره از صفر شروع کنید، چه کاری را کاملا متفاوت انجام می‌دادید؟»</li>
            <li>«کدام پویایی این سناریو، دقیقاً شبیه به چالش‌های روزمره شما در کارگاه/دفتر کار است؟»</li>
          </ul>
        </div>

        {/* Step 4: Comzee Style */}
        <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-rose-400">
            <Zap className="w-4 h-4" />
            <h4 className="font-bold text-sm">فلسفه دیبریف تجربی کامزی</h4>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed font-semibold">
            "بازی بستری برای آشکار شدن ناخودآگاه تیم است."
          </p>
          <p className="text-xs text-slate-300 leading-relaxed">
            یادگیری تجربی زمانی به نتیجه می‌رسد که شرکت‌کننده خودش فرمول موفقیت را کشف کند. از نصیحت مستقیم بپرهیزید و بگذارید هوش مصنوعیِ ما و تحلیل داده‌ها، آینه‌ای در برابر عملکرد واقعی آن‌ها باشد.
          </p>
        </div>
      </div>
    </div>
  );
}
