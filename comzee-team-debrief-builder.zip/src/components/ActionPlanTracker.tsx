/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Team, ActionPlan, ActionItem } from "../types";
import {
  CheckSquare,
  Square,
  Mail,
  User,
  Clock,
  Send,
  Plus,
  Trash2,
  AlertCircle,
  Calendar,
  Sparkles,
  CheckCircle,
  BellRing
} from "lucide-react";

interface ActionPlanTrackerProps {
  team: Team;
  defaultSuggestions?: { actionableStep: string; officeApplication: string }[];
  onUpdateActionPlan: (actionPlan: ActionPlan) => void;
}

export default function ActionPlanTracker({
  team,
  defaultSuggestions = [],
  onUpdateActionPlan
}: ActionPlanTrackerProps) {
  // Initialize action plan state
  const [leaderName, setLeaderName] = useState(team.actionPlan?.leaderName || "");
  const [leaderEmail, setLeaderEmail] = useState(team.actionPlan?.leaderEmail || "");
  const [commitments, setCommitments] = useState<ActionItem[]>(
    team.actionPlan?.commitments || []
  );
  const [followUpSent, setFollowUpSent] = useState(team.actionPlan?.followUpSent || false);
  const [showNotification, setShowNotification] = useState<{
    show: boolean;
    message: string;
    type: "success" | "info";
  }>({ show: false, message: "", type: "info" });

  // Calculate default follow-up date (7 days from now)
  const getOneWeekLaterDate = () => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toLocaleDateString("fa-IR", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  const followUpDateStr = team.actionPlan?.followUpDate || getOneWeekLaterDate();

  // Save changes back to parent
  const saveActionPlan = (
    newLeaderName: string,
    newLeaderEmail: string,
    newCommitments: ActionItem[],
    newFollowUpSent: boolean
  ) => {
    onUpdateActionPlan({
      leaderName: newLeaderName,
      leaderEmail: newLeaderEmail,
      commitments: newCommitments,
      followUpSent: newFollowUpSent,
      followUpDate: followUpDateStr
    });
  };

  // Pre-fill commitments using AI suggestions if empty
  const handleLoadSuggestions = () => {
    if (defaultSuggestions.length === 0) return;
    const initialItems: ActionItem[] = defaultSuggestions.slice(0, 3).map((s, index) => ({
      id: `ai-suggested-${index}-${Date.now()}`,
      task: s.actionableStep,
      responsible: "لیدر تیم",
      deadline: "هفته اول پس از کارگاه",
      completed: false
    }));
    setCommitments(initialItems);
    saveActionPlan(leaderName, leaderEmail, initialItems, followUpSent);
    triggerNotification("۳ تعهد بر اساس پیشنهادات هوش مصنوعی کامزی با موفقیت بارگذاری شد.", "success");
  };

  const handleAddCommitment = () => {
    if (commitments.length >= 3) {
      triggerNotification("طبق استانداردهای دیبریف کامزی، حداکثر ۳ تعهد مشخص برای تمرکز تیمی کافی است.", "info");
      return;
    }
    const newItem: ActionItem = {
      id: `custom-${Date.now()}`,
      task: "",
      responsible: "",
      deadline: "۱ هفته",
      completed: false
    };
    const updated = [...commitments, newItem];
    setCommitments(updated);
    saveActionPlan(leaderName, leaderEmail, updated, followUpSent);
  };

  const handleRemoveCommitment = (id: string) => {
    const updated = commitments.filter((item) => item.id !== id);
    setCommitments(updated);
    saveActionPlan(leaderName, leaderEmail, updated, followUpSent);
  };

  const handleUpdateCommitment = (id: string, field: keyof ActionItem, value: any) => {
    const updated = commitments.map((item) => {
      if (item.id === id) {
        return { ...item, [field]: value };
      }
      return item;
    });
    setCommitments(updated);
    saveActionPlan(leaderName, leaderEmail, updated, followUpSent);
  };

  const handleToggleComplete = (id: string) => {
    const updated = commitments.map((item) => {
      if (item.id === id) {
        return { ...item, completed: !item.completed };
      }
      return item;
    });
    setCommitments(updated);
    saveActionPlan(leaderName, leaderEmail, updated, followUpSent);
  };

  const triggerNotification = (message: string, type: "success" | "info") => {
    setShowNotification({ show: true, message, type });
    setTimeout(() => {
      setShowNotification({ show: false, message: "", type: "info" });
    }, 5000);
  };

  // Simulate automated follow-up email trigger
  const handleSimulateFollowUp = () => {
    if (!leaderEmail || !leaderEmail.includes("@")) {
      triggerNotification("لطفاً یک ایمیل معتبر برای لیدر تیم ثبت کنید تا سیستم بتواند پیگیری را شبیه‌سازی کند.", "info");
      return;
    }
    if (commitments.length === 0) {
      triggerNotification("ابتدا تعهدات تیم را مشخص کنید.", "info");
      return;
    }

    setFollowUpSent(true);
    saveActionPlan(leaderName, leaderEmail, commitments, true);
    triggerNotification(`✉️ پیام پیگیری اتوماتیک کامزی با موفقیت به آدرس (${leaderEmail}) شبیه‌سازی و ارسال شد!`, "success");
  };

  return (
    <div className="bg-slate-950/80 border border-slate-900 rounded-3xl p-6 space-y-6 text-slate-200 text-right font-sans">
      
      {/* Header and explanation */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-900 pb-4">
        <div className="space-y-1">
          <h4 className="font-extrabold text-base text-white flex items-center gap-2">
            <span className="p-1.5 bg-amber-500/10 rounded-lg text-amber-500">
              <CheckSquare className="w-5 h-5" />
            </span>
            برنامه اقدام و تعهدات تیمی (Action Plan Tracker)
          </h4>
          <p className="text-xs text-slate-400">
            دیبریف نباید در سالن همایش تمام شود؛ ۳ تعهد مشخص برای تغییر واقعی در محیط کار بسازید.
          </p>
        </div>
        
        {defaultSuggestions.length > 0 && commitments.length === 0 && (
          <button
            onClick={handleLoadSuggestions}
            className="px-3.5 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            پیشنهاد خودکار تعهدات (AI)
          </button>
        )}
      </div>

      {/* Alert Notification */}
      {showNotification.show && (
        <div
          className={`p-3.5 rounded-xl text-xs font-bold flex items-center gap-2 border leading-relaxed animate-fade-in ${
            showNotification.type === "success"
              ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
              : "bg-amber-500/10 border-amber-500/20 text-amber-400"
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{showNotification.message}</span>
        </div>
      )}

      {/* Action items digital checklist */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-300">چک‌لیست تعهدات تیمی (حداکثر ۳ مورد):</span>
          <span className="text-[11px] font-mono text-slate-500">تعداد انتخاب شده: {commitments.length} / ۳</span>
        </div>

        {commitments.length === 0 ? (
          <div className="border border-dashed border-slate-800 rounded-2xl p-8 text-center space-y-3">
            <BellRing className="w-8 h-8 text-slate-700 mx-auto" />
            <p className="text-xs text-slate-500">هیچ تعهد کاری ثبت نشده است. برای رشد تیمی، ۳ اقدام تعیین کنید.</p>
            <button
              onClick={handleAddCommitment}
              className="mx-auto px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              تعریف تعهد جدید
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {commitments.map((item, index) => (
              <div
                key={item.id}
                className={`bg-slate-900/40 border p-4 rounded-2xl transition-all space-y-3 ${
                  item.completed ? "border-emerald-500/20 bg-emerald-500/5" : "border-slate-800"
                }`}
              >
                <div className="flex items-start gap-3">
                  <button
                    onClick={() => handleToggleComplete(item.id)}
                    className="mt-1 text-slate-400 hover:text-amber-500 transition-colors"
                  >
                    {item.completed ? (
                      <CheckCircle className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <Square className="w-5 h-5" />
                    )}
                  </button>

                  <div className="flex-1 space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold text-slate-500 bg-slate-900 px-2 py-0.5 rounded font-mono">
                        تعهد {index + 1}
                      </span>
                      <input
                        type="text"
                        value={item.task}
                        onChange={(e) => handleUpdateCommitment(item.id, "task", e.target.value)}
                        placeholder="چه تغییر مشخصی ایجاد می‌کنید؟ (مثال: برگزاری روزانه هماهنگی ۱۰ دقیقه‌ای)"
                        className="w-full bg-transparent text-slate-200 text-xs font-bold focus:outline-none border-b border-transparent focus:border-amber-500/40 pb-1"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-900">
                        <User className="w-3.5 h-3.5 text-slate-500" />
                        <span className="text-slate-500 font-medium">مسئول پیگیری:</span>
                        <input
                          type="text"
                          value={item.responsible}
                          onChange={(e) => handleUpdateCommitment(item.id, "responsible", e.target.value)}
                          placeholder="نام شخص یا لیدر"
                          className="bg-transparent text-slate-300 focus:outline-none flex-1 text-xs text-left"
                        />
                      </div>

                      <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-900">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        <span className="text-slate-500 font-medium">مهلت انجام:</span>
                        <input
                          type="text"
                          value={item.deadline}
                          onChange={(e) => handleUpdateCommitment(item.id, "deadline", e.target.value)}
                          placeholder="مثلاً ۱ هفته، شنبه آینده"
                          className="bg-transparent text-slate-300 focus:outline-none flex-1 text-xs text-left"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleRemoveCommitment(item.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                    title="حذف تعهد"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

            {commitments.length < 3 && (
              <button
                onClick={handleAddCommitment}
                className="w-full py-3 border border-dashed border-slate-800 hover:border-amber-500/30 text-slate-400 hover:text-amber-400 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer bg-transparent"
              >
                <Plus className="w-4 h-4" />
                افزودن تعهد کاری جدید ({3 - commitments.length} ظرفیت باقی‌مانده)
              </button>
            )}
          </div>
        )}
      </div>

      {/* Leader info & Automatic follow-up engine */}
      <div className="bg-slate-900/30 border border-slate-900 rounded-2xl p-5 space-y-4">
        <h5 className="font-extrabold text-xs text-white flex items-center gap-2">
          <Mail className="w-4 h-4 text-amber-500" />
          تنظیمات لیدر و موتور پیگیری خودکار (Automated Follow-up)
        </h5>
        
        <p className="text-[11px] text-slate-400 leading-relaxed">
          برای تداوم یادگیری، سامانه به صورت خودکار یک هفته پس از کارگاه، پیام پیگیری به همراه چک‌لیست دیجیتال فوق را به لیدر تیم ارسال می‌کند تا تعهدات بررسی و پیگیری شوند.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 font-medium">نام لیدر تیم / هماهنگ‌کننده</label>
            <div className="bg-slate-950/60 border border-slate-900 p-2.5 rounded-xl flex items-center gap-2">
              <User className="w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={leaderName}
                onChange={(e) => {
                  setLeaderName(e.target.value);
                  saveActionPlan(e.target.value, leaderEmail, commitments, followUpSent);
                }}
                placeholder="مثال: علیرضا احمدی"
                className="w-full bg-transparent focus:outline-none text-slate-200 text-xs"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 font-medium">ایمیل لیدر تیم (ارسال اتوماتیک)</label>
            <div className="bg-slate-950/60 border border-slate-900 p-2.5 rounded-xl flex items-center gap-2">
              <Mail className="w-4 h-4 text-slate-500" />
              <input
                type="email"
                value={leaderEmail}
                onChange={(e) => {
                  setLeaderEmail(e.target.value);
                  saveActionPlan(leaderName, e.target.value, commitments, followUpSent);
                }}
                placeholder="leader@company.com"
                className="w-full bg-transparent focus:outline-none text-slate-200 text-xs text-left font-mono"
              />
            </div>
          </div>
        </div>

        {/* Status of automatic follow-up */}
        <div className="pt-3 border-t border-slate-900/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-500" />
            <span className="text-slate-400">وضعیت پیگیری اتوماتیک:</span>
            {followUpSent ? (
              <span className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-2.5 py-1 rounded-lg text-[10px] font-bold">
                ✓ ایمیل پیگیری ارسال شد
              </span>
            ) : (
              <span className="bg-amber-500/10 border border-amber-500/20 text-amber-400 px-2.5 py-1 rounded-lg text-[10px] font-bold">
                ⏳ زمان‌بندی شده برای پیگیری: {followUpDateStr} (۷ روز دیگر)
              </span>
            )}
          </div>

          <button
            onClick={handleSimulateFollowUp}
            disabled={commitments.length === 0}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-30 disabled:pointer-events-none text-slate-950 font-extrabold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md cursor-pointer self-end sm:self-auto"
          >
            <Send className="w-3.5 h-3.5" />
            تست و ارسال فوری ایمیل پیگیری
          </button>
        </div>
      </div>

    </div>
  );
}
