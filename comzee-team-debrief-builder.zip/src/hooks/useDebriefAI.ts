import { useState, useEffect, useRef } from "react";
import { Event, Team, TeamScores, SCORE_LABELS, DebriefAnalysis } from "../types";
import { DEFAULT_GAMES } from "../data/games";

export interface UseDebriefAIOptions {
  events: Event[];
  activeEvent: Event | null;
  saveEvents: (updatedEvents: Event[]) => Promise<void>;
  setSelectedTeamIdForAnalysis: (teamId: string | null) => void;
}

// Helper to calculate average and aggregate scores for multiple teams
function getAggregatedScores(teams: Team[]): { preScores: TeamScores; postScores: TeamScores; averageMembersCount: number } {
  const defaultScores = { communication: 0, trust: 0, coordination: 0, problemSolving: 0, resilience: 0 };
  if (!teams || teams.length === 0) {
    return {
      preScores: { ...defaultScores },
      postScores: { ...defaultScores },
      averageMembersCount: 0,
    };
  }

  const preScores = { ...defaultScores };
  const postScores = { ...defaultScores };
  let totalMembers = 0;

  teams.forEach((t) => {
    preScores.communication += t.preScores?.communication || 0;
    preScores.trust += t.preScores?.trust || 0;
    preScores.coordination += t.preScores?.coordination || 0;
    preScores.problemSolving += t.preScores?.problemSolving || 0;
    preScores.resilience += t.preScores?.resilience || 0;

    postScores.communication += t.postScores?.communication || 0;
    postScores.trust += t.postScores?.trust || 0;
    postScores.coordination += t.postScores?.coordination || 0;
    postScores.problemSolving += t.postScores?.problemSolving || 0;
    postScores.resilience += t.postScores?.resilience || 0;

    totalMembers += t.membersCount || 0;
  });

  const count = teams.length;
  return {
    preScores: {
      communication: Math.round((preScores.communication / count) * 10) / 10,
      trust: Math.round((preScores.trust / count) * 10) / 10,
      coordination: Math.round((preScores.coordination / count) * 10) / 10,
      problemSolving: Math.round((preScores.problemSolving / count) * 10) / 10,
      resilience: Math.round((preScores.resilience / count) * 10) / 10,
    },
    postScores: {
      communication: Math.round((postScores.communication / count) * 10) / 10,
      trust: Math.round((postScores.trust / count) * 10) / 10,
      coordination: Math.round((postScores.coordination / count) * 10) / 10,
      problemSolving: Math.round((postScores.problemSolving / count) * 10) / 10,
      resilience: Math.round((postScores.resilience / count) * 10) / 10,
    },
    averageMembersCount: Math.round(totalMembers / count),
  };
}

export function useDebriefAI({
  events,
  activeEvent,
  saveEvents,
  setSelectedTeamIdForAnalysis,
}: UseDebriefAIOptions) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgressMsg, setAnalysisProgressMsg] = useState("");
  const [errorBanner, setErrorBanner] = useState<{ title: string; message: string } | null>(null);
  const [isGeneratingQuestions, setIsGeneratingQuestions] = useState<Record<string, boolean>>({});

  const progressIntervalRef = useRef<any>(null);

  // Helper to safely clear interval
  const clearProgressInterval = () => {
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      clearProgressInterval();
    };
  }, []);

  const getFriendlyErrorMessage = (errMsg: string) => {
    if (
      errMsg.includes("429") ||
      errMsg.includes("RESOURCE_EXHAUSTED") ||
      errMsg.includes("quota") ||
      errMsg.includes("Quota exceeded")
    ) {
      return "سقف مجاز روزانه یا حد درخواست‌های همزمان کلید هوش مصنوعی رایگان به پایان رسیده است (Quota Exceeded / Rate Limit). لطفاً ۱ الی ۲ دقیقه بعد مجدداً تلاش کنید، یا نسبت به ارتقا/بررسی کلید اعتباری خود در بخش تنظیمات اقدام فرمایید.";
    }
    return errMsg;
  };

  // Call server-side Gemini AI for All Teams combined analysis
  const handleRunAllTeamsAnalysis = async () => {
    if (!activeEvent || activeEvent.teams.length === 0) return;

    clearProgressInterval();
    setIsAnalyzing(true);
    setAnalysisProgressMsg("در حال محاسبه میانگین نمرات و تجمیع رفتارهای تمام تیم‌ها...");

    const aggregated = getAggregatedScores(activeEvent.teams);
    
    // Combine notes and reflections of all teams for the prompt context
    const combinedPreNotes = activeEvent.teams.map((t) => `${t.name}: ${t.preNotes || "بدون یادداشت"}`).join("\n");
    const combinedPostNotes = activeEvent.teams.map((t) => `${t.name}: ${t.postNotes || "بدون یادداشت"}`).join("\n");
    
    const combinedReflections = {
      whatWentWell: activeEvent.teams.map((t) => `${t.name}: ${t.reflection.whatWentWell || "ثبت نشده"}`).join("\n"),
      challenges: activeEvent.teams.map((t) => `${t.name}: ${t.reflection.challenges || "ثبت نشده"}`).join("\n"),
      learnings: activeEvent.teams.map((t) => `${t.name}: ${t.reflection.learnings || "ثبت نشده"}`).join("\n"),
      actionPlan: activeEvent.teams.map((t) => `${t.name}: ${t.reflection.actionPlan || "ثبت نشده"}`).join("\n"),
    };

    const combinedBehaviorTags = activeEvent.teams.flatMap((t) => t.behaviorTags || []);

    const allTeamsPseudo: Team = {
      id: "all_teams",
      name: "کل تیم‌ها (تجمیعی)",
      membersCount: activeEvent.teams.reduce((acc, t) => acc + (t.membersCount || 0), 0),
      preScores: aggregated.preScores,
      preNotes: `یادداشت‌های هم‌افزایی تمام تیم‌ها:\n${combinedPreNotes}`,
      postScores: aggregated.postScores,
      postNotes: `ملاحظات هم‌افزایی تمام تیم‌ها:\n${combinedPostNotes}`,
      reflection: combinedReflections,
      behaviorTags: combinedBehaviorTags,
    };

    // Stagger progress steps
    const progressSteps = [
      "در حال ارزیابی الگوهای رفتاری مابین کل تیم‌های کارگاه...",
      "بررسی و سنتز ارزیابی‌های تیمی بر اساس خروجی‌های کارگاه...",
      "ریشه‌یابی و ارزیابی تعارض‌های سیستمی بین تیم‌ها بر اساس روانشناسی سازمانی...",
      "تدوین توصیه‌های ویژه مدیران ارشد و ترانسفر کاری به دفتر واقعی (Workspace Transfer)...",
      "طراحی اسلایدهای ارائه نهایی با رویکرد تجمیعی...",
      "صدور دیبریف نهایی کل تیم‌ها..."
    ];

    let progressIdx = 0;
    progressIntervalRef.current = setInterval(() => {
      if (progressIdx < progressSteps.length) {
        setAnalysisProgressMsg(progressSteps[progressIdx]);
        progressIdx++;
      }
    }, 2500);

    const gamesPlayed = [
      ...(activeEvent.selectedGames || []).map((id) => {
        const defaultGame = DEFAULT_GAMES.find((g) => g.id === id);
        return defaultGame
          ? {
              name: defaultGame.name,
              description: defaultGame.description,
              focus: defaultGame.focusDimensions.map((d) => SCORE_LABELS[d]?.fa || d).join("، "),
            }
          : null;
      }).filter(Boolean),
      ...(activeEvent.customGames || []).map((name) => ({
        name: name,
        description: "بازی سفارشی طراحی شده توسط تسهیل‌گر",
        focus: "متنوع",
      })),
    ];

    try {
      const response = await fetch("/api/debrief/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          event: {
            title: activeEvent.title,
            clientName: activeEvent.clientName,
            facilitatorName: activeEvent.facilitatorName,
            goals: activeEvent.goals,
            gamesPlayed: gamesPlayed,
            aiTone: activeEvent.aiTone,
          },
          team: allTeamsPseudo,
        }),
      });

      clearProgressInterval();

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "خطا در تحلیل هوش مصنوعی تجمیعی");
      }

      const analysisResult: DebriefAnalysis = await response.json();
      
      // Update event with the analysis
      const updatedAnalyses = {
        ...(activeEvent.analyses || {}),
        "all_teams": {
          ...analysisResult,
          teamName: "خلاصه کل تیم‌ها (تجمیعی)"
        },
      };

      const updatedEvents = events.map((e) => {
        if (e.id === activeEvent.id) {
          return {
            ...e,
            analyses: updatedAnalyses,
            status: "completed" as const,
          };
        }
        return e;
      });

      await saveEvents(updatedEvents);
      setSelectedTeamIdForAnalysis("all_teams");
      setAnalysisProgressMsg("");
    } catch (err: any) {
      clearProgressInterval();
      setErrorBanner({
        title: "خطا در تحلیل تجمیعی کل تیم‌ها",
        message: getFriendlyErrorMessage(err.message || "")
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Call server-side Gemini AI for Team Debrief Analysis
  const handleRunAIAnalysis = async (team: Team) => {
    if (!activeEvent) return;
    
    clearProgressInterval();
    setIsAnalyzing(true);
    setAnalysisProgressMsg("در حال ارسال مشخصات رویداد و پویایی تیمی...");

    // Staggered exciting progress labels for facilitators
    const progressSteps = [
      "در حال ارزیابی پویایی‌های تیمی و ترسیم نقشه رشد...",
      "بررسی و تحلیل امتیازهای ثبت‌شده پویایی‌های تیمی...",
      "ریشه‌یابی و بررسی تعارض‌های رفتاری تیم با نگاه روانشناسی سازمانی...",
      "تدوین توصیه‌های ویژه تسهیل‌گری متناسب با الگوهای کار تیمی کامزی...",
      "طراحی اسلایدهای ارائه نهایی با رویکرد انتقال تجربه به دفتر کار واقعی...",
      "آماده‌سازی کابین تعاملی تسهیل‌گر..."
    ];

    let progressIdx = 0;
    progressIntervalRef.current = setInterval(() => {
      if (progressIdx < progressSteps.length) {
        setAnalysisProgressMsg(progressSteps[progressIdx]);
        progressIdx++;
      }
    }, 2500);

    const gamesPlayed = [
      ...(activeEvent.selectedGames || []).map((id) => {
        const defaultGame = DEFAULT_GAMES.find((g) => g.id === id);
        return defaultGame
          ? {
              name: defaultGame.name,
              description: defaultGame.description,
              focus: defaultGame.focusDimensions.map((d) => SCORE_LABELS[d]?.fa || d).join("، "),
            }
          : null;
      }).filter(Boolean),
      ...(activeEvent.customGames || []).map((name) => ({
        name: name,
        description: "بازی سفارشی طراحی شده توسط تسهیل‌گر",
        focus: "متنوع",
      })),
    ];

    try {
      const response = await fetch("/api/debrief/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          event: {
            title: activeEvent.title,
            clientName: activeEvent.clientName,
            facilitatorName: activeEvent.facilitatorName,
            goals: activeEvent.goals,
            gamesPlayed: gamesPlayed,
            aiTone: activeEvent.aiTone,
          },
          team: team,
        }),
      });

      clearProgressInterval();

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "خطا در تحلیل هوش مصنوعی");
      }

      const analysisResult: DebriefAnalysis = await response.json();
      
      // Update event with the analysis
      const updatedAnalyses = {
        ...(activeEvent.analyses || {}),
        [team.id]: analysisResult,
      };

      const updatedEvents = events.map((e) => {
        if (e.id === activeEvent.id) {
          return {
            ...e,
            analyses: updatedAnalyses,
            status: "completed" as const,
          };
        }
        return e;
      });

      await saveEvents(updatedEvents);
      setSelectedTeamIdForAnalysis(team.id);
      setAnalysisProgressMsg("");
    } catch (err: any) {
      clearProgressInterval();
      setErrorBanner({
        title: `خطا در تحلیل پویایی تیم ${team.name}`,
        message: getFriendlyErrorMessage(err.message || "")
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Call server-side Gemini AI to generate custom debrief questions
  const handleGenerateAIQuestions = async (team: Team) => {
    if (!activeEvent) return;

    setIsGeneratingQuestions((prev) => ({ ...prev, [team.id]: true }));

    const gamesPlayed = [
      ...(activeEvent.selectedGames || []).map((id) => {
        const defaultGame = DEFAULT_GAMES.find((g) => g.id === id);
        return defaultGame
          ? {
              name: defaultGame.name,
              description: defaultGame.description,
              focus: defaultGame.focusDimensions.map((d) => SCORE_LABELS[d]?.fa || d).join("، "),
            }
          : null;
      }).filter(Boolean),
      ...(activeEvent.customGames || []).map((name) => ({
        name: name,
        description: "بازی سفارشی طراحی شده توسط تسهیل‌گر",
        focus: "متنوع",
      })),
    ];

    try {
      const response = await fetch("/api/debrief/questions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          event: {
            title: activeEvent.title,
            clientName: activeEvent.clientName,
            facilitatorName: activeEvent.facilitatorName,
            goals: activeEvent.goals,
            gamesPlayed: gamesPlayed,
            aiTone: activeEvent.aiTone,
          },
          team: team,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "خطا در تولید سوالات هوشمند");
      }

      const result = await response.json();
      
      // Update team in the active event
      const updatedTeams = activeEvent.teams.map((t) => {
        if (t.id === team.id) {
          return {
            ...t,
            aiQuestions: result.questions,
          };
        }
        return t;
      });

      const updatedEvents = events.map((e) => {
        if (e.id === activeEvent.id) {
          return {
            ...e,
            teams: updatedTeams,
          };
        }
        return e;
      });

      await saveEvents(updatedEvents);
    } catch (err: any) {
      setErrorBanner({
        title: `خطا در تولید سوالات اختصاصی تیم ${team.name}`,
        message: getFriendlyErrorMessage(err.message || "")
      });
    } finally {
      setIsGeneratingQuestions((prev) => ({ ...prev, [team.id]: false }));
    }
  };

  return {
    isAnalyzing,
    analysisProgressMsg,
    errorBanner,
    setErrorBanner,
    isGeneratingQuestions,
    handleRunAllTeamsAnalysis,
    handleRunAIAnalysis,
    handleGenerateAIQuestions,
  };
}
