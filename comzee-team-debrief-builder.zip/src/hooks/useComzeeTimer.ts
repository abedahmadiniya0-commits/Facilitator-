import { useState, useEffect } from "react";

export function useComzeeTimer() {
  const [focusMode, setFocusMode] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(600);
  const [timerIsRunning, setTimerIsRunning] = useState(false);
  const [timerType, setTimerType] = useState<"countdown" | "countup">("countdown");

  // Timer runner useEffect
  useEffect(() => {
    let interval: any = null;
    if (timerIsRunning) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => {
          if (timerType === "countdown") {
            // Simply decrease without stopping here, to avoid the anti-pattern
            return prev > 0 ? prev - 1 : 0;
          } else {
            return prev + 1;
          }
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timerIsRunning, timerType]);

  // Separate effect to handle countdown completion
  useEffect(() => {
    if (timerType === "countdown" && timerSeconds <= 0 && timerIsRunning) {
      setTimerIsRunning(false);
    }
  }, [timerSeconds, timerType, timerIsRunning]);

  return {
    focusMode,
    setFocusMode,
    timerSeconds,
    setTimerSeconds,
    timerIsRunning,
    setTimerIsRunning,
    timerType,
    setTimerType,
  };
}
