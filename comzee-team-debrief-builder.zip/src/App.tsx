/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from "react";
import {
  Event,
  Team,
  TeamScores,
  SCORE_LABELS,
  DebriefAnalysis,
  PresentationSlide,
  AIQuestion,
} from "./types";
import FacilitatorTips from "./components/FacilitatorTips";
import DebriefPresentation from "./components/DebriefPresentation";
import DebriefChart from "./components/DebriefChart";
import ActionPlanTracker from "./components/ActionPlanTracker";
import ClientGrowthDashboard from "./components/ClientGrowthDashboard";
import ComzeeAssistant from "./components/ComzeeAssistant";
import BreadcrumbWithBack from "./components/BreadcrumbWithBack";
import {
  Sparkles,
  Plus,
  Trash2,
  Edit3,
  Tv,
  Brain,
  Award,
  AlertTriangle,
  Lightbulb,
  FileSpreadsheet,
  FolderOpen,
  Calendar,
  Users,
  Target,
  ArrowRight,
  TrendingUp,
  Sliders,
  CheckCircle2,
  FileDown,
  Printer,
  ChevronDown,
  Info,
  X,
  Copy,
  Check,
  HelpCircle,
  Gamepad2,
  Activity,
  Eye,
  Clock,
  Play,
  Pause,
  RotateCcw,
  Timer,
  Sun,
  Moon,
} from "lucide-react";

import GamesPicker from "./components/GamesPicker";
import B2BClientReport from "./components/B2BClientReport";
import ProjectorView from "./components/ProjectorView";
import LiveScoreSubmit from "./components/LiveScoreSubmit";
import { DEFAULT_GAMES } from "./data/games";
import { useComzeeTimer } from "./hooks/useComzeeTimer";
import { useDebriefAI } from "./hooks/useDebriefAI";
import { initAuth, googleSignIn, logout } from "./lib/firebase";
import { createFolder, uploadFileToFolder } from "./lib/drive";
import { CloudUpload, RefreshCw } from "lucide-react";

// Default standard event goals
const DEFAULT_GOALS = [
  "افزایش اعتماد و امنیت روانی میان اعضای جدید",
  "تقویت کانال‌های ارتباطی و تسهیم بدون مرز اطلاعات",
  "تمرین تقسیم نقش‌ها و هماهنگی در شرایط فشار و محدودیت زمان",
  "پرورش مهارت حل مسئله استراتژیک و تفکر خلاق",
  "ارتقای پایداری، تاب‌آوری و سازگاری تیمی در مواجهه با شکست",
];

// Predefined list of behavior tags for the quick-logger
export const QUICK_BEHAVIOR_TAGS = [
  { label: "شنوایی فعال ✓", type: "positive", value: "Active Listening ✓" },
  { label: "امنیت روانی ✓", type: "positive", value: "Psychological Safety ✓" },
  { label: "وضوح نقش‌ها ✓", type: "positive", value: "Role Clarity ✓" },
  { label: "حمایت و هم‌افزایی ✓", type: "positive", value: "Cooperation & Synergy ✓" },
  { label: "مدیریت زمان عالی ✓", type: "positive", value: "Great Time Management ✓" },
  { label: "استراتژی شفاف ✓", type: "positive", value: "Clear Strategy ✓" },
  { label: "تفکر جزیره‌ای ❌", type: "negative", value: "Silo Thinking ❌" },
  { label: "فرهنگ سرزنش ❌", type: "negative", value: "Blame Culture ❌" },
  { label: "اقدام عجولانه ❌", type: "negative", value: "Hasty Action ❌" },
  { label: "قطع صحبت دیگران ❌", type: "negative", value: "Interrupting Others ❌" },
  { label: "بایکوت ایده‌ها ❌", type: "negative", value: "Idea Blocking ❌" },
  { label: "ناهماهنگی در تقسیم کار ❌", type: "negative", value: "Coordination Failure ❌" },
];

// Helper to calculate average and aggregate scores for multiple teams
export function getAggregatedScores(teams: Team[]): { preScores: TeamScores; postScores: TeamScores; averageMembersCount: number } {
  const defaultScores = { communication: 0, trust: 0, coordination: 0, problemSolving: 0, resilience: 0 };
  if (!teams || teams.length === 0) {
    return {
      preScores: { ...defaultScores },
      postScores: { ...defaultScores },
      averageMembersCount: 0,
    };
  }

  const preScores = { ...defaultScores };
  const postScores = { ...defaultScores };
  let totalMembers = 0;

  teams.forEach((t) => {
    preScores.communication += t.preScores?.communication || 0;
    preScores.trust += t.preScores?.trust || 0;
    preScores.coordination += t.preScores?.coordination || 0;
    preScores.problemSolving += t.preScores?.problemSolving || 0;
    preScores.resilience += t.preScores?.resilience || 0;

    postScores.communication += t.postScores?.communication || 0;
    postScores.trust += t.postScores?.trust || 0;
    postScores.coordination += t.postScores?.coordination || 0;
    postScores.problemSolving += t.postScores?.problemSolving || 0;
    postScores.resilience += t.postScores?.resilience || 0;

    totalMembers += t.membersCount || 0;
  });

  const count = teams.length;
  return {
    preScores: {
      communication: Math.round((preScores.communication / count) * 10) / 10,
      trust: Math.round((preScores.trust / count) * 10) / 10,
      coordination: Math.round((preScores.coordination / count) * 10) / 10,
      problemSolving: Math.round((preScores.problemSolving / count) * 10) / 10,
      resilience: Math.round((preScores.resilience / count) * 10) / 10,
    },
    postScores: {
      communication: Math.round((postScores.communication / count) * 10) / 10,
      trust: Math.round((postScores.trust / count) * 10) / 10,
      coordination: Math.round((postScores.coordination / count) * 10) / 10,
      problemSolving: Math.round((postScores.problemSolving / count) * 10) / 10,
      resilience: Math.round((postScores.resilience / count) * 10) / 10,
    },
    averageMembersCount: Math.round(totalMembers / count),
  };
}

// Initial default state if localStorage is empty
const INITIAL_EVENTS: Event[] = [
  {
    id: "comzee-sample-event-3",
    title: "کارگاه پیشرفته پویایی تیمی و خلاقیت سازمان ملل",
    date: "1405-04-08",
    clientName: "شرکت فناوری ابری پیشتاز",
    facilitatorName: "احمدی‌نیا (تسهیل‌گر ارشد کامزی)",
    goals: [
      "تقویت کانال‌های ارتباطی و تسهیم بدون مرز اطلاعات",
      "تمرین تقسیم نقش‌ها و هماهنگی در شرایط فشار و محدودیت زمان",
    ],
    status: "active",
    teams: [
      {
        id: "team-alpha",
        name: "عقاب‌های نوآور",
        membersCount: 8,
        preScores: {
          communication: 4,
          trust: 5,
          coordination: 3,
          problemSolving: 6,
          resilience: 4,
        },
        preNotes: "تیم بسیار پرانرژی است اما در تقسیم کار اولیه دچار سردرگمی شدید شدند. رهبر مشخصی ندارند.",
        postScores: {
          communication: 8,
          trust: 7,
          coordination: 8,
          problemSolving: 9,
          resilience: 7,
        },
        postNotes: "در شبیه‌سازی دوم پازل‌ها، تقسیم وظایف عالی انجام شد. رضا نقش سخنگو را عالی ایفا کرد و به شدت شنونده خوبی شدند.",
        reflection: {
          whatWentWell: "گوش دادن فعال در فاز دوم بازی فوق‌العاده بهبود یافت و توانستیم زمان را ذخیره کنیم.",
          challenges: "در سناریو اول به دلیل اصرار دو نفر روی ایده خودمان، زمان را کلاً از دست دادیم.",
          learnings: "یاد گرفتیم که داشتن ایده خوب کافی نیست؛ هماهنگی در پیاده‌سازی و توافق سریع تیمی برگ برنده است.",
          actionPlan: "در جلسات اسپرینت هفتگی شرکت، ۵ دقیقه اول را کلاً به شفاف‌سازی نقش‌ها اختصاص می‌دهیم.",
        },
        actionPlan: {
          leaderName: "رضا کریمی",
          leaderEmail: "r.karimi@pehtazcloud.com",
          commitments: [
            {
              id: "item-1",
              task: "برگزاری روزانه جلسات هماهنگی ایستاده ۵ دقیقه‌ای قبل از تسک‌ها",
              responsible: "رضا کریمی (لیدر)",
              deadline: "شنبه آینده",
              completed: false
            },
            {
              id: "item-2",
              task: "ایجاد کانال اسلک مجزا برای تسهیم سریع اخبار بحرانی پروژه",
              responsible: "مریم احمدی",
              deadline: "۳ روز دیگر",
              completed: true
            }
          ],
          followUpSent: false,
          followUpDate: "۱۴۰۵-۰۴-۱۵"
        }
      },
    ],
    analyses: {},
  },
  {
    id: "comzee-sample-event-2",
    title: "شبیه‌سازی بقا در کوهستان و مدیریت بحران",
    date: "1404-12-10",
    clientName: "شرکت فناوری ابری پیشتاز",
    facilitatorName: "احمدی‌نیا (تسهیل‌گر ارشد کامزی)",
    goals: [
      "پرورش مهارت حل مسئله استراتژیک و تفکر خلاق",
      "ارتقای پایداری، تاب‌آوری و سازگاری تیمی در مواجهه با شکست",
    ],
    status: "completed",
    teams: [
      {
        id: "team-beta-1",
        name: "تک‌آوران ابری",
        membersCount: 10,
        preScores: {
          communication: 5,
          trust: 5,
          coordination: 5,
          problemSolving: 6,
          resilience: 5,
        },
        preNotes: "تیم در ابتدا دچار ناهماهنگی شد اما در فاز نجات به سرعت خود را بازسازی کرد.",
        postScores: {
          communication: 7,
          trust: 7,
          coordination: 7,
          problemSolving: 8,
          resilience: 7,
        },
        postNotes: "استراتژی نجات به خوبی پیاده شد و توانستند جزو تیم‌های برتر صعودکننده باشند.",
        reflection: {
          whatWentWell: "توانایی پذیرش خطا و تغییر سریع سناریو پس از بهمن اول بازی عالی بود.",
          challenges: "محدودیت زمان و اضطراب ناشی از کاهش منابع تیم را کمی تحت فشار قرار داد.",
          learnings: "یاد گرفتیم در بحران‌ها حفظ خونسردی تیمی و اتکا به رهبر تعیین‌شده الزامی است.",
          actionPlan: "یک چک‌لیست مدیریت بحران برای مواقع بروز خطا در سرورهای ابری شرکت تدوین کنیم.",
        }
      }
    ],
    analyses: {},
  },
  {
    id: "comzee-sample-event-1",
    title: "کارگاه مقدماتی پویایی تیمی و طوفان فکری",
    date: "1404-06-15",
    clientName: "شرکت فناوری ابری پیشتاز",
    facilitatorName: "احمدی‌نیا (تسهیل‌گر ارشد کامزی)",
    goals: [
      "افزایش اعتماد و امنیت روانی میان اعضای جدید",
      "تقویت کانال‌های ارتباطی و تسهیم بدون مرز اطلاعات",
    ],
    status: "completed",
    teams: [
      {
        id: "team-gamma-1",
        name: "نوآوران جوان",
        membersCount: 7,
        preScores: {
          communication: 3,
          trust: 4,
          coordination: 3,
          problemSolving: 4,
          resilience: 3,
        },
        preNotes: "تیم جدید دپارتمان فنی با هم غریبه هستند و نرخ سکوت و تعارف بالاست.",
        postScores: {
          communication: 6,
          trust: 6,
          coordination: 5,
          problemSolving: 7,
          resilience: 5,
        },
        postNotes: "بازی یخ‌شکن اولیه کمک شایانی به شکستن مرزها و تعارفات معمول پرسنل جدید کرد.",
        reflection: {
          whatWentWell: "تعارفات اولیه برطرف شد و اعضا راحت‌تر ایده دادند.",
          challenges: "دچار سندرم جزیره‌ای بودند و تقسیم کار ضعیف انجام شد.",
          learnings: "برای کارآمدی باید مستقیماً با همکاران صحبت کرد و فرضیه‌سازی نکرد.",
          actionPlan: "برگزاری روزهای قهوه تیمی دوهفتگی جهت آشنایی بیشتر با بخش‌های دیگر.",
        }
      }
    ],
    analyses: {},
  },
  {
    id: "comzee-pharma-event-1",
    title: "کارگاه یکپارچگی دپارتمان‌ها و امنیت روانی",
    date: "1404-10-22",
    clientName: "هلدینگ دارویی سلامت",
    facilitatorName: "احمدی‌نیا (تسهیل‌گر ارشد کامزی)",
    goals: [
      "افزایش اعتماد و امنیت روانی میان اعضای جدید",
      "تقویت کانال‌های ارتباطی و تسهیم بدون مرز اطلاعات",
    ],
    status: "completed",
    teams: [
      {
        id: "team-pharma-1",
        name: "احیاگران",
        membersCount: 12,
        preScores: {
          communication: 3,
          trust: 3,
          coordination: 4,
          problemSolving: 4,
          resilience: 3,
        },
        preNotes: "تفاوت شدید فرهنگی بین دپارتمان مارکتینگ و فروش که باعث عدم اعتماد اولیه شد.",
        postScores: {
          communication: 7,
          trust: 6,
          coordination: 6,
          problemSolving: 6,
          resilience: 6,
        },
        postNotes: "تمرین مشترک دیبریف باعث کاهش سوءتفاهم‌ها و درک متقابل دغدغه‌های فروش و مارکتینگ شد.",
        reflection: {
          whatWentWell: "طراحی راه‌حل مشترک برای افزایش فروش فصل سرما.",
          challenges: "مقاومت اولیه اعضا برای صحبت جدی در مورد تنش‌های گذشته.",
          learnings: "دپارتمان‌ها مقابل هم نیستند، بلکه زنجیره ارزش مکمل یکدیگرند.",
          actionPlan: "برگزاری جلسه هم‌راستایی ماهانه بین لیدرهای مارکتینگ و فروش.",
        }
      }
    ],
    analyses: {},
  }
];

export default function App() {
  const [events, setEvents] = useState<Event[]>(() => {
    const saved = localStorage.getItem("comzee_events");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_EVENTS;
      }
    }
    return INITIAL_EVENTS;
  });
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [selectedTeamIdForAnalysis, setSelectedTeamIdForAnalysis] = useState<string | null>(null);
  const [selectedTeamIdForObservation, setSelectedTeamIdForObservation] = useState<string | null>(null);

  // Active event helper
  const activeEvent = events.find((e) => e.id === selectedEventId) || null;

  // Save to server and local storage on modification
  const saveEvents = async (updatedEvents: Event[]) => {
    setEvents(updatedEvents);
    localStorage.setItem("comzee_events", JSON.stringify(updatedEvents));
    try {
      await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedEvents),
      });
    } catch (err) {
      console.error("Failed to sync updated events to cloud server:", err);
    }
  };

  // Reset team selections when switching events to prevent state desync
  useEffect(() => {
    setSelectedTeamIdForObservation(null);
    setSelectedTeamIdForAnalysis(null);
  }, [selectedEventId]);

  // Hook for AI debriefing and question generation
  const {
    isAnalyzing,
    analysisProgressMsg,
    errorBanner,
    setErrorBanner,
    isGeneratingQuestions,
    handleRunAllTeamsAnalysis,
    handleRunAIAnalysis,
    handleGenerateAIQuestions,
  } = useDebriefAI({
    events,
    activeEvent,
    saveEvents,
    setSelectedTeamIdForAnalysis,
  });

  // Hook for Focus Mode stopwatch timer
  const {
    focusMode,
    setFocusMode,
    timerSeconds,
    setTimerSeconds,
    timerIsRunning,
    setTimerIsRunning,
    timerType,
    setTimerType,
  } = useComzeeTimer();

  // Google Drive App Version Saving States
  const [appDriveAccessToken, setAppDriveAccessToken] = useState<string | null>(null);
  const [isSavingAppToDrive, setIsSavingAppToDrive] = useState(false);
  const [appDriveLink, setAppDriveLink] = useState<string | null>(null);
  const [appDriveError, setAppDriveError] = useState<string | null>(null);
  const [appDriveSuccess, setAppDriveSuccess] = useState(false);
  const [appDriveUserEmail, setAppDriveUserEmail] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setAppDriveAccessToken(token);
        setAppDriveUserEmail(user.email);
      },
      () => {
        setAppDriveAccessToken(null);
        setAppDriveUserEmail(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleSaveAppToDrive = async () => {
    setAppDriveError(null);
    setAppDriveSuccess(false);
    setIsSavingAppToDrive(true);

    try {
      let token = appDriveAccessToken;
      if (!token) {
        // Trigger sign in
        const result = await googleSignIn();
        if (result) {
          token = result.accessToken;
          setAppDriveAccessToken(result.accessToken);
          setAppDriveUserEmail(result.user.email);
        } else {
          throw new Error("تأیید هویت با حساب گوگل لغو شد یا با خطا مواجه گردید.");
        }
      }

      if (!token) {
        throw new Error("توکن معتبر برای دسترسی به گوگل درایو یافت نشد.");
      }

      // 1. Create a folder named "ورژن یک دستیار تیم سازی کامزی"
      const folderId = await createFolder(token, "ورژن یک دستیار تیم سازی کامزی");
      
      // 2. Prepare the content to save: All events and workspace state
      const backupData = {
        version: "1.0",
        appName: "دستیار تیم سازی کامزی",
        backupDate: new Date().toISOString(),
        events: events,
        localSettings: {
          webhookUrl: localStorage.getItem("comzee_webhook_url") || "",
          dashboardTheme: localStorage.getItem("comzee_dashboard_theme") || "dark",
        }
      };

      const backupContent = JSON.stringify(backupData, null, 2);
      const backupFilename = `comzee-assistant-v1-backup-${new Date().toISOString().slice(0, 10)}.json`;

      // 3. Upload the backup file to that folder
      const uploadResult = await uploadFileToFolder(
        token,
        folderId,
        backupFilename,
        backupContent,
        "application/json"
      );

      setAppDriveLink(uploadResult.webViewLink);
      setAppDriveSuccess(true);
    } catch (err: any) {
      console.error("Error backing up app to Google Drive:", err);
      setAppDriveError(err.message || "خطایی در ذخیره اطلاعات در گوگل درایو رخ داد.");
    } finally {
      setIsSavingAppToDrive(false);
    }
  };

  const [activeTab, setActiveTab] = useState<"setup" | "teams" | "analysis">("setup");
  
  // Dashboard theme settings (dark vs high-contrast light mode)
  const [dashboardTheme, setDashboardTheme] = useState<"dark" | "light">(() => {
    return (localStorage.getItem("comzee_dashboard_theme") as "dark" | "light") || "dark";
  });

  const toggleDashboardTheme = () => {
    const nextTheme = dashboardTheme === "dark" ? "light" : "dark";
    setDashboardTheme(nextTheme);
    localStorage.setItem("comzee_dashboard_theme", nextTheme);
  };
  const [viewMode, setViewMode] = useState<"workshops" | "growth" | "assistant">("workshops");
  
  // Custom tag inputs state (teamId -> text input)
  const [customTagInputs, setCustomTagInputs] = useState<Record<string, string>>({});

  // Dedicated query routing states
  const [urlMode, setUrlMode] = useState<string | null>(null);
  const [urlEventId, setUrlEventId] = useState<string | null>(null);
  const [urlTeamId, setUrlTeamId] = useState<string | null>(null);

  // Parse URL queries on mount
  useEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const mode = queryParams.get("mode");
    const eventId = queryParams.get("eventId");
    const teamId = queryParams.get("teamId");
    
    if (mode) {
      setUrlMode(mode);
    } else if (queryParams.get("projector") === "true") {
      setUrlMode("projector");
    }
    if (eventId) setUrlEventId(eventId);
    if (teamId) setUrlTeamId(teamId);
  }, []);

  // B2B Client Report Modal State
  const [isPreviewingB2BReport, setIsPreviewingB2BReport] = useState(false);
  const [copiedQuestionId, setCopiedQuestionId] = useState<string | null>(null);

  // Form creation states
  const [showCreateEventModal, setShowCreateEventModal] = useState(false);
  const [createWizardStep, setCreateWizardStep] = useState<1 | 2 | 3>(1);
  const [newEventTitle, setNewEventTitle] = useState("");
  const [newEventClient, setNewEventClient] = useState("");
  const [newEventFacilitator, setNewEventFacilitator] = useState("تسهیل‌گر ارشد کامزی");
  const [newEventGoals, setNewEventGoals] = useState<string[]>([]);
  const [autoTeamsCount, setAutoTeamsCount] = useState<number>(3);
  
  // Custom modular goals list
  const [customGoals, setCustomGoals] = useState<string[]>(DEFAULT_GOALS);
  const [newModularGoalInput, setNewModularGoalInput] = useState("");

  // --- Universal Back Handler ---
  const handleBackNavigation = useCallback(() => {
    if (focusMode) {
      setFocusMode(false);
    } else if (activeTab === "analysis") {
      setActiveTab("teams");
    } else if (activeTab === "teams") {
      setActiveTab("setup");
    } else if (viewMode !== "workshops") {
      setViewMode("workshops");
    }
  }, [focusMode, activeTab, viewMode]);

  // Universal Back Button Component
  const renderBackButton = () => {
    const canGoBack = focusMode || (viewMode === "workshops" && (activeTab === "teams" || activeTab === "analysis")) || viewMode !== "workshops";
    if (!canGoBack) return null;

    return (
      <button 
        onClick={handleBackNavigation}
        className="fixed top-4 left-4 z-50 p-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-full shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center justify-center cursor-pointer border border-amber-600/20"
        title="بازگشت"
      >
        <ArrowRight className="w-5 h-5" /> 
      </button>
    );
  };

  // Webhook settings states
  const [webhookUrl, setWebhookUrl] = useState(() => {
    return localStorage.getItem("comzee_webhook_url") || "https://n8n.comzee.ir/webhook/debrief-sync-snapp-digikala";
  });
  const [isSendingWebhook, setIsSendingWebhook] = useState(false);
  const [webhookStatus, setWebhookStatus] = useState<"idle" | "success" | "error">("idle");
  
  // Slide presenter active state
  const [presentingAnalysis, setPresentingAnalysis] = useState<DebriefAnalysis | null>(null);

  // Load from server and local storage on mount (lazy-initialization already fallback-loaded the state synchronously)
  useEffect(() => {
    // Load custom goals
    const savedGoals = localStorage.getItem("comzee_custom_goals");
    if (savedGoals) {
      try {
        setCustomGoals(JSON.parse(savedGoals));
      } catch (e) {
        setCustomGoals(DEFAULT_GOALS);
      }
    }

    const loadData = async () => {
      try {
        const res = await fetch("/api/events");
        if (res.ok) {
          const serverEvents = await res.json();
          if (serverEvents && serverEvents.length > 0) {
            setEvents(serverEvents);
            localStorage.setItem("comzee_events", JSON.stringify(serverEvents));
          }
        }
      } catch (err) {
        console.warn("Could not sync with cloud DB server on startup, falling back to local storage.", err);
      }
    };

    loadData();
  }, []);

  // Select first event if none selected
  useEffect(() => {
    if (events.length > 0 && !selectedEventId) {
      setSelectedEventId(events[0].id);
    }
  }, [events, selectedEventId]);

  // Handle Create Event
  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle || !newEventClient) return;

    // Auto-generate luxury teams based on the count chosen in Wizard Step 3
    const luxuryTeamNames = ["تیم سرخ (آرس)", "تیم آبی (نپتون)", "تیم زرین (آپولو)", "تیم زمرد (آرتمیس)", "تیم بنفش (هلیوس)"];
    const generatedTeams: Team[] = [];
    
    for (let i = 0; i < autoTeamsCount; i++) {
      const name = luxuryTeamNames[i % luxuryTeamNames.length] || `تیم هوشمند ${i + 1}`;
      generatedTeams.push({
        id: "team_" + Date.now() + "_" + i,
        name: name,
        membersCount: 6, // default reasonable count
        preScores: { communication: 5, trust: 5, coordination: 5, problemSolving: 5, resilience: 5 },
        postScores: { communication: 7, trust: 6, coordination: 7, problemSolving: 7, resilience: 6 },
        preNotes: "بازی با چالش و ابهام زیادی شروع شد. برنامه‌ریزی زودهنگام کمی با ناهماهنگی روبرو بود.",
        postNotes: "اعضای تیم در طول ران دوم بازی انعطاف بیشتری به خرج دادند و کانال‌های ارتباطی فعال‌تر شد.",
        reflection: {
          whatWentWell: "گوش دادن فعال در تصمیم‌گیری‌های حساس ران دوم بازی افزایش یافت.",
          challenges: "مدیریت زمان در مواجهه با قوانین جدید شبیه‌ساز چالش‌برانگیز بود.",
          learnings: "ایجاد امنیت روانی برای ابراز ایده‌های ریسکی منجر به راه‌حل‌های سریع‌تر می‌گردد.",
          actionPlan: "تعریف جلسات کوتاه ایستاده (Standup) روزانه در محیط اداری جهت هم‌راستایی نقش‌ها."
        }
      });
    }

    const newEvent: Event = {
      id: "event_" + Date.now(),
      title: newEventTitle,
      date: new Date().toLocaleDateString("fa-IR") || new Date().toISOString().split("T")[0],
      clientName: newEventClient,
      facilitatorName: newEventFacilitator,
      goals: newEventGoals.length > 0 ? newEventGoals : [customGoals[0]],
      status: "setup",
      teams: generatedTeams,
      analyses: {},
      aiTone: "analytical",
    };

    const updated = [newEvent, ...events];
    saveEvents(updated);
    setSelectedEventId(newEvent.id);
    setActiveTab("teams"); // start directly in Teams view as they have pre-populated data!
    
    // Reset form
    setNewEventTitle("");
    setNewEventClient("");
    setNewEventGoals([]);
    setCreateWizardStep(1); // reset wizard step
    setShowCreateEventModal(false);
  };

  // Delete Event
  const handleDeleteEvent = (id: string) => {
    if (window.confirm("آیا از حذف این رویداد کارگاهی اطمینان دارید؟ تمامی اطلاعات تیم‌ها پاک خواهد شد.")) {
      const updated = events.filter((e) => e.id !== id);
      saveEvents(updated);
      if (selectedEventId === id) {
        setSelectedEventId(updated.length > 0 ? updated[0].id : null);
      }
    }
  };

  // Goal Toggle for New Event
  const toggleGoalSelection = (goal: string) => {
    if (newEventGoals.includes(goal)) {
      setNewEventGoals(newEventGoals.filter((g) => g !== goal));
    } else {
      setNewEventGoals([...newEventGoals, goal]);
    }
  };

  // Dynamic modular goals helpers
  const handleAddModularGoal = (goalText: string) => {
    const trimmed = goalText.trim();
    if (!trimmed) return;
    if (customGoals.includes(trimmed)) return;
    const updated = [...customGoals, trimmed];
    setCustomGoals(updated);
    localStorage.setItem("comzee_custom_goals", JSON.stringify(updated));
    setNewModularGoalInput("");
  };

  const handleRemoveModularGoal = (goalText: string) => {
    const updated = customGoals.filter(g => g !== goalText);
    setCustomGoals(updated);
    localStorage.setItem("comzee_custom_goals", JSON.stringify(updated));
    if (newEventGoals.includes(goalText)) {
      setNewEventGoals(newEventGoals.filter(g => g !== goalText));
    }
  };

  // Webhook execution helper
  const handleTriggerWebhook = async () => {
    if (!activeEvent || !webhookUrl) return;
    setIsSendingWebhook(true);
    setWebhookStatus("idle");
    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source: "Comzee Debrief Facilitator Builder",
          timestamp: new Date().toISOString(),
          eventId: activeEvent.id,
          title: activeEvent.title,
          clientName: activeEvent.clientName,
          facilitatorName: activeEvent.facilitatorName,
          goals: activeEvent.goals,
          teams: activeEvent.teams,
          analyses: activeEvent.analyses
        })
      });
      if (response.ok) {
        setWebhookStatus("success");
      } else {
        setWebhookStatus("error");
      }
    } catch (e) {
      setWebhookStatus("error");
    } finally {
      setIsSendingWebhook(false);
      setTimeout(() => setWebhookStatus("idle"), 4000);
    }
  };

  // Update Event Attributes
  const updateEventField = (field: keyof Event, value: any) => {
    if (!activeEvent) return;
    const updated = events.map((e) => {
      if (e.id === activeEvent.id) {
        return { ...e, [field]: value };
      }
      return e;
    });
    saveEvents(updated);
  };

  // Toggle standard games selection
  const handleToggleGame = (gameId: string) => {
    if (!activeEvent) return;
    const selected = activeEvent.selectedGames || [];
    const updated = selected.includes(gameId)
      ? selected.filter((id) => id !== gameId)
      : [...selected, gameId];
    updateEventField("selectedGames", updated);
  };

  // Add custom game to event
  const handleAddCustomGame = (gameName: string) => {
    if (!activeEvent) return;
    const custom = activeEvent.customGames || [];
    if (!custom.includes(gameName)) {
      updateEventField("customGames", [...custom, gameName]);
    }
  };

  // Remove custom game from event
  const handleRemoveCustomGame = (gameName: string) => {
    if (!activeEvent) return;
    const custom = activeEvent.customGames || [];
    updateEventField("customGames", custom.filter((name) => name !== gameName));
  };

  // Add a new Team to the Active Event
  const handleAddTeam = () => {
    if (!activeEvent) return;
    const newTeam: Team = {
      id: "team_" + Date.now(),
      name: `تیم جدید ${activeEvent.teams.length + 1}`,
      membersCount: 6,
      preScores: { communication: 5, trust: 5, coordination: 5, problemSolving: 5, resilience: 5 },
      preNotes: "",
      postScores: { communication: 5, trust: 5, coordination: 5, problemSolving: 5, resilience: 5 },
      postNotes: "",
      reflection: { whatWentWell: "", challenges: "", learnings: "", actionPlan: "" },
    };

    const updatedTeams = [...activeEvent.teams, newTeam];
    updateEventField("teams", updatedTeams);
  };

  // Update a Team's properties
  const handleUpdateTeam = (teamId: string, field: keyof Team, value: any) => {
    if (!activeEvent) return;
    const updatedTeams = activeEvent.teams.map((t) => {
      if (t.id === teamId) {
        return { ...t, [field]: value };
      }
      return t;
    });
    updateEventField("teams", updatedTeams);
  };

  // Update specific Team Score (pre or post)
  const handleUpdateTeamScore = (teamId: string, type: "pre" | "post", dimension: keyof TeamScores, value: number) => {
    if (!activeEvent) return;
    const updatedTeams = activeEvent.teams.map((t) => {
      if (t.id === teamId) {
        const scoreKey = type === "pre" ? "preScores" : "postScores";
        return {
          ...t,
          [scoreKey]: {
            ...t[scoreKey],
            [dimension]: value,
          },
        };
      }
      return t;
    });
    updateEventField("teams", updatedTeams);
  };

  // Update Team Reflection specific fields
  const handleUpdateReflection = (teamId: string, field: keyof Team["reflection"], value: string) => {
    if (!activeEvent) return;
    const updatedTeams = activeEvent.teams.map((t) => {
      if (t.id === teamId) {
        return {
          ...t,
          reflection: {
            ...t.reflection,
            [field]: value,
          },
        };
      }
      return t;
    });
    updateEventField("teams", updatedTeams);
  };

  // Toggle quick-behavior tags
  const handleToggleBehaviorTag = (teamId: string, tag: string) => {
    if (!activeEvent) return;
    const updatedTeams = activeEvent.teams.map((t) => {
      if (t.id === teamId) {
        const currentTags = t.behaviorTags || [];
        const updatedTags = currentTags.includes(tag)
          ? currentTags.filter((val) => val !== tag)
          : [...currentTags, tag];
        return {
          ...t,
          behaviorTags: updatedTags,
        };
      }
      return t;
    });
    updateEventField("teams", updatedTeams);
  };

  // Add custom behavior tag
  const handleAddCustomBehaviorTag = (teamId: string, tag: string) => {
    if (!activeEvent || !tag.trim()) return;
    const trimmed = tag.trim();
    const updatedTeams = activeEvent.teams.map((t) => {
      if (t.id === teamId) {
        const currentTags = t.behaviorTags || [];
        if (currentTags.includes(trimmed)) return t;
        return {
          ...t,
          behaviorTags: [...currentTags, trimmed],
        };
      }
      return t;
    });
    updateEventField("teams", updatedTeams);
  };

  // Remove a Team
  const handleRemoveTeam = (teamId: string) => {
    if (!activeEvent) return;
    if (window.confirm("آیا از حذف این تیم اطمینان دارید؟")) {
      const updatedTeams = activeEvent.teams.filter((t) => t.id !== teamId);
      updateEventField("teams", updatedTeams);
      if (selectedTeamIdForAnalysis === teamId) {
        setSelectedTeamIdForAnalysis(null);
      }
    }
  };

  // AI Analysis and Question Generation functions are now handled by the useDebriefAI custom hook.

  // Quick export of the debrief report
  const handleExportReport = (analysis: DebriefAnalysis) => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(analysis, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `comzee-debrief-${analysis.teamName}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Launch the presentation mode
  const handleLaunchPresentation = (analysis: DebriefAnalysis, team: Team) => {
    setPresentingAnalysis(analysis);
  };

  // URL Mode rendering overrides (Projector, Live Assessment, Client B2B Report)
  if (urlMode === "projector" && urlEventId && urlTeamId) {
    return (
      <ProjectorView
        eventId={urlEventId}
        teamId={urlTeamId}
        onExit={() => {
          setUrlMode(null);
          setUrlEventId(null);
          setUrlTeamId(null);
          window.location.search = "";
        }}
      />
    );
  }

  if (urlMode === "live-score" && urlEventId && urlTeamId) {
    const matchedEvt = events.find((e) => e.id === urlEventId);
    const matchedTeam = matchedEvt?.teams.find((t) => t.id === urlTeamId);
    return (
      <LiveScoreSubmit
        eventId={urlEventId}
        teamId={urlTeamId}
        eventName={matchedEvt?.title || "کارگاه توسعه پویایی تیمی کامزی"}
        teamName={matchedTeam?.name || "تیم ارزیابی"}
        onExit={() => {
          setUrlMode(null);
          setUrlEventId(null);
          setUrlTeamId(null);
          window.location.search = "";
        }}
      />
    );
  }

  if (urlMode === "client-report" && urlEventId && urlTeamId) {
    const matchedEvt = events.find((e) => e.id === urlEventId);
    if (matchedEvt) {
      return (
        <B2BClientReport
          isOpen={true}
          onClose={() => {
            setUrlMode(null);
            setUrlEventId(null);
            setUrlTeamId(null);
            window.location.search = "";
          }}
          event={matchedEvt}
          selectedTeamId={urlTeamId}
        />
      );
    }
  }

  // Keyboard shortcut for Esc/Back
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") handleBackNavigation();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleBackNavigation]);

  // Sync selected team for observation on activeEvent load
  useEffect(() => {
    if (activeEvent && activeEvent.teams.length > 0 && !selectedTeamIdForObservation) {
      setSelectedTeamIdForObservation(activeEvent.teams[0].id);
    }
  }, [activeEvent, selectedTeamIdForObservation]);

  // Immersive Focus Cockpit render block
  if (focusMode && activeEvent) {
    const activeObservationTeam = activeEvent.teams.find((t) => t.id === selectedTeamIdForObservation) || activeEvent.teams[0] || null;
    
    const formatTimer = (secs: number) => {
      const mins = Math.floor(secs / 60);
      const s = secs % 60;
      return `${mins.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    };

    return (
      <div className={`min-h-screen text-slate-100 flex flex-col font-sans dir-rtl select-none ${
        dashboardTheme === "light" 
          ? "theme-light bg-slate-50 text-slate-900" 
          : "bg-gradient-to-br from-[#090d16] via-[#0f172a] to-[#080c14]"
      }`}>
        {renderBackButton()}
        {/* Immersive Cockpit Header */}
        <header className="bg-slate-950/60 backdrop-blur-md border-b border-slate-900 px-6 py-4 sticky top-0 z-40 shadow-xl">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="relative flex items-center justify-center">
                <span className="absolute inline-flex h-4 w-4 rounded-full bg-rose-500 opacity-75 animate-ping" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="font-black text-lg text-white">کابین زنده ارزیابی و تمرکز کارگاهی</h1>
                  <span className="text-xs bg-amber-500/15 text-amber-400 font-bold px-2.5 py-0.5 rounded-full border border-amber-500/20">COMZEE LIVE</span>
                </div>
                <p className="text-sm text-slate-400 mt-1">کارگاه: {activeEvent.title} • سازمان: {activeEvent.clientName}</p>
              </div>
            </div>

            {/* Team selection tabs inside header */}
            {activeEvent.teams.length > 0 && (
              <div className="flex bg-slate-900 border border-slate-800 p-1 rounded-xl gap-1">
                {activeEvent.teams.map((t) => {
                  const isSelected = activeObservationTeam && t.id === activeObservationTeam.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setSelectedTeamIdForObservation(t.id)}
                      className={`px-4 py-2 rounded-lg text-sm font-bold transition-all cursor-pointer ${
                        isSelected
                          ? "bg-amber-500 text-slate-950 shadow-md font-extrabold"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      {t.name}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Exit button */}
            <button
              onClick={() => setFocusMode(false)}
              className="px-5 py-2.5 bg-gradient-to-l from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-sm rounded-xl flex items-center gap-1.5 shadow-lg shadow-amber-500/5 transition-all cursor-pointer"
            >
              <Eye className="w-4.5 h-4.5" />
              خروج از حالت تمرکز (Esc)
            </button>
          </div>
        </header>

        {activeEvent.teams.length === 0 || !activeObservationTeam ? (
          <div className="flex-1 max-w-7xl w-full mx-auto p-6 flex flex-col items-center justify-center">
            <div className="bg-slate-900/40 backdrop-blur-md border border-slate-800 rounded-3xl p-12 text-center max-w-md space-y-4">
              <Users className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="font-extrabold text-lg text-white">تیمی برای تمرکز یافت نشد</h3>
              <p className="text-sm text-slate-400 leading-relaxed">ابتدا باید در حالت معمولی داشبورد حداقل یک تیم اضافه کنید تا قابلیت کابین ارزیابی زنده فعال شود.</p>
              <button
                onClick={() => setFocusMode(false)}
                className="px-4 py-2 bg-slate-800 border border-slate-700 text-slate-200 text-sm font-bold rounded-xl"
              >
                بازگشت به داشبورد و ایجاد تیم
              </button>
            </div>
          </div>
        ) : (
          <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* COLUMN 1: Stopwatch and Scores (col-span-5) */}
            <section className="lg:col-span-5 flex flex-col space-y-6">
              
              {/* Elegant Stopwatch card */}
              <div className="bg-slate-900/40 backdrop-blur-md border border-slate-800/80 rounded-3xl p-6 flex flex-col items-center justify-center space-y-5 shadow-xl shadow-slate-950/20">
                <div className="flex items-center gap-1.5 text-sm font-bold text-slate-400">
                  <Timer className="w-4.5 h-4.5 text-amber-500" />
                  <span>تایمر شبیه‌ساز کامزی حین فعالیت زنده</span>
                </div>

                <div className="flex flex-col items-center">
                  <span className={`font-mono text-7xl font-black tracking-widest transition-colors ${
                    timerSeconds < 60 && timerIsRunning ? "text-rose-500 animate-pulse drop-shadow-[0_0_20px_rgba(239,68,68,0.4)]" : "text-amber-400 drop-shadow-[0_0_15px_rgba(245,158,11,0.25)]"
                  }`}>
                    {formatTimer(timerSeconds)}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setTimerSeconds(Math.max(0, timerSeconds - 60))}
                    className="p-2.5 bg-slate-950/60 border border-slate-850 hover:bg-slate-850 text-slate-300 rounded-xl transition-all cursor-pointer text-sm font-bold"
                    title="کاهش یک دقیقه"
                  >
                    -۱:۰۰
                  </button>
                  <button
                    onClick={() => setTimerIsRunning(!timerIsRunning)}
                    className={`px-6 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 transition-all cursor-pointer shadow ${
                      timerIsRunning
                        ? "bg-rose-500/20 text-rose-400 border border-rose-500/30 hover:bg-rose-500/30"
                        : "bg-amber-500 text-slate-950 hover:bg-amber-400"
                    }`}
                  >
                    {timerIsRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-slate-950" />}
                    {timerIsRunning ? "توقف تایمر" : "شروع ران بازی"}
                  </button>
                  <button
                    onClick={() => {
                      setTimerIsRunning(false);
                      setTimerSeconds(600);
                    }}
                    className="p-2.5 bg-slate-950/60 border border-slate-850 hover:bg-slate-850 text-slate-300 rounded-xl transition-all cursor-pointer"
                    title="بازنشانی به ۱۰ دقیقه"
                  >
                    <RotateCcw className="w-4.5 h-4.5" />
                  </button>
                  <button
                    onClick={() => setTimerSeconds(timerSeconds + 60)}
                    className="p-2.5 bg-slate-950/60 border border-slate-850 hover:bg-slate-850 text-slate-300 rounded-xl transition-all cursor-pointer text-sm font-bold"
                    title="افزایش یک دقیقه"
                  >
                    +۱:۰۰
                  </button>
                </div>

                <div className="flex bg-slate-950/80 p-0.5 rounded-lg border border-slate-850 text-xs">
                  <button
                    onClick={() => setTimerType("countdown")}
                    className={`px-3 py-1 rounded-md font-bold transition-all ${timerType === "countdown" ? "bg-slate-850 text-amber-400" : "text-slate-500"}`}
                  >
                    تایمر معکوس
                  </button>
                  <button
                    onClick={() => setTimerType("countup")}
                    className={`px-3 py-1 rounded-md font-bold transition-all ${timerType === "countup" ? "bg-slate-850 text-amber-400" : "text-slate-500"}`}
                  >
                    زمان‌سنج صعودی
                  </button>
                </div>
              </div>

              {/* Live Dynamics Scores card */}
              <div className="bg-slate-900/40 backdrop-blur-md border border-slate-800/80 rounded-3xl p-6 flex-1 flex flex-col justify-between space-y-4 shadow-xl shadow-slate-950/20">
                <div className="space-y-1 pb-3 border-b border-slate-950/40">
                  <h4 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    تنظیم زنده نمرات پویایی تیمی
                  </h4>
                  <p className="text-xs text-slate-400">نمرات را همزمان با رفتارهای مشاهده‌شده در هر بخش تغییر دهید.</p>
                </div>

                <div className="space-y-4 flex-1 flex flex-col justify-center">
                  {(Object.keys(SCORE_LABELS) as Array<keyof TeamScores>).map((dim) => (
                    <div key={dim} className="space-y-1">
                      <div className="flex items-center justify-between text-sm font-semibold">
                        <span className="text-slate-300">{SCORE_LABELS[dim].fa}</span>
                        <span className="font-mono text-amber-400 font-bold text-sm">{activeObservationTeam.postScores[dim]} / ۱۰</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="10"
                        value={activeObservationTeam.postScores[dim]}
                        onChange={(e) => handleUpdateTeamScore(activeObservationTeam.id, "post", dim, parseInt(e.target.value))}
                        className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
                      />
                    </div>
                  ))}
                </div>
                
                <div className="bg-slate-950/60 p-3.5 rounded-2xl border border-slate-900/50 text-xs text-slate-400 leading-relaxed text-right mt-1">
                  💡 <strong>نکته تسهیل‌گری کامزی:</strong> در حین بازی اگر دیدید اعضا ایده مفیدی را بایکوت می‌کنند، سریعاً نمره <strong>حل مسئله</strong> یا <strong>اعتماد</strong> را پایین بکشید و تگ رفتاری متناظر را تیک بزنید.
                </div>
              </div>
            </section>

            {/* COLUMN 2: Modular Observation Panel (col-span-7) */}
            <section className="lg:col-span-7 flex flex-col space-y-6">
              <div className="bg-slate-900/40 backdrop-blur-md border border-slate-800/80 rounded-3xl p-6 flex flex-col h-full justify-between space-y-5 shadow-xl shadow-slate-950/20">
                
                {/* Header info */}
                <div className="flex items-center justify-between flex-wrap gap-2 pb-3 border-b border-slate-950/40">
                  <div className="space-y-0.5 text-right">
                    <h4 className="text-sm font-black text-slate-200 flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-rose-400 animate-pulse" />
                      پنل ماژولار ثبت رفتارهای مشاهده‌شده تیمی ({activeObservationTeam.name})
                    </h4>
                    <p className="text-xs text-slate-400">تگ‌های رفتاری مشاهده شده حین فعالیت بازی را به عنوان داده‌های عینی شبیه‌ساز ثبت نمایید.</p>
                  </div>
                  <span className="text-xs bg-rose-500/10 text-rose-400 px-3 py-1 rounded-full font-bold font-mono">
                    {(activeObservationTeam.behaviorTags || []).length} رفتار ثبت‌شده
                  </span>
                </div>

                {/* Grid of tags */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 flex-1 items-center">
                  {QUICK_BEHAVIOR_TAGS.map((tag) => {
                    const isSelected = (activeObservationTeam.behaviorTags || []).includes(tag.label);
                    return (
                      <button
                        key={tag.label}
                        type="button"
                        onClick={() => handleToggleBehaviorTag(activeObservationTeam.id, tag.label)}
                        className={`p-2.5 rounded-xl text-xs font-bold text-right transition-all border flex flex-col justify-between h-[68px] cursor-pointer select-none ${
                          isSelected
                            ? tag.type === "positive"
                              ? "bg-emerald-500/10 border-emerald-500/40 text-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.1)] scale-[0.98]"
                              : "bg-rose-500/10 border-rose-500/40 text-rose-400 shadow-[0_0_12px_rgba(244,63,94,0.1)] scale-[0.98]"
                            : "bg-slate-950/40 border-slate-900 text-slate-400 hover:border-slate-850 hover:text-slate-300"
                        }`}
                      >
                        <span className="text-[11px] text-slate-500 block">
                          {tag.type === "positive" ? "پویایی مثبت" : "چالش گروهی"}
                        </span>
                        <span className="font-semibold block truncate mt-1">{tag.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Custom quick behavior tag adder */}
                <div className="pt-3 border-t border-slate-950/40 flex items-center gap-2">
                  <input
                    type="text"
                    value={customTagInputs[activeObservationTeam.id] || ""}
                    onChange={(e) => setCustomTagInputs((prev) => ({ ...prev, [activeObservationTeam.id]: e.target.value }))}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        if (customTagInputs[activeObservationTeam.id]?.trim()) {
                          handleAddCustomBehaviorTag(activeObservationTeam.id, customTagInputs[activeObservationTeam.id]);
                          setCustomTagInputs((prev) => ({ ...prev, [activeObservationTeam.id]: "" }));
                        }
                      }
                    }}
                    className="flex-1 bg-slate-950/60 border border-slate-900 rounded-xl px-3.5 py-2.5 text-slate-300 text-sm focus:outline-none focus:border-amber-500/60 placeholder:text-slate-650 text-right"
                    placeholder="ثبت رفتار سفارشی زنده دیگر... (سپس Enter بزنید)"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (customTagInputs[activeObservationTeam.id]?.trim()) {
                        handleAddCustomBehaviorTag(activeObservationTeam.id, customTagInputs[activeObservationTeam.id]);
                        setCustomTagInputs((prev) => ({ ...prev, [activeObservationTeam.id]: "" }));
                      }
                    }}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-750 border border-slate-750 text-slate-300 font-extrabold text-sm rounded-xl transition-all cursor-pointer"
                  >
                    ثبت رفتار
                  </button>
                </div>

                {/* Text Qualitative Notebook */}
                <div className="space-y-1.5 text-right pt-3 border-t border-slate-950/40">
                  <label className="text-slate-300 text-sm font-extrabold flex items-center gap-1.5 justify-end">
                    <Edit3 className="w-3.5 h-3.5 text-amber-500" />
                    دفترچه ثبت کیفی یادداشت‌های کارگاهی (Facilitator Observations)
                  </label>
                  <textarea
                    value={activeObservationTeam.postNotes}
                    onChange={(e) => handleUpdateTeam(activeObservationTeam.id, "postNotes", e.target.value)}
                    className="w-full bg-slate-950/80 border border-slate-900 rounded-2xl p-4 text-slate-200 text-sm focus:outline-none focus:border-amber-500/50 transition-all h-[120px] resize-none leading-relaxed font-sans placeholder:text-slate-600 text-right"
                    placeholder="مشاهدات رفتاری مهم، نقل‌قول‌های عینی اعضا، تنش‌ها، مدل‌های حل تعارض و هر آنچه که می‌تواند به هوش مصنوعی در ساخت یک دیبریف عمیق کمک کند را همین‌جا یادداشت نمایید..."
                  />
                </div>
              </div>
            </section>
          </main>
        )}
      </div>
    );
  }

  return (
    <div className={`min-h-screen flex flex-col font-sans dir-rtl selection:bg-amber-500 selection:text-slate-950 ${
      dashboardTheme === "light"
        ? "theme-light bg-slate-50 text-slate-900"
        : "bg-slate-950 text-slate-100"
    }`}>
      {renderBackButton()}
      
      {/* If Presenter is Active, overlay the full screen */}
      {presentingAnalysis && activeEvent && (
        <DebriefPresentation
          slides={presentingAnalysis.slides}
          preScores={activeEvent.teams.find((t) => t.id === presentingAnalysis.teamId)!.preScores}
          postScores={activeEvent.teams.find((t) => t.id === presentingAnalysis.teamId)!.postScores}
          teamName={presentingAnalysis.teamName}
          clientName={activeEvent.clientName}
          onClose={() => setPresentingAnalysis(null)}
          team={activeEvent.teams.find((t) => t.id === presentingAnalysis.teamId)}
          onUpdateActionPlan={(plan) => handleUpdateTeam(presentingAnalysis.teamId, "actionPlan", plan)}
        />
      )}

      {/* Ambient Floating Focus Mode Notification */}
      {focusMode && (
        <div className="bg-gradient-to-l from-amber-600 to-amber-500 text-slate-950 text-center py-2 px-4 text-xs font-black flex items-center justify-between shadow-lg sticky top-0 z-40">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 animate-pulse" />
            <span>حالت تمرکز کارگاهی فعال است (تمام ابزارهای جانبی و نوارها پنهان شده‌اند)</span>
          </div>
          <button 
            onClick={() => setFocusMode(false)}
            className="bg-slate-950 text-amber-400 font-extrabold px-3 py-1 rounded-lg text-[10px] hover:bg-slate-900 transition-colors"
          >
            خروج از حالت تمرکز
          </button>
        </div>
      )}

      {/* Main Navbar */}
      {!focusMode && (
        <header className="bg-slate-900 border-b border-slate-900 px-6 py-4 sticky top-0 z-30 shadow-lg">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-gradient-to-tr from-amber-600 to-amber-400 rounded-2xl shadow-md shadow-amber-500/10 text-slate-950">
                <Sparkles className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <h1 className="font-black text-xl text-white tracking-tight flex items-center gap-2">
                  تسهیل‌یار دیبریف تیم‌سازی کامزی <span className="text-[10px] bg-amber-500/15 text-amber-400 font-bold px-2 py-0.5 rounded-full border border-amber-500/20">COMZEE</span>
                </h1>
                <p className="text-xs text-slate-400 mt-0.5">پلتفرم هوشمند تحلیل عملکرد و پویایی‌های کار تیمی تجربی</p>
              </div>
            </div>

            {/* Quick Stats / Action */}
            <div className="flex items-center gap-3">
              {/* Quick Theme Toggle Button */}
              <button
                onClick={toggleDashboardTheme}
                className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                  dashboardTheme === "light"
                    ? "border-slate-300 bg-white text-amber-600 hover:bg-slate-100"
                    : "border-slate-800 bg-slate-950/60 text-amber-400 hover:bg-slate-850"
                }`}
                title={dashboardTheme === "dark" ? "تغییر به پوسته روشن با کنتراست بالا" : "تغییر به پوسته تاریک فضایی"}
              >
                {dashboardTheme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              <div className="bg-slate-950/60 border border-slate-800 rounded-xl px-4 py-1.5 text-center hidden md:block">
                <span className="text-[10px] text-slate-500 block font-medium">کارگاه‌های فعال</span>
                <span className="text-sm font-bold font-mono text-amber-400">{events.length} رویداد</span>
              </div>
              
              <button
                onClick={() => setShowCreateEventModal(true)}
                className="px-4 py-2.5 bg-gradient-to-l from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-amber-500/5 hover:shadow-amber-500/10 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                تعریف کارگاه جدید
              </button>
            </div>
          </div>
        </header>
      )}

      {/* View Mode Tabs */}
      <div className="max-w-7xl w-full mx-auto px-4 md:px-6 pt-6">
        <div className="bg-slate-900 border border-slate-900/85 p-1 rounded-2xl inline-flex font-bold text-xs gap-1 shadow-md flex-wrap">
          <button
            onClick={() => setViewMode("workshops")}
            className={`px-5 py-2.5 rounded-xl flex items-center gap-2 transition-all cursor-pointer ${
              viewMode === "workshops"
                ? "bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/15"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Gamepad2 className="w-4 h-4" />
            کارگاه‌های فعال و امتیازدهی
          </button>
          <button
            onClick={() => setViewMode("growth")}
            className={`px-5 py-2.5 rounded-xl flex items-center gap-2 transition-all cursor-pointer ${
              viewMode === "growth"
                ? "bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/15"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            داشبورد مقایسه‌ای مشتری (HR Growth)
          </button>
          <button
            onClick={() => setViewMode("assistant")}
            className={`px-5 py-2.5 rounded-xl flex items-center gap-2 transition-all cursor-pointer ${
              viewMode === "assistant"
                ? "bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/15"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Sparkles className="w-4 h-4 animate-pulse text-amber-400" />
            دستیار هوشمند دیبریف (پروژکتور)
          </button>
        </div>
      </div>

      {/* Global Breadcrumb & Back Navigation */}
      <div className="max-w-7xl w-full mx-auto px-4 md:px-6 mt-4">
        <BreadcrumbWithBack
          viewMode={viewMode}
          selectedEventId={selectedEventId}
          activeEventTitle={activeEvent ? activeEvent.title : null}
          activeTab={activeTab}
          selectedTeamName={activeEvent?.teams.find(t => t.id === selectedTeamIdForAnalysis)?.name || null}
          lightMode={dashboardTheme === "light"}
          onNavigateViewMode={(mode) => setViewMode(mode)}
          onNavigateTab={(tab) => setActiveTab(tab)}
          onClearEvent={() => {
            setSelectedEventId(null);
            setSelectedTeamIdForAnalysis(null);
          }}
          onClearTeam={() => setSelectedTeamIdForAnalysis(null)}
        />
      </div>

      {/* Main Container */}
      {viewMode === "growth" ? (
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 min-h-0">
          <ClientGrowthDashboard
            events={events}
            onSelectEvent={(eventId, tab) => {
              setSelectedEventId(eventId);
              setActiveTab(tab);
              setViewMode("workshops");
            }}
          />
        </main>
      ) : viewMode === "assistant" ? (
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 min-h-0">
          <ComzeeAssistant />
        </main>
      ) : (
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-0">
        
        {/* Left Side: Event List & Navigator */}
        {!focusMode && (
          <section className="lg:col-span-1 bg-slate-900/40 border border-slate-900 rounded-2xl p-4 flex flex-col space-y-4">
            <div className="flex items-center gap-2 text-slate-300 font-bold text-xs pb-2 border-b border-slate-900">
              <FolderOpen className="w-4 h-4 text-amber-400" />
              <h3>لیست کارگاه‌های تیم‌سازی</h3>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1 max-h-[350px] lg:max-h-[600px]">
              {events.length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-xs">
                  هیچ رویدادی تعریف نشده است.
                </div>
              ) : (
                events.map((e) => {
                  const isActive = e.id === selectedEventId;
                  return (
                    <div
                      key={e.id}
                      onClick={() => {
                        setSelectedEventId(e.id);
                        setSelectedTeamIdForAnalysis(null);
                      }}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer group text-right relative overflow-hidden ${
                        isActive
                          ? "bg-slate-900 border-amber-500/40 shadow-md"
                          : "bg-slate-950/40 border-slate-950 hover:bg-slate-900 hover:border-slate-800"
                      }`}
                    >
                      {isActive && (
                        <div className="absolute right-0 top-0 bottom-0 w-1 bg-amber-500" />
                      )}
                      <h4 className={`text-xs font-bold leading-relaxed truncate ${isActive ? "text-amber-400" : "text-slate-300 group-hover:text-white"}`}>
                        {e.title}
                      </h4>
                      <p className="text-[10px] text-slate-500 mt-1 truncate">مشتری: {e.clientName}</p>
                      
                      <div className="flex items-center justify-between mt-2.5 pt-2.5 border-t border-slate-950/60 text-[9px] text-slate-500">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-slate-600" />
                          {e.date}
                        </span>
                        <span className="bg-slate-950 px-1.5 py-0.5 rounded font-mono font-medium">
                          {e.teams.length} تیم
                        </span>
                      </div>

                      {/* Delete Event Quick button */}
                      <button
                        onClick={(evt) => {
                          evt.stopPropagation();
                          handleDeleteEvent(e.id);
                        }}
                        className="absolute left-2 top-2 p-1 text-slate-600 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="حذف کارگاه"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>

            {/* Facilitator quick access guidelines card */}
            <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-3 text-right">
              <h4 className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-amber-500" />
                راهنمای پویایی کارگاهی
              </h4>
              <p className="text-[10px] text-slate-500 leading-relaxed mt-1.5">
                در پایان شبیه‌سازی تیمی، ابتدا به اعضا اجازه دهید احساسات خود را برون‌ریزی کنند، سپس نمرات مقایسه‌ای را به عنوان داده عینی با آن‌ها به بحث بگذارید.
              </p>
            </div>
          </section>
        )}

        {/* Right Side: Event Workspace & Controls */}
        <section className={`${focusMode ? "lg:col-span-4" : "lg:col-span-3"} flex flex-col space-y-6`}>
          {activeEvent ? (
            <div className="bg-slate-900/20 border border-slate-900 rounded-3xl p-5 md:p-6 flex flex-col space-y-6">
              
              {/* High-Fidelity Active Stepper Progress Indicator */}
              <div className="bg-slate-950/60 border border-slate-900 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-amber-400">
                    <Activity className="w-4 h-4 text-amber-500 animate-pulse" />
                    <span>وضعیت پیشرفت گام‌به‌گام کارگاه:</span>
                  </div>
                  <div className="font-mono font-black text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    {activeTab === "setup" ? "۳۳٪" : activeTab === "teams" ? "۶۶٪" : "۱۰۰٪"} کامل شده
                  </div>
                </div>

                {/* Progress Bar Line */}
                <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-850">
                  <div 
                    className="h-full bg-gradient-to-l from-amber-500 to-amber-400 transition-all duration-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]" 
                    style={{ width: activeTab === "setup" ? "33%" : activeTab === "teams" ? "66%" : "100%" }}
                  />
                </div>

                {/* Legend Steps with Completion Checkmarks */}
                <div className="grid grid-cols-3 gap-2 text-[10px] md:text-xs">
                  <div 
                    onClick={() => setActiveTab("setup")}
                    className={`flex items-center gap-1.5 cursor-pointer p-1.5 rounded-lg transition-all ${
                      activeTab === "setup" ? "bg-amber-500/10 text-amber-300 font-bold border border-amber-500/20" : "text-slate-500 hover:text-slate-400"
                    }`}
                  >
                    <span className="w-4.5 h-4.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[9px]">✓</span>
                    <span className="truncate">۱. مشخصات و اهداف</span>
                  </div>

                  <div 
                    onClick={() => setActiveTab("teams")}
                    className={`flex items-center gap-1.5 cursor-pointer p-1.5 rounded-lg transition-all ${
                      activeTab === "teams" ? "bg-amber-500/10 text-amber-300 font-bold border border-amber-500/20" : "text-slate-500 hover:text-slate-400"
                    }`}
                  >
                    <span className={`w-4.5 h-4.5 rounded-full flex items-center justify-center font-bold text-[9px] ${
                      activeEvent.teams.length > 0 ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-slate-900 border-slate-800 text-slate-600"
                    }`}>
                      {activeEvent.teams.length > 0 ? "✓" : "۲"}
                    </span>
                    <span className="truncate">۲. تیم‌ها و امتیازدهی</span>
                  </div>

                  <div 
                    onClick={() => setActiveTab("analysis")}
                    className={`flex items-center gap-1.5 cursor-pointer p-1.5 rounded-lg transition-all ${
                      activeTab === "analysis" ? "bg-amber-500/10 text-amber-300 font-bold border border-amber-500/20" : "text-slate-500 hover:text-slate-400"
                    }`}
                  >
                    <span className={`w-4.5 h-4.5 rounded-full flex items-center justify-center font-bold text-[9px] ${
                      Object.keys(activeEvent.analyses || {}).length > 0 ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-slate-900 border-slate-800 text-slate-600"
                    }`}>
                      {Object.keys(activeEvent.analyses || {}).length > 0 ? "✓" : "۳"}
                    </span>
                    <span className="truncate">۳. گزارش دیبریف</span>
                  </div>
                </div>
              </div>

              {/* Event Context card */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 border border-slate-900 p-5 rounded-2xl">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] bg-amber-500/10 text-amber-400 font-bold px-2 py-0.5 rounded border border-amber-500/15">
                      در حال مدیریت کارگاه
                    </span>
                    <span className="text-[9px] text-slate-500 font-mono">{activeEvent.id}</span>
                    
                    {/* Focus Mode toggle within header */}
                    <button
                      onClick={() => setFocusMode(true)}
                      className="px-3 py-1 rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 text-[10px] font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_12px_rgba(245,158,11,0.08)]"
                      title="شروع کابین زنده ارزیابی و ثبت رفتارهای حین بازی"
                    >
                      <Eye className="w-3.5 h-3.5 animate-pulse" />
                      شروع کابین تمرکز زنده (Focus Cockpit)
                    </button>
                  </div>
                  <h2 className="text-lg font-extrabold text-white mt-1.5 leading-snug">{activeEvent.title}</h2>
                  <div className="flex flex-wrap gap-x-4 gap-y-2 mt-2 text-xs text-slate-400 font-medium">
                    <span className="flex items-center gap-1.5">
                      <Target className="w-3.5 h-3.5 text-amber-500" />
                      سازمان: <strong className="text-slate-300">{activeEvent.clientName}</strong>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-amber-500" />
                      تعداد تیم‌ها: <strong className="text-slate-300">{activeEvent.teams.length} تیم</strong>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Edit3 className="w-3.5 h-3.5 text-amber-500" />
                      تسهیل‌گر: <strong className="text-slate-300">{activeEvent.facilitatorName}</strong>
                    </span>
                  </div>
                </div>

                <div className="flex border-b border-slate-800 md:border-b-0 pb-3 md:pb-0 gap-1 self-start md:self-center">
                  <button
                    onClick={() => setActiveTab("setup")}
                    className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                      activeTab === "setup"
                        ? "bg-slate-800 text-amber-400 border border-slate-700 shadow"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    ۱. مشخصات و اهداف
                  </button>
                  <button
                    onClick={() => setActiveTab("teams")}
                    className={`px-4 py-2 text-xs font-bold rounded-xl transition-all relative ${
                      activeTab === "teams"
                        ? "bg-slate-800 text-amber-400 border border-slate-700 shadow"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    ۲. تیم‌ها و امتیازدهی
                    {activeEvent.teams.length === 0 && (
                      <span className="absolute -top-1 -left-1 w-2 h-2 bg-rose-500 rounded-full" />
                    )}
                  </button>
                  <button
                    onClick={() => setActiveTab("analysis")}
                    className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                      activeTab === "analysis"
                        ? "bg-slate-800 text-amber-400 border border-slate-700 shadow"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    ۳. گزارش هوشمند دیبریف
                  </button>
                </div>
              </div>

              {/* Tab Content 1: Setup & Goals */}
              {activeTab === "setup" && (
                <div className="space-y-6 animate-fade-in text-right">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {/* Event details update */}
                    <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                      <h3 className="text-xs font-bold text-slate-300 pb-2 border-b border-slate-900 flex items-center gap-2">
                        <Sliders className="w-4 h-4 text-amber-500" />
                        ویرایش مشخصات پایه
                      </h3>

                      <div className="space-y-3.5 text-xs text-right">
                        <div className="space-y-1.5">
                          <label className="text-slate-400 block font-medium">عنوان کارگاه تیم‌سازی</label>
                          <input
                            type="text"
                            value={activeEvent.title}
                            onChange={(e) => updateEventField("title", e.target.value)}
                            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-amber-500 transition-colors"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-slate-400 block font-medium">نام سازمان / مشتری</label>
                          <input
                            type="text"
                            value={activeEvent.clientName}
                            onChange={(e) => updateEventField("clientName", e.target.value)}
                            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-amber-500 transition-colors"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1.5">
                            <label className="text-slate-400 block font-medium">تسهیل‌گر ارشد</label>
                            <input
                              type="text"
                              value={activeEvent.facilitatorName}
                              onChange={(e) => updateEventField("facilitatorName", e.target.value)}
                              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-200 focus:outline-none focus:border-amber-500 transition-colors"
                            />
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-slate-400 block font-medium">تاریخ برگزاری</label>
                            <input
                              type="text"
                              value={activeEvent.date}
                              onChange={(e) => updateEventField("date", e.target.value)}
                              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 font-mono text-slate-200 text-center focus:outline-none focus:border-amber-500 transition-colors animate-none"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Goals display & selection */}
                    <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-900">
                        <h3 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                          <Target className="w-4 h-4 text-amber-500" />
                          اهداف شبیه‌سازی کامزی (ماژولار)
                        </h3>
                      </div>

                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        انتخاب اهداف کمک می‌کند تا هوش مصنوعی در تحلیل دیبریف نهایی تمرکز بهتری روی نتایج متناسب با خروجی‌های مدنظر تسهیل‌گر داشته باشد.
                      </p>

                      {/* Inline modular goal adder */}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="افزودن هدف ماژولار جدید..."
                          value={newModularGoalInput}
                          onChange={(e) => setNewModularGoalInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              handleAddModularGoal(newModularGoalInput);
                            }
                          }}
                          className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-amber-500"
                        />
                        <button
                          type="button"
                          onClick={() => handleAddModularGoal(newModularGoalInput)}
                          className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                        >
                          ثبت هدف
                        </button>
                      </div>

                      <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                        {customGoals.map((goal, idx) => {
                          const isSelected = activeEvent.goals.includes(goal);
                          return (
                            <div
                              key={idx}
                              onClick={() => {
                                let updatedGoals = [];
                                if (isSelected) {
                                  updatedGoals = activeEvent.goals.filter((g) => g !== goal);
                                  if (updatedGoals.length === 0) updatedGoals = [customGoals[0]];
                                } else {
                                  updatedGoals = [...activeEvent.goals, goal];
                                }
                                updateEventField("goals", updatedGoals);
                              }}
                              className={`p-2.5 rounded-xl border text-xs leading-relaxed text-right cursor-pointer flex items-center justify-between transition-all ${
                                isSelected
                                  ? "bg-amber-500/10 border-amber-500/30 text-amber-300 font-semibold"
                                  : "bg-slate-900/60 border-slate-900 text-slate-400 hover:border-slate-800 hover:text-slate-300"
                              }`}
                            >
                              <div className="flex items-start gap-2.5">
                                <span className={`w-4 h-4 rounded-full flex-shrink-0 flex items-center justify-center border mt-0.5 ${
                                  isSelected ? "bg-amber-500 border-amber-400 text-slate-950" : "border-slate-700 text-transparent"
                                }`}>
                                  ✓
                                </span>
                                <span>{goal}</span>
                              </div>
                              
                              {!DEFAULT_GOALS.includes(goal) && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleRemoveModularGoal(goal);
                                  }}
                                  className="text-rose-500 hover:text-rose-400 font-bold px-1 text-[10px] cursor-pointer"
                                  title="حذف هدف سفارشی"
                                >
                                  [حذف]
                                </button>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Games Selection */}
                  <GamesPicker
                    selectedGames={activeEvent.selectedGames || []}
                    customGames={activeEvent.customGames || []}
                    onToggleGame={handleToggleGame}
                    onAddCustomGame={handleAddCustomGame}
                    onRemoveCustomGame={handleRemoveCustomGame}
                  />

                  {/* Dashboard Appearance Theme Settings Card */}
                  <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center gap-2 pb-2 border-b border-slate-900">
                      <Sliders className="w-4 h-4 text-amber-500" />
                      <h4 className="font-bold text-xs text-slate-300">تنظیمات ظاهری داشبورد (پوسته و تم رنگی)</h4>
                    </div>

                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      پوسته رنگی پیش‌فرض تسهیل‌یار را متناسب با نور محیط کارگاه تنظیم نمایید. پوسته روشن با کنتراست بالا برای کار در محیط‌های باز، فضاهای بسیار پرنور یا استفاده بر روی ویدیو پروژکتورهای کم‌نور ایده‌آل است.
                    </p>

                    <div className="flex flex-col sm:flex-row gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          setDashboardTheme("dark");
                          localStorage.setItem("comzee_dashboard_theme", "dark");
                        }}
                        className={`flex-1 py-3 px-4 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                          dashboardTheme === "dark"
                            ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/10"
                            : "bg-slate-900 border-slate-850 text-slate-400 hover:text-slate-300 hover:bg-slate-850"
                        }`}
                      >
                        <Moon className="w-4 h-4" />
                        تم تاریک فضایی (پیش‌فرض)
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setDashboardTheme("light");
                          localStorage.setItem("comzee_dashboard_theme", "light");
                        }}
                        className={`flex-1 py-3 px-4 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                          dashboardTheme === "light"
                            ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/10"
                            : "bg-slate-900 border-slate-850 text-slate-400 hover:text-slate-300 hover:bg-slate-850"
                        }`}
                      >
                        <Sun className="w-4 h-4" />
                        تم روشن با کنتراست بالا (محیط پرنور)
                      </button>
                    </div>
                  </div>

                  {/* AI Output Tone Settings Card */}
                  <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4 text-right">
                    <div className="flex items-center gap-2 pb-2 border-b border-slate-900">
                      <Brain className="w-4 h-4 text-amber-500" />
                      <h4 className="font-bold text-xs text-slate-300">تنظیمات هوش مصنوعی و لحن خروجی گزارش (Comzee AI Tone)</h4>
                    </div>

                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      لحن پاسخ‌دهی، نگارش گزارش نهایی، تحلیل‌های ریشه‌ای و مایکرو-پرکتیس‌های تولید شده توسط هوش مصنوعی کامزی را متناسب با فرهنگ سازمانی مشتری یا صلاحدید خود تنظیم کنید.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        type="button"
                        onClick={() => updateEventField("aiTone", "motivational")}
                        className={`py-3 px-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all cursor-pointer ${
                          (activeEvent.aiTone || "analytical") === "motivational"
                            ? "bg-amber-500/15 text-amber-400 border-amber-500/40 shadow-lg shadow-amber-500/5 font-extrabold"
                            : "bg-slate-900 border-slate-850 text-slate-400 hover:text-slate-300 hover:bg-slate-850"
                        }`}
                      >
                        <span className="text-xs font-bold">💪 انگیزشی و الهام‌بخش</span>
                        <span className="text-[9px] text-slate-500 leading-relaxed">تکیه روی توانمندی‌ها، ارتقای همبستگی و تشویق تیم</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => updateEventField("aiTone", "analytical")}
                        className={`py-3 px-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all cursor-pointer ${
                          (activeEvent.aiTone || "analytical") === "analytical"
                            ? "bg-amber-500/15 text-amber-400 border-amber-500/40 shadow-lg shadow-amber-500/5 font-extrabold"
                            : "bg-slate-900 border-slate-850 text-slate-400 hover:text-slate-300 hover:bg-slate-850"
                        }`}
                      >
                        <span className="text-xs font-bold">🔬 علمی و تحلیل‌گرایانه</span>
                        <span className="text-[9px] text-slate-500 leading-relaxed">دقیق، علمی، جدی، ریشه‌یابی منطقی عمیق رفتارها</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => updateEventField("aiTone", "strict")}
                        className={`py-3 px-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all cursor-pointer ${
                          (activeEvent.aiTone || "analytical") === "strict"
                            ? "bg-amber-500/15 text-amber-400 border-amber-500/40 shadow-lg shadow-amber-500/5 font-extrabold"
                            : "bg-slate-900 border-slate-850 text-slate-400 hover:text-slate-300 hover:bg-slate-850"
                        }`}
                      >
                        <span className="text-xs font-bold">🎯 رک، صریح و مطالبه‌گر</span>
                        <span className="text-[9px] text-slate-500 leading-relaxed">به چالش کشیدن سستی‌ها، ناهماهنگی‌ها و نقد سازنده ضعف‌ها</span>
                      </button>
                    </div>
                  </div>

                  {/* Webhook Integrations settings panel (Extensible scaling) */}
                  <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center gap-2 pb-2 border-b border-slate-900">
                      <Sliders className="w-4 h-4 text-emerald-400" />
                      <h4 className="font-bold text-xs text-slate-300">اتصال وب‌هوکی و خودکارسازی CRM سازمان (N8N / Make / DigiKala / Snapp)</h4>
                    </div>

                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      با تعریف آدرس وب‌هوک اختصاصی، می‌توانید فایل JSON کامل رویداد را پس از اتمام دیبریف مستقیماً به سیستم‌های پرسنلی یا اتوماسیون‌های دلخواه ارسال نمایید. این قابلیت امکان یکپارچه‌سازی کامل و صدور گزارش‌های خودکار را فراهم می‌کند.
                    </p>

                    <div className="flex flex-col sm:flex-row gap-3">
                      <div className="flex-1 space-y-1">
                        <label className="text-slate-500 text-[10px] block font-bold">آدرس وب‌هوک اتوماسیون (POST URL)</label>
                        <input
                          type="text"
                          value={webhookUrl}
                          onChange={(e) => {
                            setWebhookUrl(e.target.value);
                            localStorage.setItem("comzee_webhook_url", e.target.value);
                          }}
                          placeholder="https://your-n8n-instance.com/webhook/debrief..."
                          className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-300 focus:outline-none focus:border-amber-500 font-mono"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={handleTriggerWebhook}
                        disabled={isSendingWebhook}
                        className={`sm:self-end px-5 py-2.5 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer ${
                          webhookStatus === "success"
                            ? "bg-emerald-500 text-slate-950"
                            : webhookStatus === "error"
                            ? "bg-rose-500 text-white"
                            : "bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300"
                        }`}
                      >
                        {isSendingWebhook ? (
                          <span className="w-4 h-4 border-2 border-slate-300 border-t-transparent rounded-full animate-spin" />
                        ) : webhookStatus === "success" ? (
                          "✓ با موفقیت ارسال شد"
                        ) : webhookStatus === "error" ? (
                          "❌ خطا در ارسال وب‌هوک"
                        ) : (
                          "ارسال کل داده‌های دیبریف (POST)"
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Google Drive app version saving panel */}
                  <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4 text-right">
                    <div className="flex items-center gap-2 pb-2 border-b border-slate-900">
                      <CloudUpload className="w-4 h-4 text-amber-500" />
                      <h4 className="font-bold text-xs text-slate-300">پشتیبان‌گیری و ذخیره‌سازی نسخه روی گوگل درایو (Google Drive Versioning)</h4>
                    </div>

                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      شما می‌توانید داده‌ها، تنظیمات و کارگاه‌های فعال خود را در قالب یک نسخه پشتیبان در پوشه اختصاصی <strong className="text-amber-400">«ورژن یک دستیار تیم سازی کامزی»</strong> روی گوگل درایو شخصی خود ذخیره کنید.
                    </p>

                    <div className="flex flex-col sm:flex-row items-center gap-4">
                      <button
                        type="button"
                        onClick={handleSaveAppToDrive}
                        disabled={isSavingAppToDrive}
                        className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-l from-amber-500 to-amber-400 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 hover:scale-[1.01] transition-transform cursor-pointer"
                      >
                        {isSavingAppToDrive ? (
                          <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                        ) : (
                          <CloudUpload className="w-4 h-4 text-slate-950 stroke-[2.5]" />
                        )}
                        {isSavingAppToDrive ? "در حال ایجاد پوشه و ذخیره روی درایو..." : "ذخیره این نسخه در گوگل درایو"}
                      </button>

                      {appDriveUserEmail && (
                        <span className="text-[10px] text-slate-500 font-bold">
                          متصل به حساب: {appDriveUserEmail}
                        </span>
                      )}
                    </div>

                    {appDriveSuccess && appDriveLink && (
                      <div className="bg-emerald-950/20 border border-emerald-900/30 text-emerald-400 p-4 rounded-xl text-xs space-y-2">
                        <p className="font-extrabold flex items-center gap-1.5 justify-end">
                          <span>✓ فایل با موفقیت در پوشه «ورژن یک دستیار تیم سازی کامزی» ذخیره شد</span>
                        </p>
                        <p className="text-[10px] text-slate-400">
                          برای دسترسی به فایل بک‌آپ و پوشه ایجاد شده در حساب کاربری گوگل خود، می‌توانید روی لینک زیر کلیک کنید:
                        </p>
                        <div className="flex justify-end">
                          <a
                            href={appDriveLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-xs text-amber-400 hover:underline font-bold"
                          >
                            مشاهده پوشه و فایل در گوگل درایو ↗
                          </a>
                        </div>
                      </div>
                    )}

                    {appDriveError && (
                      <div className="bg-rose-950/20 border border-rose-900/30 text-rose-400 p-4 rounded-xl text-xs">
                        <p className="font-extrabold text-right">⚠️ خطا در ذخیره روی گوگل درایو:</p>
                        <p className="text-[10px] text-slate-400 text-right mt-1">{appDriveError}</p>
                      </div>
                    )}
                  </div>

                  {/* Facilitator tools */}
                  <FacilitatorTips />
                </div>
              )}

              {/* Tab Content 2: Teams and Ratings */}
              {activeTab === "teams" && (
                <div className="space-y-6 animate-fade-in text-right">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="font-extrabold text-base text-white">ثبت نتایج ارزیابی و خودارزیابی تیم‌ها</h3>
                      <p className="text-xs text-slate-400 mt-1">تیم‌های حاضر در شبیه‌سازی را ثبت و ابعاد رفتاری آن‌ها را نمره‌دهی کنید.</p>
                    </div>
                    <button
                      onClick={handleAddTeam}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 font-bold text-xs rounded-xl flex items-center gap-1.5 self-start sm:self-center transition-all shadow-sm"
                    >
                      <Plus className="w-4 h-4 text-amber-500" />
                      افزودن تیم جدید
                    </button>
                  </div>

                  {activeEvent.teams.length === 0 ? (
                    <div className="bg-slate-950/40 border border-slate-900 rounded-3xl p-12 text-center flex flex-col items-center justify-center space-y-3">
                      <Users className="w-12 h-12 text-slate-700" />
                      <div>
                        <h4 className="font-bold text-sm text-slate-400">هیچ تیمی برای این کارگاه تعریف نشده است</h4>
                        <p className="text-xs text-slate-500 mt-1">برای شروع نمره‌دهی و تحلیل دیبریف، تیم‌های حاضر را ایجاد کنید.</p>
                      </div>
                      <button
                        onClick={handleAddTeam}
                        className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl mt-2 shadow"
                      >
                        ایجاد اولین تیم
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {/* Segmented Team Switcher Bar */}
                      <div className="bg-slate-950/40 border border-slate-900 p-3 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div className="flex flex-wrap gap-2">
                          {activeEvent.teams.map((t, idx) => {
                            const isSelected = selectedTeamIdForObservation ? t.id === selectedTeamIdForObservation : idx === 0;
                            return (
                              <button
                                key={t.id}
                                onClick={() => setSelectedTeamIdForObservation(t.id)}
                                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                                  isSelected
                                    ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md font-extrabold"
                                    : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                                }`}
                              >
                                {t.name}
                              </button>
                            );
                          })}
                        </div>
                        <span className="text-[10px] text-slate-500 font-bold hidden md:inline">
                          تیم‌های فعال کارگاهی (سوئیچ مابین داده‌های هر تیم)
                        </span>
                      </div>

                      {/* Single Team Observer Panel */}
                      {(() => {
                        const team = activeEvent.teams.find(t => t.id === selectedTeamIdForObservation) || activeEvent.teams[0];
                        if (!team) return null;
                        const teamIdx = activeEvent.teams.findIndex(t => t.id === team.id);
                        return (
                          <div
                            key={team.id}
                            className="bg-slate-950/50 border border-slate-900 rounded-2xl p-5 md:p-6 space-y-6 relative overflow-hidden"
                          >
                          {/* Team label / Delete */}
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-900 pb-4">
                            <div className="flex flex-wrap items-center gap-3">
                              <span className="w-7 h-7 rounded-full bg-slate-800 text-amber-400 font-black text-xs flex items-center justify-center font-mono border border-slate-700 shadow">
                                {teamIdx + 1}
                              </span>
                              
                              <div className="flex items-center gap-2">
                                <input
                                  type="text"
                                  value={team.name}
                                  onChange={(e) => handleUpdateTeam(team.id, "name", e.target.value)}
                                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-sm font-bold text-white focus:outline-none focus:border-amber-500 transition-colors w-40 sm:w-56"
                                  placeholder="نام تیم"
                                />
                                <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
                                  <span className="text-slate-500 font-medium">تعداد اعضا:</span>
                                  <input
                                    type="number"
                                    value={team.membersCount}
                                    onChange={(e) => handleUpdateTeam(team.id, "membersCount", parseInt(e.target.value) || 1)}
                                    className="bg-transparent font-bold font-mono text-amber-400 focus:outline-none w-8 text-center"
                                    min="1"
                                  />
                                </div>
                              </div>
                            </div>

                            <button
                              onClick={() => handleRemoveTeam(team.id)}
                              className="text-xs text-rose-500 hover:text-rose-400 flex items-center gap-1.5 font-bold self-end sm:self-center transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              حذف تیم
                            </button>
                          </div>

                          {/* Scores panel: Team Dynamics Evaluation */}
                          <div className="space-y-6">
                            
                            {/* Team Dynamics assessment */}
                            <div className="bg-slate-900/40 border border-slate-900 p-6 rounded-2xl space-y-5">
                              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs pb-2 border-b border-slate-950/40">
                                <span className="w-2 h-2 rounded-full bg-amber-500" />
                                <h4>ارزیابی پویایی‌های تیمی کارگاه</h4>
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-4">
                                  {(Object.keys(SCORE_LABELS) as Array<keyof TeamScores>).map((dim) => (
                                    <div key={dim} className="space-y-1 text-right">
                                      <div className="flex items-center justify-between text-[11px] font-semibold">
                                        <span className="text-slate-300 flex items-center gap-1">
                                          {SCORE_LABELS[dim].fa}
                                          <span className="group relative">
                                            <Info className="w-3 h-3 text-slate-500 hover:text-slate-400 cursor-help" />
                                            <span className="pointer-events-none absolute bottom-full right-0 w-52 bg-slate-950 text-slate-300 p-2.5 rounded-lg border border-slate-800 text-[10px] leading-relaxed shadow-xl opacity-0 group-hover:opacity-100 transition-opacity z-20 mb-1">
                                              {SCORE_LABELS[dim].description}
                                            </span>
                                          </span>
                                        </span>
                                        <span className="font-mono text-amber-400 font-bold">{team.postScores[dim]} / ۱۰</span>
                                      </div>
                                      <div className="flex items-center gap-3">
                                        <input
                                          type="range"
                                          min="1"
                                          max="10"
                                          value={team.postScores[dim]}
                                          onChange={(e) => handleUpdateTeamScore(team.id, "post", dim, parseInt(e.target.value))}
                                          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                                        />
                                      </div>
                                    </div>
                                  ))}
                                </div>

                                <div className="space-y-3 flex flex-col justify-between">
                                  <div className="space-y-1.5 text-xs flex-1 flex flex-col">
                                    <label className="text-slate-400 font-medium">ملاحظات، شواهد رفتاری و پویایی‌های تیم حین فعالیت‌ها</label>
                                    <textarea
                                      value={team.postNotes}
                                      onChange={(e) => handleUpdateTeam(team.id, "postNotes", e.target.value)}
                                      className="w-full flex-1 bg-slate-950/60 border border-slate-900 rounded-xl p-3 text-slate-300 text-xs focus:outline-none focus:border-amber-500/60 transition-colors h-full min-h-[140px] resize-none leading-relaxed"
                                      placeholder="نقاط قوت و چالش‌های مشاهده شده، الگوهای ارتباطی اعضا، حل مسئله و..."
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>

                          </div>

                          {/* Behavioral Quick-Logger */}
                          <div className="bg-slate-900/30 border border-slate-900 rounded-2xl p-5 space-y-4 text-right">
                            <div className="flex items-center justify-between flex-wrap gap-2">
                              <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                                <Activity className="w-4 h-4 text-rose-400" />
                                ثبت رفتارهای حین بازی (Behavioral Quick-Logger)
                              </h4>
                              <span className="text-[10px] bg-rose-500/10 text-rose-400 px-2.5 py-0.5 rounded-full font-bold font-mono">
                                {(team.behaviorTags || []).length} رفتار ثبت‌شده
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-500 leading-relaxed">
                              تگ‌های رفتاری مشاهده‌شده حین بازی را با یک کلیک فعال کنید تا وارد تحلیل هوش مصنوعی شوند. همچنین می‌توانید تگ‌های دلخواه خود را اضافه کنید.
                            </p>

                            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
                              {QUICK_BEHAVIOR_TAGS.map((tag) => {
                                const isSelected = (team.behaviorTags || []).includes(tag.label);
                                return (
                                  <button
                                    key={tag.label}
                                    type="button"
                                    onClick={() => handleToggleBehaviorTag(team.id, tag.label)}
                                    className={`p-2.5 rounded-xl text-[11px] font-bold text-right transition-all border flex flex-col justify-between h-[68px] cursor-pointer select-none ${
                                      isSelected
                                        ? tag.type === "positive"
                                          ? "bg-emerald-500/10 border-emerald-500/40 text-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.1)]"
                                          : "bg-rose-500/10 border-rose-500/40 text-rose-400 shadow-[0_0_12px_rgba(244,63,94,0.1)]"
                                        : "bg-slate-950/40 border-slate-900 text-slate-400 hover:border-slate-800 hover:text-slate-300"
                                    }`}
                                  >
                                    <span className="text-[9px] text-slate-500 block">
                                      {tag.type === "positive" ? "پویایی مثبت" : "چالش گروهی"}
                                    </span>
                                    <span className="font-semibold block truncate mt-1">{tag.label}</span>
                                  </button>
                                );
                              })}
                            </div>

                            {/* Custom Behavior Tag Input */}
                            <div className="pt-2 border-t border-slate-900/40 flex items-center gap-2">
                              <input
                                type="text"
                                value={customTagInputs[team.id] || ""}
                                onChange={(e) => setCustomTagInputs((prev) => ({ ...prev, [team.id]: e.target.value }))}
                                onKeyDown={(e) => {
                                  if (e.key === "Enter") {
                                    e.preventDefault();
                                    if (customTagInputs[team.id]?.trim()) {
                                      handleAddCustomBehaviorTag(team.id, customTagInputs[team.id]);
                                      setCustomTagInputs((prev) => ({ ...prev, [team.id]: "" }));
                                    }
                                  }
                                }}
                                className="flex-1 bg-slate-950/60 border border-slate-900 rounded-xl px-3 py-2 text-slate-300 text-xs focus:outline-none focus:border-amber-500/60 placeholder:text-slate-650"
                                placeholder="ثبت رفتار سفارشی دیگر... (سپس Enter بزنید)"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  if (customTagInputs[team.id]?.trim()) {
                                    handleAddCustomBehaviorTag(team.id, customTagInputs[team.id]);
                                    setCustomTagInputs((prev) => ({ ...prev, [team.id]: "" }));
                                  }
                                }}
                                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 font-bold text-xs rounded-xl transition-all"
                              >
                                ثبت تگ
                              </button>
                            </div>
                            
                            {/* Render Custom tags */}
                            {team.behaviorTags && team.behaviorTags.some(tag => !QUICK_BEHAVIOR_TAGS.map(t => t.label).includes(tag)) && (
                              <div className="flex flex-wrap gap-1.5 pt-2">
                                <span className="text-[10px] text-slate-500 self-center font-semibold">تگ‌های دلخواه ثبت‌شده:</span>
                                {team.behaviorTags.filter(tag => !QUICK_BEHAVIOR_TAGS.map(t => t.label).includes(tag)).map((tag) => (
                                  <span
                                    key={tag}
                                    className="inline-flex items-center gap-1.5 text-[10px] font-bold bg-slate-900 border border-slate-800 text-slate-300 px-2.5 py-1 rounded-lg"
                                  >
                                    <span>{tag}</span>
                                    <button
                                      type="button"
                                      onClick={() => handleToggleBehaviorTag(team.id, tag)}
                                      className="text-rose-500 hover:text-rose-400 font-extrabold text-[10px] cursor-pointer"
                                    >
                                      ✕
                                    </button>
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* Self-Reflection input form */}
                          <div className="bg-slate-900/30 border border-slate-900 rounded-2xl p-5 space-y-4">
                            <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                              <Brain className="w-4 h-4 text-amber-500" />
                              بازتاب تیمی (Team Reflection & Debriefing Questions)
                            </h4>
                            <p className="text-[10px] text-slate-500 leading-relaxed">
                              ثبت مستقیم نظرات و جملاتی که اعضای تیم در طول مکالمه دیبریف نهایی به کار برده‌اند. این بخش اساس تحلیل‌های کیفی هوش مصنوعی است.
                            </p>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-right">
                              <div className="space-y-1.5">
                                <label className="text-slate-400 block font-medium">چه چیزهایی خوب پیش رفت؟ (نقاط قوت پنهان)</label>
                                <textarea
                                  value={team.reflection.whatWentWell}
                                  onChange={(e) => handleUpdateReflection(team.id, "whatWentWell", e.target.value)}
                                  className="w-full bg-slate-950/60 border border-slate-900 rounded-xl p-2.5 text-slate-300 text-xs focus:outline-none focus:border-amber-500/60 h-20 resize-none leading-relaxed"
                                  placeholder="مثال: همفکری اعضا قبل از لمس ابزار بازی، پشتیبانی روانی از هم تیمی بازمانده"
                                />
                              </div>

                              <div className="space-y-1.5">
                                <label className="text-slate-400 block font-medium">چه چالش‌ها و تضادهایی وجود داشت؟ (موانع هماهنگی)</label>
                                <textarea
                                  value={team.reflection.challenges}
                                  onChange={(e) => handleUpdateReflection(team.id, "challenges", e.target.value)}
                                  className="w-full bg-slate-950/60 border border-slate-900 rounded-xl p-2.5 text-slate-300 text-xs focus:outline-none focus:border-amber-500/60 h-20 resize-none leading-relaxed"
                                  placeholder="مثال: کمبود شنیدن فعال به دلیل عجله و اضطراب ناشی از تایمر، نادیده گرفتن ایده جدید"
                                />
                              </div>

                              <div className="space-y-1.5">
                                <label className="text-slate-400 block font-medium">چه درس‌هایی از بازی‌ها گرفتیم؟ (بینش‌های عمیق)</label>
                                <textarea
                                  value={team.reflection.learnings}
                                  onChange={(e) => handleUpdateReflection(team.id, "learnings", e.target.value)}
                                  className="w-full bg-slate-950/60 border border-slate-900 rounded-xl p-2.5 text-slate-300 text-xs focus:outline-none focus:border-amber-500/60 h-20 resize-none leading-relaxed"
                                  placeholder="مثال: یاد گرفتیم داشتن استراتژی جامع، سرعت پیاده‌سازی را ۱۰ برابر می‌کند"
                                />
                              </div>

                              <div className="space-y-1.5">
                                <label className="text-slate-400 block font-medium">نحوه به کارگیری این درس‌ها در کار روزمره دفتر (Workspace Action Plan)</label>
                                <textarea
                                  value={team.reflection.actionPlan}
                                  onChange={(e) => handleUpdateReflection(team.id, "actionPlan", e.target.value)}
                                  className="w-full bg-slate-950/60 border border-slate-900 rounded-xl p-2.5 text-slate-300 text-xs focus:outline-none focus:border-amber-500/60 h-20 resize-none leading-relaxed"
                                  placeholder="مثال: در پروژه‌های تیمی از این پس ابتدا ۳ دقیقه صمت اختیاری برای بارش فکری فردی خواهیم گذاشت"
                                />
                              </div>
                            </div>

                            {/* AI Debrief Questions Generator Block */}
                            <div className="border-t border-slate-900/60 pt-4 mt-2 space-y-3 text-right">
                              <div className="flex items-center justify-between flex-wrap gap-3">
                                <div className="space-y-1">
                                  <h5 className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                                    <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                                    سوالات دیبریف تسهیل‌گری هوشمند و اختصاصی
                                  </h5>
                                  <p className="text-[10px] text-slate-400 leading-relaxed">
                                    تولید هوشمندانه ۳ سوال عمیق و غیرکلیشه‌ای بر اساس تفاوت‌های نمرات و چالش‌های این تیم جهت هدایت گفتگو در جلسه زنده دیبریف.
                                  </p>
                                </div>
                                
                                <button
                                  type="button"
                                  onClick={() => handleGenerateAIQuestions(team)}
                                  disabled={isGeneratingQuestions[team.id]}
                                  className={`px-4 py-2 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 transition-all shadow-sm ${
                                    isGeneratingQuestions[team.id]
                                      ? "bg-slate-800 text-slate-500 cursor-not-allowed"
                                      : "bg-amber-500/10 text-amber-400 border border-amber-500/20 hover:bg-amber-500/20 hover:scale-[1.01]"
                                  }`}
                                >
                                  {isGeneratingQuestions[team.id] ? (
                                    <>
                                      <div className="w-3.5 h-3.5 rounded-full border-2 border-amber-400/20 border-t-amber-400 animate-spin" />
                                      <span>در حال طراحی سوالات اختصاصی...</span>
                                    </>
                                  ) : (
                                    <>
                                      <Sparkles className="w-3.5 h-3.5" />
                                      <span>{team.aiQuestions && team.aiQuestions.length > 0 ? "بازسازی سوالات هوشمند" : "تولید ۳ سوال اختصاصی با هوش مصنوعی"}</span>
                                    </>
                                  )}
                                </button>
                              </div>

                              {isGeneratingQuestions[team.id] && (
                                <div className="bg-slate-950/40 border border-slate-900/40 rounded-xl p-6 text-center space-y-2.5 animate-pulse">
                                  <Brain className="w-6 h-6 text-amber-500/80 mx-auto animate-bounce" />
                                  <p className="text-[11px] text-slate-400 font-semibold">تسهیل‌گر گرامی، الگوریتم‌های هوش مصنوعی کامزی در حال تحلیل رفتارهای تیم و صورت‌بندی ۳ سوال عمیق و تامل‌برانگیز هستند...</p>
                                </div>
                              )}

                              {!isGeneratingQuestions[team.id] && team.aiQuestions && team.aiQuestions.length > 0 && (
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1 animate-fade-in">
                                  {team.aiQuestions.map((q) => {
                                    const isCopied = copiedQuestionId === `${team.id}_${q.id}`;
                                    return (
                                      <div key={q.id} className="bg-slate-950/60 border border-slate-900 rounded-xl p-3.5 space-y-2.5 relative flex flex-col justify-between group hover:border-amber-500/30 hover:bg-slate-950/80 transition-all duration-300">
                                        <div className="space-y-2">
                                          <div className="flex items-center justify-between">
                                            <span className="text-[9px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded">
                                              سوال {q.id} • {q.oridCategory}
                                            </span>
                                            
                                            <button
                                              type="button"
                                              onClick={() => {
                                                navigator.clipboard.writeText(q.question);
                                                setCopiedQuestionId(`${team.id}_${q.id}`);
                                                setTimeout(() => setCopiedQuestionId(null), 2000);
                                              }}
                                              className="text-slate-500 hover:text-white p-1 rounded hover:bg-slate-900 transition-colors flex items-center gap-1"
                                              title="کپی سوال"
                                            >
                                              {isCopied ? (
                                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                              ) : (
                                                <Copy className="w-3.5 h-3.5" />
                                              )}
                                            </button>
                                          </div>
                                          
                                          <p className="text-xs font-bold text-slate-100 leading-relaxed font-sans">
                                            « {q.question} »
                                          </p>
                                        </div>
                                        
                                        <div className="bg-slate-900/40 rounded-lg p-2 border border-slate-900/30 mt-1">
                                          <div className="flex items-start gap-1">
                                            <HelpCircle className="w-3 h-3 text-slate-500 mt-0.5 shrink-0" />
                                            <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                                              <span className="text-slate-500">هدف تسهیل‌گر: </span>
                                              {q.intent}
                                            </p>
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Quick Navigation / Action to AI report */}
                          <div className="flex justify-end pt-3">
                            <button
                              onClick={() => {
                                handleRunAIAnalysis(team);
                                setActiveTab("analysis");
                              }}
                              className="px-5 py-2.5 bg-gradient-to-l from-amber-500 to-amber-400 text-slate-950 font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-all shadow-md hover:shadow-amber-500/10 hover:scale-[1.01]"
                            >
                              <Brain className="w-4 h-4 stroke-[2]" />
                              تحلیل پویایی تیمی و صدور دیبریف نهایی با هوش مصنوعی
                            </button>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}
                </div>
              )}

              {/* Tab Content 3: Debrief Analysis Results */}
              {activeTab === "analysis" && (
                <div className="space-y-6 animate-fade-in text-right">
                  
                  {isAnalyzing ? (
                    <div className="bg-slate-950/50 border border-slate-900 rounded-3xl p-16 text-center flex flex-col items-center justify-center space-y-6">
                      <div className="relative">
                        <div className="w-16 h-16 rounded-full border-4 border-amber-500/20 border-t-amber-500 animate-spin" />
                        <Brain className="w-7 h-7 text-amber-400 absolute inset-0 m-auto animate-pulse" />
                      </div>
                      
                      <div className="space-y-2 max-w-md">
                        <h4 className="font-extrabold text-white text-base">کابین تحلیل هوش مصنوعی کامزی در حال پردازش است</h4>
                        <p className="text-xs text-slate-400 font-semibold">{analysisProgressMsg}</p>
                        <p className="text-[10px] text-slate-500 leading-relaxed pt-2">
                          تسهیل‌گر گرامی، هوش مصنوعی ما در حال تدوین یک تحلیل عمیق پویایی تیمی مبتنی بر شواهد رفتاری ثبت شده توسط شما و همچنین بازتاب عینی اعضای تیم است.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      
                      {/* Active teams selector for reports */}
                      <div className="bg-slate-950/60 border border-slate-900 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div className="flex items-center gap-2">
                          <Brain className="w-5 h-5 text-amber-500" />
                          <h4 className="font-bold text-xs text-slate-300">گزارش‌های دیبریف تیمی صادر شده:</h4>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {activeEvent.teams.length > 1 && (
                            <button
                              onClick={() => setSelectedTeamIdForAnalysis("all_teams")}
                              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all border cursor-pointer ${
                                selectedTeamIdForAnalysis === "all_teams"
                                  ? "bg-amber-500 text-slate-950 border-amber-400 shadow"
                                  : (activeEvent.analyses && activeEvent.analyses["all_teams"])
                                  ? "bg-slate-900 border-slate-800 text-amber-400 hover:bg-slate-850"
                                  : "bg-slate-950 border-slate-900 text-slate-550 hover:text-slate-400"
                              }`}
                            >
                              📊 خلاصه کل تیم‌ها (تجمیعی)
                              {activeEvent.analyses && activeEvent.analyses["all_teams"] && (
                                <span className="inline-block w-1.5 h-1.5 bg-emerald-400 rounded-full mr-1.5" />
                              )}
                            </button>
                          )}
                          
                          {activeEvent.teams.map((t) => {
                            const isSelected = selectedTeamIdForAnalysis === t.id;
                            const hasReport = activeEvent.analyses && activeEvent.analyses[t.id];
                            return (
                              <button
                                key={t.id}
                                onClick={() => setSelectedTeamIdForAnalysis(t.id)}
                                className={`px-4 py-2 text-xs font-bold rounded-xl transition-all border cursor-pointer ${
                                  isSelected
                                    ? "bg-amber-500 text-slate-950 border-amber-400 shadow"
                                    : hasReport
                                    ? "bg-slate-900 border-slate-800 text-amber-400 hover:bg-slate-850"
                                    : "bg-slate-950 border-slate-900 text-slate-600 hover:text-slate-400"
                                }`}
                              >
                                {t.name}
                                {hasReport && (
                                  <span className="inline-block w-1.5 h-1.5 bg-emerald-400 rounded-full mr-1.5" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* No team selected or no analysis available */}
                      {!selectedTeamIdForAnalysis || !activeEvent.analyses || !activeEvent.analyses[selectedTeamIdForAnalysis] ? (
                        <div className="bg-slate-950/40 border border-slate-900 rounded-3xl p-12 text-center flex flex-col items-center justify-center space-y-4">
                          <Tv className="w-12 h-12 text-slate-700" />
                          
                          {selectedTeamIdForAnalysis === "all_teams" ? (
                            <div className="space-y-3">
                              <h4 className="font-bold text-sm text-slate-400">تحلیل خلاصه مدیریتی (کل تیم‌ها) صادر نشده است</h4>
                              <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto leading-relaxed">
                                با ترکیب و تجمیع نمرات رفتاری و کیفی تمام تیم‌های این کارگاه، یک تحلیل یکپارچه برای کل رویداد تدوین و صادر کنید. این گزارش برای ارائه مستقیم به کارفرما عالی است.
                              </p>
                              
                              <button
                                onClick={() => handleRunAllTeamsAnalysis()}
                                className="px-5 py-2.5 mt-2 bg-gradient-to-l from-amber-500 to-amber-400 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 transition-all shadow-md hover:scale-[1.01] mx-auto cursor-pointer"
                              >
                                <Brain className="w-4 h-4" />
                                تحلیل هوشمند کل تیم‌ها (تجمیعی)
                              </button>
                            </div>
                          ) : (
                            <div>
                              <h4 className="font-bold text-sm text-slate-400">هیچ تحلیلی هنوز نهایی نشده است</h4>
                              <p className="text-xs text-slate-500 mt-1">
                                ابتدا یک تیم را از نوار بالای همین بخش انتخاب کنید یا دکمه زیر را برای تحلیل تیم انتخابی کلیک کنید.
                              </p>
                              
                              {activeEvent.teams.length > 0 && (() => {
                                const currentTeam = activeEvent.teams.find(t => t.id === selectedTeamIdForAnalysis);
                                const targetTeam = currentTeam || activeEvent.teams[0];
                                return (
                                  <button
                                    onClick={() => handleRunAIAnalysis(targetTeam)}
                                    className="px-5 py-2.5 mt-4 bg-gradient-to-l from-amber-500 to-amber-400 text-slate-950 hover:scale-[1.01] transition-transform font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md shadow-amber-500/10 cursor-pointer mx-auto"
                                  >
                                    <Brain className="w-4 h-4 stroke-[2.5]" />
                                    تحلیل {targetTeam.name} با هوش مصنوعی کامزی
                                  </button>
                                );
                              })()}
                            </div>
                          )}
                        </div>
                      ) : (
                        // Report Workspace
                        (() => {
                          const analysis = activeEvent.analyses[selectedTeamIdForAnalysis];
                          
                          let team: Team;
                          if (selectedTeamIdForAnalysis === "all_teams") {
                            const aggregated = getAggregatedScores(activeEvent.teams);
                            team = {
                              id: "all_teams",
                              name: "خلاصه کل تیم‌ها (تجمیعی)",
                              membersCount: activeEvent.teams.reduce((acc, t) => acc + (t.membersCount || 0), 0),
                              preScores: aggregated.preScores,
                              postScores: aggregated.postScores,
                              preNotes: "تجمیعی تمام تیم‌ها",
                              postNotes: "تجمیعی تمام تیم‌ها",
                              reflection: { whatWentWell: "", challenges: "", learnings: "", actionPlan: "" }
                            };
                          } else {
                            team = activeEvent.teams.find((t) => t.id === selectedTeamIdForAnalysis)!;
                          }
                          
                          return (
                            <div className="space-y-6">
                              
                              {/* Header Actions for selected report */}
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/60 border border-slate-900 p-5 rounded-2xl">
                                <div>
                                  <h3 className="font-extrabold text-base text-white">دیبریف هوشمند {analysis.teamName} آماده ارائه است</h3>
                                  <p className="text-xs text-slate-400 mt-1">تحلیل کامل شد. اکنون می‌توانید اسلایدها را روی پرده بیندازید یا گزارش را خروجی بگیرید.</p>
                                </div>

                                <div className="flex flex-wrap gap-2">
                                  <button
                                    onClick={() => handleLaunchPresentation(analysis, team)}
                                    className="px-4 py-2.5 bg-gradient-to-l from-amber-500 to-amber-400 text-slate-950 font-black text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-amber-500/10 hover:scale-[1.01] transition-transform cursor-pointer"
                                  >
                                    <Tv className="w-4 h-4 stroke-[2.5] text-slate-950" />
                                    شروع ارائه دیبریف (پروژکتور)
                                  </button>

                                  <button
                                    onClick={() => setIsPreviewingB2BReport(true)}
                                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                                  >
                                    <Eye className="w-4 h-4 text-amber-500" />
                                    سند چاپی B2B کارفرما
                                  </button>

                                  <button
                                    onClick={() => handleExportReport(analysis)}
                                    className="p-2.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 rounded-xl transition-colors cursor-pointer"
                                    title="دانلود گزارش JSON"
                                  >
                                    <FileDown className="w-4 h-4" />
                                  </button>

                                  <button
                                    onClick={() => window.print()}
                                    className="p-2.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 rounded-xl transition-colors cursor-pointer"
                                    title="چاپ گزارش"
                                  >
                                    <Printer className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>

                              {/* Sharing and Real-time Integration Portal Links */}
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-950/60 border border-slate-900 rounded-2xl p-5 text-right text-xs">
                                <div className="space-y-2 bg-slate-900/40 p-4 rounded-xl border border-slate-900 flex flex-col justify-between">
                                  <div className="space-y-2">
                                    <div className="flex items-center justify-between">
                                      <span className="font-extrabold text-amber-400">۱. لینک اختصاصی پروژکتور مستقل</span>
                                      <button
                                        onClick={() => {
                                          const url = `${window.location.origin}${window.location.pathname}?mode=projector&eventId=${activeEvent.id}&teamId=${team.id}`;
                                          navigator.clipboard.writeText(url);
                                        }}
                                        className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 bg-slate-950 px-2 py-1 rounded border border-slate-850 transition-colors cursor-pointer"
                                      >
                                        کپی لینک
                                      </button>
                                    </div>
                                    <p className="text-[10px] text-slate-500 leading-relaxed">
                                      این لینک را در تب جدید مرورگر باز کنید یا روی مانیتور سالن بیندازید تا اسلایدها بدون پنل ادمین نمایش یابند.
                                    </p>
                                  </div>
                                  <button
                                    onClick={() => {
                                      setUrlMode("projector");
                                      setUrlEventId(activeEvent.id);
                                      setUrlTeamId(team.id);
                                    }}
                                    className="text-[10px] text-amber-500 font-bold block text-right hover:underline pt-2 cursor-pointer w-full"
                                  >
                                    باز کردن مستقل پروژکتور (در همین پنجره) ↗
                                  </button>
                                </div>

                                <div className="space-y-2 bg-slate-900/40 p-4 rounded-xl border border-slate-900 flex flex-col justify-between">
                                  <div className="space-y-2">
                                    <div className="flex items-center justify-between">
                                      <span className="font-extrabold text-sky-400">۲. پورتال زنده کلاینت (B2B Report)</span>
                                      <button
                                        onClick={() => {
                                          const url = `${window.location.origin}${window.location.pathname}?mode=client-report&eventId=${activeEvent.id}&teamId=${team.id}`;
                                          navigator.clipboard.writeText(url);
                                        }}
                                        className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 bg-slate-950 px-2 py-1 rounded border border-slate-850 transition-colors cursor-pointer"
                                      >
                                        کپی لینک
                                      </button>
                                    </div>
                                    <p className="text-[10px] text-slate-500 leading-relaxed">
                                      لینک گزارش نهایی ویژه ارسال به کارفرما یا مدیر کل منابع انسانی شرکت جهت مشاهده آنلاین و بی واسطه.
                                    </p>
                                  </div>
                                  <button
                                    onClick={() => {
                                      setUrlMode("client-report");
                                      setUrlEventId(activeEvent.id);
                                      setUrlTeamId(team.id);
                                    }}
                                    className="text-[10px] text-sky-400 font-bold block text-right hover:underline pt-2 cursor-pointer w-full"
                                  >
                                    باز کردن گزارش کارفرما (در همین پنجره) ↗
                                  </button>
                                </div>

                                <div className="space-y-2 bg-slate-900/40 p-4 rounded-xl border border-slate-900 flex flex-col justify-between">
                                  <div className="space-y-2">
                                    <div className="flex items-center justify-between">
                                      <span className="font-extrabold text-emerald-400">۳. نظرسنجی زنده گوشی هم‌تیمی‌ها</span>
                                      <button
                                        onClick={() => {
                                          const url = `${window.location.origin}${window.location.pathname}?mode=live-score&eventId=${activeEvent.id}&teamId=${team.id}`;
                                          navigator.clipboard.writeText(url);
                                        }}
                                        className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 bg-slate-950 px-2 py-1 rounded border border-slate-850 transition-colors cursor-pointer"
                                      >
                                        کپی لینک
                                      </button>
                                    </div>
                                    <p className="text-[10px] text-slate-500 leading-relaxed">
                                      این لینک را برای اعضای تیم اس ام اس، تلگرام یا واتس‌اپ کنید تا هر عضو امتیازدهی را با گوشی ثبت کند.
                                    </p>
                                  </div>
                                  <button
                                    onClick={() => {
                                      setUrlMode("live-score");
                                      setUrlEventId(activeEvent.id);
                                      setUrlTeamId(team.id);
                                    }}
                                    className="text-[10px] text-emerald-400 font-bold block text-right hover:underline pt-2 cursor-pointer w-full"
                                  >
                                    تست لندینگ موبایل اعضا (در همین پنجره) ↗
                                  </button>
                                </div>
                              </div>

                              {/* Two columns: 1. Scores comparison 2. Strengths & Weaknesses */}
                              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                
                                <div className="space-y-6">
                                  {/* Chart view */}
                                  <DebriefChart postScores={team.postScores} teamName={team.name} lightMode={dashboardTheme === "light"} />

                                  {/* Comzee Facilitation insights card */}
                                  <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                                    <h4 className="text-xs font-bold text-amber-400 flex items-center gap-2 pb-2 border-b border-slate-900">
                                      <Lightbulb className="w-4 h-4 text-amber-400" />
                                      بینش‌های عمیق و تخصصی کامزی برای تیم
                                    </h4>
                                    <div className="space-y-3">
                                      {analysis.comzeeInsights.map((insight, idx) => (
                                        <div key={idx} className="flex gap-2.5 items-start bg-slate-900/30 p-3 rounded-xl border border-slate-900/60">
                                          <span className="w-4 h-4 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px] font-mono mt-0.5">
                                            {idx + 1}
                                          </span>
                                          <p className="text-xs text-slate-300 leading-relaxed font-medium">{insight}</p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                </div>

                                <div className="space-y-6">
                                  {/* Detailed Strengths */}
                                  <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                                    <h4 className="text-xs font-bold text-emerald-400 flex items-center gap-2 pb-2 border-b border-slate-900">
                                      <Award className="w-4 h-4 text-emerald-400" />
                                      نقاط قوت تیمی و شواهد رفتاری
                                    </h4>
                                    <div className="space-y-3">
                                      {analysis.strengths.map((strength, idx) => (
                                        <div key={idx} className="bg-slate-900/40 border border-slate-900 rounded-xl p-4 space-y-2">
                                          <h5 className="font-bold text-xs text-white flex items-center gap-2">
                                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                                            {strength.title}
                                          </h5>
                                          <p className="text-slate-400 text-[11px] leading-relaxed pr-3.5">{strength.description}</p>
                                          <div className="bg-emerald-500/5 border border-emerald-500/10 p-2.5 rounded-lg text-[10px] text-emerald-300 leading-relaxed font-medium pr-3.5">
                                            <strong className="text-emerald-400">شاهد رفتاری در رویداد:</strong> {strength.behavioralEvidence}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                  {/* Detailed Challenges & Weaknesses */}
                                  <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                                    <h4 className="text-xs font-bold text-rose-500 flex items-center gap-2 pb-2 border-b border-slate-900">
                                      <AlertTriangle className="w-4 h-4 text-rose-500" />
                                      چالش‌ها، موانع پویایی و ریشه‌یابی روانشناختی
                                    </h4>
                                    <div className="space-y-3">
                                      {analysis.weaknesses.map((weakness, idx) => (
                                        <div key={idx} className="bg-slate-900/40 border border-slate-900 rounded-xl p-4 space-y-2">
                                          <h5 className="font-bold text-xs text-white flex items-center gap-2">
                                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                                            {weakness.title}
                                          </h5>
                                          <p className="text-slate-400 text-[11px] leading-relaxed pr-3.5">{weakness.description}</p>
                                          <div className="bg-rose-500/5 border border-rose-500/10 p-2.5 rounded-lg text-[10px] text-rose-300 leading-relaxed font-medium pr-3.5">
                                            <strong className="text-rose-400">ریشه‌یابی و پویایی گروهی:</strong> {weakness.rootCause}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                </div>

                              </div>

                              {/* Workspace Action Plan - Transfer */}
                              <div className="bg-slate-950/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                                <h4 className="text-xs font-bold text-amber-500 flex items-center gap-2 pb-2 border-b border-slate-900">
                                  <FileSpreadsheet className="w-4 h-4 text-amber-500" />
                                  برنامه انتقال یادگیری به محیط کار اداری (Office Transfer Plan)
                                </h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  {analysis.workspaceTransfer.map((item, idx) => (
                                    <div key={idx} className="bg-slate-900/30 border border-slate-900 p-4 rounded-xl space-y-2">
                                      <h5 className="font-bold text-xs text-white flex items-center gap-1.5">
                                        <CheckCircle2 className="w-4 h-4 text-amber-500" />
                                        {item.actionableStep}
                                      </h5>
                                      <p className="text-slate-400 text-[11px] leading-relaxed pr-5">
                                        <strong className="text-slate-300">نحوه پیاده‌سازی در شرکت:</strong> {item.officeApplication}
                                      </p>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              {/* Workspace Action Plan - Tracker */}
                              <ActionPlanTracker
                                team={team}
                                defaultSuggestions={analysis.workspaceTransfer}
                                onUpdateActionPlan={(plan) => handleUpdateTeam(team.id, "actionPlan", plan)}
                              />

                            </div>
                          );
                        })()
                      )}

                    </div>
                  )}

                </div>
              )}

            </div>
          ) : (
            // No selected event fallback
            <div className="bg-slate-900/20 border border-slate-900 rounded-3xl p-12 text-center flex flex-col items-center justify-center space-y-4">
              <FolderOpen className="w-12 h-12 text-slate-700" />
              <div>
                <h4 className="font-bold text-sm text-slate-400">هیچ کارگاهی انتخاب نشده است</h4>
                <p className="text-xs text-slate-500 mt-1">یک کارگاه را از منوی سمت راست انتخاب کنید یا یک کارگاه تیمی جدید ایجاد نمایید.</p>
              </div>
              <button
                onClick={() => setShowCreateEventModal(true)}
                className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl"
              >
                تعریف اولین کارگاه
              </button>
            </div>
          )}
        </section>

      </main>
      )}

      {/* Footer */}
      {!focusMode && (
        <footer className="bg-slate-900 border-t border-slate-950 mt-12 py-6 px-6 text-center text-xs text-slate-500 space-y-1.5 font-sans">
          <p>تسهیل‌یار دیبریف تیم‌سازی کامزی © {new Date().getFullYear()}</p>
          <p className="text-[10px] text-slate-600">طراحی شده ویژه شبیه‌سازها، پویایی‌های جدی و بازی‌های سازمانی کامزی • comzee.ir</p>
        </footer>
      )}

      {/* Create Event Modal (3-Step Wizard Layout) */}
      {showCreateEventModal && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-7 text-right space-y-6 animate-fade-in shadow-2xl relative">
            <button
              onClick={() => {
                setShowCreateEventModal(false);
                setCreateWizardStep(1);
              }}
              className="absolute left-5 top-5 p-1.5 bg-slate-950 rounded-xl text-slate-500 hover:text-white transition-colors border border-slate-850 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Wizard Header Progress Indicator */}
            <div className="space-y-3 pb-3 border-b border-slate-850">
              <h3 className="font-black text-lg text-white">راه‌اندازی کارگاه با تسهیل‌یار هوشمند (جادوگر تنظیم)</h3>
              
              {/* Animated Progress Steps */}
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-2">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-colors ${
                    createWizardStep >= 1 ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-500"
                  }`}>
                    ۱
                  </div>
                  <span className={`text-[11px] font-bold ${createWizardStep >= 1 ? "text-amber-400" : "text-slate-500"}`}>تعریف کارگاه</span>
                </div>
                
                <div className="flex-1 h-[2px] mx-3 bg-slate-800 relative">
                  <div className="absolute inset-y-0 right-0 bg-amber-500 transition-all duration-300" style={{ width: createWizardStep > 1 ? "100%" : "0%" }} />
                </div>

                <div className="flex items-center gap-2">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-colors ${
                    createWizardStep >= 2 ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-500"
                  }`}>
                    ۲
                  </div>
                  <span className={`text-[11px] font-bold ${createWizardStep >= 2 ? "text-amber-400" : "text-slate-500"}`}>اهداف ماژولار</span>
                </div>

                <div className="flex-1 h-[2px] mx-3 bg-slate-800 relative">
                  <div className="absolute inset-y-0 right-0 bg-amber-500 transition-all duration-300" style={{ width: createWizardStep > 2 ? "100%" : "0%" }} />
                </div>

                <div className="flex items-center gap-2">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-colors ${
                    createWizardStep >= 3 ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-500"
                  }`}>
                    ۳
                  </div>
                  <span className={`text-[11px] font-bold ${createWizardStep >= 3 ? "text-amber-400" : "text-slate-500"}`}>ساختار تیمی</span>
                </div>
              </div>
            </div>

            {/* STEP 1: Definition of Workshop */}
            {createWizardStep === 1 && (
              <div className="space-y-4 text-xs animate-fade-in">
                <div className="space-y-1.5">
                  <label className="text-slate-400 block font-bold">عنوان کارگاه / سناریو</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: شبیه‌سازی مدیریت بحران آپولو ۱۳"
                    value={newEventTitle}
                    onChange={(e) => setNewEventTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-amber-500 transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-slate-400 block font-bold">نام شرکت یا سازمان مشتری</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: اسنپ، دیجی‌کالا، هلدینگ خلیج‌فارس"
                    value={newEventClient}
                    onChange={(e) => setNewEventClient(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-amber-500 transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-slate-400 block font-bold">تسهیل‌گر مسئول این رویداد</label>
                  <input
                    type="text"
                    placeholder="نام تسهیل‌گر مسئول"
                    value={newEventFacilitator}
                    onChange={(e) => setNewEventFacilitator(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-amber-500 transition-colors"
                  />
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    type="button"
                    disabled={!newEventTitle || !newEventClient}
                    onClick={() => setCreateWizardStep(2)}
                    className="px-6 py-2.5 bg-gradient-to-l from-amber-500 to-amber-400 text-slate-950 font-extrabold rounded-xl shadow-lg shadow-amber-500/10 hover:scale-[1.01] transition-transform cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    مرحله بعد: تعیین اهداف ماژولار ➔
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: Modular Goals Setup */}
            {createWizardStep === 2 && (
              <div className="space-y-4 text-xs animate-fade-in">
                {/* Custom Goal Adding input (Dynamic Modularity) */}
                <div className="space-y-2 bg-slate-950 border border-slate-850/60 p-4 rounded-2xl">
                  <label className="text-amber-400 block font-bold">➕ تعریف اهداف دیبریف کاملاً سفارشی (ماژولار)</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="هدف دلخواه جدید را بنویسید... (مثال: ارتقای تفکر چابک)"
                      value={newModularGoalInput}
                      onChange={(e) => setNewModularGoalInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          handleAddModularGoal(newModularGoalInput);
                        }
                      }}
                      className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500 text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => handleAddModularGoal(newModularGoalInput)}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl transition-colors cursor-pointer"
                    >
                      افزودن هدف
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-slate-400 block font-bold">اهداف فعال برای ارزیابی شبیه‌ساز (حداقل یک مورد):</label>
                  <div className="space-y-1.5 max-h-[160px] overflow-y-auto bg-slate-950 p-3 rounded-xl border border-slate-850 pr-1.5">
                    {customGoals.map((goal, idx) => {
                      const isSelected = newEventGoals.includes(goal);
                      return (
                        <div
                          key={idx}
                          className="flex items-center justify-between p-2 rounded-lg text-[11px] leading-relaxed border border-slate-900 bg-slate-900/40 hover:bg-slate-900/80 transition-all"
                        >
                          <div
                            onClick={() => toggleGoalSelection(goal)}
                            className={`flex-1 flex items-start gap-2.5 cursor-pointer text-right ${
                              isSelected ? "text-amber-300 font-semibold" : "text-slate-400"
                            }`}
                          >
                            <span className={`w-4 h-4 rounded flex-shrink-0 flex items-center justify-center border text-[10px] mt-0.5 ${
                              isSelected ? "bg-amber-500 border-amber-400 text-slate-950" : "border-slate-700 text-transparent"
                            }`}>
                              ✓
                            </span>
                            <span>{goal}</span>
                          </div>
                          
                          {/* Allow removing custom goals but keep core ones */}
                          {!DEFAULT_GOALS.includes(goal) && (
                            <button
                              type="button"
                              onClick={() => handleRemoveModularGoal(goal)}
                              className="text-rose-500 hover:text-rose-400 font-bold px-1 text-[10px]"
                              title="حذف هدف سفارشی"
                            >
                              [حذف]
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4 flex justify-between">
                  <button
                    type="button"
                    onClick={() => setCreateWizardStep(1)}
                    className="px-4 py-2.5 bg-slate-800 border border-slate-700 text-slate-300 font-bold rounded-xl cursor-pointer"
                  >
                    اصلاح مشخصات کارگاه
                  </button>
                  <button
                    type="button"
                    disabled={newEventGoals.length === 0}
                    onClick={() => setCreateWizardStep(3)}
                    className="px-6 py-2.5 bg-gradient-to-l from-amber-500 to-amber-400 text-slate-950 font-extrabold rounded-xl shadow-lg shadow-amber-500/10 hover:scale-[1.01] transition-transform cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    مرحله بعد: تنظیم اولیه تیم‌ها ➔
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Teams Pre-population & Finish */}
            {createWizardStep === 3 && (
              <div className="space-y-4 text-xs animate-fade-in text-right">
                <div className="bg-slate-950/60 border border-slate-850 p-4 rounded-2xl space-y-3">
                  <h4 className="font-bold text-amber-400 text-xs flex items-center gap-2">
                    🚀 ایجاد و مقداردهی خودکار تیم‌های هوشمند
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    با شبیه‌سازی تعداد تیم‌ها، کدهای نمونه، نمرات و یادداشت‌های واقعی بلافاصله برای تست سریع در سیستم درج می‌شود. شما پس از شروع می‌توانید این نمرات را به صورت زنده ویرایش یا با دستیار هوشمند مشورت کنید.
                  </p>

                  <div className="space-y-2 pt-2">
                    <label className="text-slate-300 font-bold block">تعداد تیم‌های شبیه‌سازی برای شروع:</label>
                    <div className="flex items-center gap-3 justify-center bg-slate-900 border border-slate-800 p-2.5 rounded-xl">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setAutoTeamsCount(num)}
                          className={`w-10 h-10 text-xs font-black font-mono rounded-lg transition-all cursor-pointer border ${
                            autoTeamsCount === num
                              ? "bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-md shadow-amber-500/10 scale-105"
                              : "bg-slate-950 border-slate-850 text-slate-400 hover:text-white"
                          }`}
                        >
                          {num}
                        </button>
                      ))}
                      <span className="text-slate-400 text-[11px] mr-2">تیم</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-between">
                  <button
                    type="button"
                    onClick={() => setCreateWizardStep(2)}
                    className="px-4 py-2.5 bg-slate-800 border border-slate-700 text-slate-300 font-bold rounded-xl cursor-pointer"
                  >
                    بازگشت به اهداف
                  </button>
                  <button
                    type="button"
                    onClick={handleCreateEvent}
                    className="px-7 py-3 bg-gradient-to-l from-emerald-500 to-emerald-400 text-slate-950 font-black rounded-xl shadow-lg shadow-emerald-500/10 hover:scale-[1.01] transition-transform cursor-pointer"
                  >
                    🚀 ثبت نهایی و شروع کارگاه دیبریف
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {activeEvent && selectedTeamIdForAnalysis && (
        <B2BClientReport
          isOpen={isPreviewingB2BReport}
          onClose={() => setIsPreviewingB2BReport(false)}
          event={activeEvent}
          selectedTeamId={selectedTeamIdForAnalysis}
        />
      )}

      {errorBanner && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl relative space-y-4 text-right" dir="rtl">
            <button
              onClick={() => setErrorBanner(null)}
              className="absolute top-4 left-4 p-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            
            <div className="flex items-start gap-4">
              <div className="p-3 bg-rose-500/10 text-rose-400 rounded-2xl border border-rose-500/20 shrink-0">
                <AlertTriangle className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div className="space-y-1.5">
                <h3 className="text-base font-black text-white">{errorBanner.title}</h3>
                <p className="text-xs text-slate-400 font-semibold leading-relaxed">{errorBanner.message}</p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setErrorBanner(null)}
                className="px-5 py-2.5 bg-slate-800 border border-slate-700 hover:bg-slate-750 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
              >
                متوجه شدم (بستن)
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
